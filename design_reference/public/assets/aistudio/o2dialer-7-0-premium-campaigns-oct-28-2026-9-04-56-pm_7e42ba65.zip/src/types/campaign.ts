export type CampaignStatus = 'active' | 'paused' | 'completed' | 'scheduled';

export type DialerMode = 'rapid' | 'predictive' | 'preview';

export interface CampaignContact {
  id: string;
  name: string;
  phone: string;
  company?: string;
  status: 'pending' | 'completed' | 'busy' | 'no-answer' | 'failed' | 'dnc';
  callDurationSeconds?: number;
  lastAttempt?: string;
  notes?: string;
}

export interface Campaign {
  id: string;
  name: string;
  description?: string;
  status: CampaignStatus;
  totalContacts: number;
  completedCalls: number;
  pendingCalls: number;
  answeredCalls: number;
  failedCalls: number;
  progressPercentage: number;
  createdAt: string;
  lastActivity: string;
  dialerMode: DialerMode;
  delayBetweenCalls: number; // in seconds
  duplicateContactsFound: number;
  callerId?: string;
  contacts: CampaignContact[];
  tags: string[];
}

export type SortField = 'lastActivity' | 'name' | 'progress' | 'contacts' | 'createdAt';
export type SortOrder = 'asc' | 'desc';

export interface CampaignFilterOptions {
  query: string;
  status: CampaignStatus | 'all';
  sortBy: SortField;
  sortOrder: SortOrder;
}

export interface CampaignOverviewStats {
  totalCampaigns: number;
  totalContacts: number;
  completedCalls: number;
  pendingCalls: number;
  overallProgress: number;
  activeCount: number;
  completedCount: number;
  pausedCount: number;
  scheduledCount: number;
}
