import { Campaign, CampaignContact } from './campaign';

export type SessionStatus = 'ready' | 'running' | 'waiting' | 'paused' | 'finished' | 'error';
export type CallPhase = 'idle' | 'dialing' | 'ringing' | 'connected';
export type CallOutcome = 'answered' | 'no-answer' | 'failed' | 'skipped';

export interface CallLogRecord {
  id: string;
  contactId: string;
  name: string;
  phone: string;
  outcome: CallOutcome;
  durationSeconds: number;
  timestamp: string;
}

export interface SessionConfig {
  delayBetweenCalls: number; // in seconds
  retryAttempts: number;
  audioRoute: 'speaker' | 'headset' | 'earpiece';
  randomizeDelay: boolean;
  maxCallDurationSeconds: number;
}

export interface LiveSessionState {
  campaignId: string;
  status: SessionStatus;
  callPhase: CallPhase;
  currentContact: CampaignContact | null;
  currentContactIndex: number;
  callDurationSeconds: number;
  delayCountdownSeconds: number;
  outcomes: {
    answered: number;
    noAnswer: number;
    failed: number;
    skipped: number;
  };
  history: CallLogRecord[];
  errorMessage?: string;
}
