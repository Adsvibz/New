import React from 'react';
import { Pause, Play, SkipForward, Square, RotateCcw } from 'lucide-react';
import { SessionStatus } from '../../types/dialer';
import { Translations } from '../../i18n/translations';

interface SessionControlsProps {
  sessionStatus: SessionStatus;
  isCompleted: boolean;
  onPauseResume: () => void;
  onSkipCall: () => void;
  onPromptStop: () => void;
  onRestartSession: () => void;
  t: Translations;
}

export const SessionControls: React.FC<SessionControlsProps> = ({
  sessionStatus,
  isCompleted,
  onPauseResume,
  onSkipCall,
  onPromptStop,
  onRestartSession,
  t,
}) => {
  const isRunning = sessionStatus === 'running' || sessionStatus === 'waiting';
  const isPaused = sessionStatus === 'paused';
  const isReady = sessionStatus === 'ready';

  return (
    <div className="px-6 py-4 bg-white border-b border-[#F0F2F5]">
      <div className="grid grid-cols-3 gap-2.5">
        {/* Secondary: Skip Call */}
        <button
          onClick={onSkipCall}
          disabled={!isRunning && !isPaused}
          className="h-10 px-3 rounded-xl border border-[#EBECEF] text-[#4B5563] hover:text-[#111827] hover:bg-[#F4F5F7] disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-1.5 text-[12.5px] font-medium"
          aria-label={t.actionSkipCall}
        >
          <SkipForward className="w-3.5 h-3.5 stroke-[2]" />
          <span>{t.actionSkipCall}</span>
        </button>

        {/* Primary Action: Pause or Resume */}
        {isReady || isCompleted ? (
          <button
            onClick={onRestartSession}
            className="h-10 px-4 rounded-xl bg-[#111827] text-white hover:bg-neutral-800 transition-all active:scale-[0.98] flex items-center justify-center gap-2 text-[13px] font-semibold shadow-xs"
            aria-label={isCompleted ? t.actionRestartCampaign : t.actionStartSession}
          >
            {isCompleted ? (
              <>
                <RotateCcw className="w-4 h-4 stroke-[2]" />
                <span>{t.actionRestartCampaign}</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>{t.actionStartSession}</span>
              </>
            )}
          </button>
        ) : (
          <button
            onClick={onPauseResume}
            className={`h-10 px-4 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-2 text-[13px] font-semibold shadow-xs ${
              isPaused
                ? 'bg-[#111827] text-white hover:bg-neutral-800'
                : 'bg-[#111827] text-white hover:bg-neutral-800'
            }`}
            aria-label={isPaused ? t.actionResumeSession : t.actionPauseSession}
          >
            {isPaused ? (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Resume</span>
              </>
            ) : (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause</span>
              </>
            )}
          </button>
        )}

        {/* Secondary / Destructive: Stop Session */}
        <button
          onClick={onPromptStop}
          disabled={isReady || isCompleted}
          className="h-10 px-3 rounded-xl border border-[#EBECEF] text-red-600 hover:bg-red-50 hover:border-red-200 disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-1.5 text-[12.5px] font-medium"
          aria-label={t.actionStopSession}
        >
          <Square className="w-3.5 h-3.5 fill-current" />
          <span>{t.actionStopSession}</span>
        </button>
      </div>
    </div>
  );
};
