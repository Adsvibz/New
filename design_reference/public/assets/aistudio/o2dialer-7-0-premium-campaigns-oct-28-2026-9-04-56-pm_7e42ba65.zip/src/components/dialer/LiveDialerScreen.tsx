import React, { useState, useEffect, useRef } from 'react';
import { Campaign, CampaignContact } from '../../types/campaign';
import {
  CallOutcome,
  CallPhase,
  LiveSessionState,
  SessionConfig,
  SessionStatus,
} from '../../types/dialer';
import { Translations, Language } from '../../i18n/translations';
import {
  applyCallOutcomeToCampaign,
  getNextPendingContact,
  getQueuedContacts,
  removeContactFromCampaign,
} from '../../utils/dialerLogic';
import { DialerHeader } from './DialerHeader';
import { ActiveCallingHero } from './ActiveCallingHero';
import { DialerProgress } from './DialerProgress';
import { SessionControls } from './SessionControls';
import { CallingQueue } from './CallingQueue';
import { SessionConfigStrip } from './SessionConfigStrip';
import { CampaignPickerSheet } from './CampaignPickerSheet';
import { StopConfirmModal } from './StopConfirmModal';
import { DialerSettingsModal } from './DialerSettingsModal';

interface LiveDialerScreenProps {
  campaigns: Campaign[];
  activeCampaignId: string | null;
  onSelectCampaign: (campaign: Campaign) => void;
  onUpdateCampaign: (updatedCampaign: Campaign) => void;
  onOpenCampaignDetails: (campaign: Campaign) => void;
  currentLanguage: Language;
  onToggleLanguage: () => void;
  onTriggerToast: (type: 'success' | 'info' | 'error', message: string) => void;
  t: Translations;
}

export const LiveDialerScreen: React.FC<LiveDialerScreenProps> = ({
  campaigns,
  activeCampaignId,
  onSelectCampaign,
  onUpdateCampaign,
  onOpenCampaignDetails,
  currentLanguage,
  onToggleLanguage,
  onTriggerToast,
  t,
}) => {
  // Find current selected campaign
  const selectedCampaign =
    campaigns.find((c) => c.id === activeCampaignId) ||
    (campaigns.length > 0 ? campaigns[0] : null);

  // Session state
  const [sessionStatus, setSessionStatus] = useState<SessionStatus>('ready');
  const [callPhase, setCallPhase] = useState<CallPhase>('idle');
  const [currentContact, setCurrentContact] = useState<CampaignContact | null>(null);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [delayCountdown, setDelayCountdown] = useState<number>(4);

  // Modals state
  const [isCampaignPickerOpen, setIsCampaignPickerOpen] = useState(false);
  const [isStopConfirmOpen, setIsStopConfirmOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSimulatedError, setIsSimulatedError] = useState(false);

  // Session configuration
  const [sessionConfig, setSessionConfig] = useState<SessionConfig>({
    delayBetweenCalls: selectedCampaign?.delayBetweenCalls ?? 4,
    retryAttempts: 2,
    audioRoute: 'speaker',
    randomizeDelay: false,
    maxCallDurationSeconds: 180,
  });

  // Timers refs
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);
  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync session configuration if campaign changes
  useEffect(() => {
    if (selectedCampaign) {
      setSessionConfig((prev) => ({
        ...prev,
        delayBetweenCalls: selectedCampaign.delayBetweenCalls,
      }));
    }
  }, [selectedCampaign?.id, selectedCampaign?.delayBetweenCalls]);

  // Derived queued contacts
  const queuedContacts = selectedCampaign
    ? getQueuedContacts(selectedCampaign.contacts, currentContact?.id)
    : [];
  const nextContact = queuedContacts.length > 0 ? queuedContacts[0] : null;

  // Clear timers on unmount
  useEffect(() => {
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
      if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    };
  }, []);

  // Live call timer ticker
  useEffect(() => {
    if (sessionStatus === 'running') {
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => {
          const next = prev + 1;
          // Phase progression
          if (next === 2) setCallPhase('ringing');
          if (next === 5) setCallPhase('connected');

          // Automatic completion after realistic duration (e.g. 35s) if user doesn't click an outcome
          if (next >= 35) {
            handleCompleteCurrentCall('answered', 35);
          }
          return next;
        });
      }, 1000);
    } else {
      if (callTimerRef.current) {
        clearInterval(callTimerRef.current);
        callTimerRef.current = null;
      }
    }

    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [sessionStatus, currentContact?.id, selectedCampaign]);

  // Countdown timer ticker for waiting state
  useEffect(() => {
    if (sessionStatus === 'waiting') {
      countdownTimerRef.current = setInterval(() => {
        setDelayCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(countdownTimerRef.current!);
            handleStartNextCall();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
        countdownTimerRef.current = null;
      }
    }

    return () => {
      if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    };
  }, [sessionStatus, selectedCampaign]);

  // Start Session handler
  const handleStartSession = () => {
    if (!selectedCampaign) return;

    const firstContact = getNextPendingContact(selectedCampaign.contacts);
    if (!firstContact) {
      onTriggerToast('info', 'All contacts in this campaign have been dialed.');
      setSessionStatus('finished');
      return;
    }

    setCurrentContact(firstContact);
    setCallDuration(0);
    setCallPhase('dialing');
    setSessionStatus('running');
    onTriggerToast('success', `Session started: Calling ${firstContact.name}`);
  };

  // Start next call after waiting delay
  const handleStartNextCall = () => {
    if (!selectedCampaign) return;

    const next = getNextPendingContact(selectedCampaign.contacts, currentContact?.id);
    if (!next) {
      setSessionStatus('finished');
      setCurrentContact(null);
      onTriggerToast('success', 'All contacts dialed. Campaign completed!');
      return;
    }

    setCurrentContact(next);
    setCallDuration(0);
    setCallPhase('dialing');
    setSessionStatus('running');
  };

  // Complete current call and transition to waiting or finished
  const handleCompleteCurrentCall = (outcome: CallOutcome, duration: number) => {
    if (!selectedCampaign || !currentContact) return;

    const updated = applyCallOutcomeToCampaign(
      selectedCampaign,
      currentContact.id,
      outcome,
      duration
    );
    onUpdateCampaign(updated);

    const remainingPending = updated.contacts.filter(
      (c) => c.status === 'pending' && c.id !== currentContact.id
    );

    if (remainingPending.length === 0) {
      setSessionStatus('finished');
      setCurrentContact(null);
      onTriggerToast('success', `Call completed. Campaign finished!`);
    } else {
      // Transition to waiting state with countdown
      const delay = sessionConfig.delayBetweenCalls;
      setDelayCountdown(delay);
      setSessionStatus('waiting');
      setCallPhase('idle');
      setCurrentContact(null);
    }
  };

  // Pause / Resume handler
  const handlePauseResume = () => {
    if (sessionStatus === 'running' || sessionStatus === 'waiting') {
      setSessionStatus('paused');
      onTriggerToast('info', 'Auto-dialer session paused.');
    } else if (sessionStatus === 'paused') {
      if (currentContact) {
        setSessionStatus('running');
      } else {
        setSessionStatus('waiting');
      }
      onTriggerToast('success', 'Auto-dialer session resumed.');
    }
  };

  // Skip Call handler
  const handleSkipCall = () => {
    if (!currentContact) return;
    onTriggerToast('info', `Skipped ${currentContact.name}.`);
    handleCompleteCurrentCall('skipped', callDuration);
  };

  // Confirm Stop Session
  const handleConfirmStop = () => {
    setSessionStatus('ready');
    setCallPhase('idle');
    setCurrentContact(null);
    setCallDuration(0);
    setIsStopConfirmOpen(false);
    onTriggerToast('info', 'Session ended. Call progress has been saved.');
  };

  // Remove contact from queue
  const handleRemoveFromQueue = (contact: CampaignContact) => {
    if (!selectedCampaign) return;
    const updated = removeContactFromCampaign(selectedCampaign, contact.id);
    onUpdateCampaign(updated);
    onTriggerToast('info', `Removed ${contact.name} from queue.`);
  };

  // Toggle simulated error state
  const handleToggleSimulatedError = () => {
    if (sessionStatus === 'error') {
      setSessionStatus('ready');
      setIsSimulatedError(false);
      onTriggerToast('success', 'Carrier reconnected.');
    } else {
      setSessionStatus('error');
      setIsSimulatedError(true);
      onTriggerToast('error', 'Simulated carrier connection error.');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-white flex flex-col">
      {/* 1. Compact Screen Header */}
      <DialerHeader
        selectedCampaign={selectedCampaign}
        sessionStatus={sessionStatus}
        onOpenCampaignPicker={() => setIsCampaignPickerOpen(true)}
        currentLanguage={currentLanguage}
        onToggleLanguage={onToggleLanguage}
        onSimulateErrorToggle={handleToggleSimulatedError}
        t={t}
      />

      {/* 2. Active Calling Area — The Main Hero */}
      <ActiveCallingHero
        sessionStatus={sessionStatus}
        callPhase={callPhase}
        currentContact={currentContact}
        nextContact={nextContact}
        callDurationSeconds={callDuration}
        delayCountdownSeconds={delayCountdown}
        selectedCampaign={selectedCampaign}
        onStartSession={handleStartSession}
        onRecordManualOutcome={(outcome) =>
          handleCompleteCurrentCall(outcome, Math.max(callDuration, 15))
        }
        onResolveError={() => {
          setSessionStatus('ready');
          setIsSimulatedError(false);
        }}
        onSelectAnotherCampaign={() => setIsCampaignPickerOpen(true)}
        onViewResults={() => {
          if (selectedCampaign) onOpenCampaignDetails(selectedCampaign);
        }}
        t={t}
      />

      {/* 3. Live Campaign Progress */}
      <DialerProgress campaign={selectedCampaign} t={t} />

      {/* 4. Session Controls — EXTREMELY IMPORTANT */}
      <SessionControls
        sessionStatus={sessionStatus}
        isCompleted={(selectedCampaign?.pendingCalls ?? 0) === 0}
        onPauseResume={handlePauseResume}
        onSkipCall={handleSkipCall}
        onPromptStop={() => setIsStopConfirmOpen(true)}
        onRestartSession={handleStartSession}
        t={t}
      />

      {/* 5. Upcoming Calling Queue ("Up Next") */}
      <CallingQueue
        queuedContacts={queuedContacts}
        onRemoveContact={handleRemoveFromQueue}
        t={t}
      />

      {/* 6. Session Configuration Strip */}
      <SessionConfigStrip
        config={sessionConfig}
        delaySec={sessionConfig.delayBetweenCalls}
        onOpenSettings={() => setIsSettingsOpen(true)}
        t={t}
      />

      {/* Modals & Bottom Sheets */}
      <CampaignPickerSheet
        campaigns={campaigns}
        selectedCampaignId={selectedCampaign?.id}
        isOpen={isCampaignPickerOpen}
        onClose={() => setIsCampaignPickerOpen(false)}
        onSelectCampaign={(c) => {
          onSelectCampaign(c);
          setSessionStatus('ready');
          setCurrentContact(null);
          setCallDuration(0);
        }}
        t={t}
      />

      <StopConfirmModal
        isOpen={isStopConfirmOpen}
        campaignName={selectedCampaign?.name ?? 'Campaign'}
        onConfirm={handleConfirmStop}
        onCancel={() => setIsStopConfirmOpen(false)}
        t={t}
      />

      <DialerSettingsModal
        isOpen={isSettingsOpen}
        config={sessionConfig}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateConfig={setSessionConfig}
        t={t}
      />
    </div>
  );
};
