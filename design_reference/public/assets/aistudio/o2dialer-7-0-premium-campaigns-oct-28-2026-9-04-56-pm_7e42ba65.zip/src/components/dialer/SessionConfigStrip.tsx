import React from 'react';
import { Sliders, Volume2, Clock, RotateCw } from 'lucide-react';
import { SessionConfig } from '../../types/dialer';
import { Translations } from '../../i18n/translations';

interface SessionConfigStripProps {
  config: SessionConfig;
  delaySec: number;
  onOpenSettings: () => void;
  t: Translations;
}

export const SessionConfigStrip: React.FC<SessionConfigStripProps> = ({
  config,
  delaySec,
  onOpenSettings,
  t,
}) => {
  return (
    <div className="px-6 py-2.5 bg-[#FAFAFA] border-t border-[#F0F2F5] flex items-center justify-between text-[11.5px] text-[#6B7280]">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1" title="Delay between calls">
          <Clock className="w-3.5 h-3.5 text-[#8E95A2]" />
          <span>{delaySec}s delay</span>
        </div>
        <span aria-hidden="true" className="text-neutral-300">·</span>
        <div className="flex items-center gap-1" title="Retry attempts on failed call">
          <RotateCw className="w-3.5 h-3.5 text-[#8E95A2]" />
          <span>{t.retryCount}</span>
        </div>
        <span aria-hidden="true" className="text-neutral-300">·</span>
        <div className="flex items-center gap-1" title="Audio routing">
          <Volume2 className="w-3.5 h-3.5 text-[#8E95A2]" />
          <span className="capitalize">{config.audioRoute}</span>
        </div>
      </div>

      <button
        onClick={onOpenSettings}
        className="text-[11px] font-medium text-[#111827] hover:underline flex items-center gap-1"
        aria-label="Configure session preferences"
      >
        <Sliders className="w-3 h-3" />
        <span>Settings</span>
      </button>
    </div>
  );
};
