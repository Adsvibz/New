import React from 'react';
import { Campaign, CampaignContact } from '../../types/campaign';
import { CallOutcome, CallPhase, SessionStatus } from '../../types/dialer';
import { Translations } from '../../i18n/translations';
import { formatCallTimer } from '../../utils/dialerLogic';
import { Phone, PhoneCall, AlertCircle, RefreshCw, CheckCircle2, Clock } from 'lucide-react';

interface ActiveCallingHeroProps {
  sessionStatus: SessionStatus;
  callPhase: CallPhase;
  currentContact: CampaignContact | null;
  nextContact: CampaignContact | null;
  callDurationSeconds: number;
  delayCountdownSeconds: number;
  selectedCampaign: Campaign | null;
  onStartSession: () => void;
  onRecordManualOutcome: (outcome: CallOutcome) => void;
  onResolveError: () => void;
  onSelectAnotherCampaign: () => void;
  onViewResults: () => void;
  t: Translations;
}

export const ActiveCallingHero: React.FC<ActiveCallingHeroProps> = ({
  sessionStatus,
  callPhase,
  currentContact,
  nextContact,
  callDurationSeconds,
  delayCountdownSeconds,
  selectedCampaign,
  onStartSession,
  onRecordManualOutcome,
  onResolveError,
  onSelectAnotherCampaign,
  onViewResults,
  t,
}) => {
  // 1. Error State
  if (sessionStatus === 'error') {
    return (
      <div className="p-6 bg-red-50/50 border-b border-red-100/80 text-center">
        <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-2.5">
          <AlertCircle className="w-5 h-5 stroke-[2]" />
        </div>
        <h2 className="text-[16px] font-semibold text-[#111827] tracking-tight">
          Carrier Connection Paused
        </h2>
        <p className="text-[12.5px] text-[#6B7280] max-w-xs mx-auto mt-1 mb-3.5 leading-relaxed">
          The auto-dialer detected a momentary SIM carrier timeout. Queued calls remain intact.
        </p>
        <button
          onClick={onResolveError}
          className="px-4 py-1.5 text-[12.5px] font-medium bg-[#111827] text-white hover:bg-neutral-800 rounded-lg transition-colors inline-flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Resume Connection</span>
        </button>
      </div>
    );
  }

  // 2. Finished State
  if (sessionStatus === 'finished') {
    return (
      <div className="p-6 bg-white border-b border-[#F0F2F5] text-center">
        <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-2.5">
          <CheckCircle2 className="w-5 h-5 stroke-[2]" />
        </div>
        <h2 className="text-[17px] font-semibold text-[#111827] tracking-tight">
          {t.sessionCompletedTitle}
        </h2>
        <p className="text-[12.5px] text-[#8E95A2] max-w-xs mx-auto mt-1 mb-4 leading-relaxed">
          {t.sessionCompletedSubtitle}
        </p>
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={onViewResults}
            className="px-3.5 py-1.5 text-[12.5px] font-medium text-[#111827] hover:bg-[#F4F5F7] border border-[#EBECEF] rounded-lg transition-colors"
          >
            {t.actionViewResults}
          </button>
          <button
            onClick={onSelectAnotherCampaign}
            className="px-3.5 py-1.5 text-[12.5px] font-medium bg-[#111827] text-white hover:bg-neutral-800 rounded-lg transition-colors"
          >
            {t.chooseAnotherCampaign}
          </button>
        </div>
      </div>
    );
  }

  // 3. Ready State (Before starting or when stopped)
  if (sessionStatus === 'ready' || !currentContact && sessionStatus !== 'waiting') {
    const hasProgress = (selectedCampaign?.completedCalls ?? 0) > 0;
    const isCompleted = (selectedCampaign?.pendingCalls ?? 0) === 0;

    return (
      <div className="p-6 bg-white border-b border-[#F0F2F5] text-center">
        <span className="text-[11.5px] font-medium text-[#8E95A2] uppercase tracking-wider block mb-1">
          {t.readyToCallHeading}
        </span>
        <h2 className="text-[20px] font-semibold text-[#111827] tracking-tight">
          {selectedCampaign ? selectedCampaign.name : 'No Campaign Selected'}
        </h2>
        <p className="text-[12.5px] text-[#8E95A2] max-w-xs mx-auto mt-1 mb-4 leading-relaxed">
          {selectedCampaign
            ? `${selectedCampaign.pendingCalls} remaining calls in queue · ${selectedCampaign.dialerMode} dialer`
            : t.readyToCallSubtitle}
        </p>

        {selectedCampaign && (
          <button
            onClick={onStartSession}
            disabled={isCompleted}
            className="px-5 py-2 text-[13px] font-medium bg-[#111827] text-white hover:bg-neutral-800 disabled:opacity-40 rounded-full transition-all active:scale-[0.98] inline-flex items-center gap-1.5 shadow-xs"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>
              {isCompleted
                ? t.actionRestartCampaign
                : hasProgress
                ? t.actionResumeSession
                : t.actionStartSession}
            </span>
          </button>
        )}
      </div>
    );
  }

  // 4. Waiting State (Between calls with countdown)
  if (sessionStatus === 'waiting') {
    return (
      <div className="p-6 bg-white border-b border-[#F0F2F5] text-center">
        <span className="text-[11px] font-medium text-[#8E95A2] uppercase tracking-wider block mb-1">
          Pacing Interval
        </span>

        {/* Countdown display */}
        <div className="text-[32px] font-semibold text-[#111827] tabular-nums tracking-tight leading-none mb-2">
          {t.nextCallIn(delayCountdownSeconds)}
        </div>

        {nextContact && (
          <p className="text-[13px] text-[#6B7280]">
            Upcoming: <strong className="text-[#111827] font-semibold">{nextContact.name}</strong>{' '}
            <span className="font-mono text-[12px] text-[#8E95A2]">({nextContact.phone})</span>
          </p>
        )}
      </div>
    );
  }

  // 5. Active Call or Paused Call State (Hero)
  return (
    <div className="p-6 bg-white border-b border-[#F0F2F5] text-center transition-all">
      {/* Status kicker: Currently Calling or Paused */}
      <div className="flex items-center justify-center gap-1.5 mb-1.5">
        {sessionStatus === 'paused' ? (
          <span className="text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
            {t.sessionStatusPaused}
          </span>
        ) : (
          <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>
              {callPhase === 'dialing'
                ? t.callingPhaseDialing
                : callPhase === 'ringing'
                ? t.callingPhaseRinging
                : t.callingPhaseConnected}
            </span>
          </span>
        )}
      </div>

      {/* Main Focal Point: Contact Name */}
      <h2 className="text-[24px] font-semibold text-[#111827] tracking-tight leading-tight">
        {currentContact?.name || 'Contact'}
      </h2>

      {/* Company & Phone number */}
      <div className="flex items-center justify-center gap-1.5 text-[13px] text-[#6B7280] mt-1">
        {currentContact?.company && (
          <>
            <span>{currentContact.company}</span>
            <span aria-hidden="true" className="text-neutral-300">·</span>
          </>
        )}
        <span className="font-mono text-[12.5px] tabular-nums text-[#111827]">
          {currentContact?.phone}
        </span>
      </div>

      {/* Live Call Duration */}
      <div className="mt-3 text-[28px] font-semibold text-[#111827] tabular-nums tracking-tight leading-none">
        {formatCallTimer(callDurationSeconds)}
      </div>

      {/* Outcome simulation shortcuts (Subtle pill buttons for instant outcome simulation) */}
      {sessionStatus === 'running' && (
        <div className="mt-4 pt-3 border-t border-[#F0F2F5] flex items-center justify-center gap-1.5">
          <span className="text-[11px] text-[#8E95A2] mr-1">Log outcome:</span>
          <button
            onClick={() => onRecordManualOutcome('answered')}
            className="px-2.5 py-1 text-[11px] font-medium bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-md transition-colors"
          >
            {t.outcomeAnswered}
          </button>
          <button
            onClick={() => onRecordManualOutcome('no-answer')}
            className="px-2.5 py-1 text-[11px] font-medium bg-neutral-100 text-[#4B5563] hover:bg-neutral-200 rounded-md transition-colors"
          >
            {t.outcomeNoAnswer}
          </button>
          <button
            onClick={() => onRecordManualOutcome('failed')}
            className="px-2.5 py-1 text-[11px] font-medium bg-red-50 text-red-700 hover:bg-red-100 rounded-md transition-colors"
          >
            {t.outcomeFailed}
          </button>
        </div>
      )}
    </div>
  );
};
