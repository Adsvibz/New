import React from 'react';
import { CampaignContact } from '../../types/campaign';
import { Translations } from '../../i18n/translations';
import { Trash2 } from 'lucide-react';

interface CallingQueueProps {
  queuedContacts: CampaignContact[];
  onRemoveContact: (contact: CampaignContact) => void;
  t: Translations;
}

export const CallingQueue: React.FC<CallingQueueProps> = ({
  queuedContacts,
  onRemoveContact,
  t,
}) => {
  return (
    <section className="px-6 py-4 bg-white" aria-label="Calling Queue">
      {/* Queue Header */}
      <div className="flex items-center justify-between pb-2 mb-1 border-b border-[#F0F2F5]">
        <div className="flex items-center gap-2">
          <h3 className="text-[14px] font-semibold text-[#111827] tracking-tight">
            {t.upNext}
          </h3>
          <span className="text-[12px] text-[#8E95A2] font-normal tabular-nums">
            — {t.upNextRemaining(queuedContacts.length)}
          </span>
        </div>
      </div>

      {/* Clean list rows */}
      {queuedContacts.length === 0 ? (
        <div className="py-8 text-center text-[#8E95A2] text-[12.5px]">
          Queue is clear. No further contacts pending.
        </div>
      ) : (
        <div className="divide-y divide-[#F0F2F5]">
          {queuedContacts.slice(0, 8).map((contact, index) => (
            <div
              key={contact.id}
              className="py-2.5 flex items-center justify-between gap-3 group transition-colors hover:bg-[#FAFAFA] -mx-2 px-2 rounded-lg"
            >
              {/* Order number, Name & Phone */}
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                <span className="w-5 text-[11px] font-mono text-[#8E95A2] shrink-0 tabular-nums">
                  {index + 1}.
                </span>
                <div className="min-w-0 flex-1 flex items-baseline gap-2 truncate">
                  <span className="text-[13px] font-medium text-[#111827] truncate">
                    {contact.name}
                  </span>
                  <span className="font-mono text-[11.5px] text-[#8E95A2] tabular-nums shrink-0">
                    {contact.phone}
                  </span>
                </div>
              </div>

              {/* Remove button */}
              <button
                type="button"
                onClick={() => onRemoveContact(contact)}
                className="w-7 h-7 rounded-md text-[#8E95A2] hover:text-red-600 hover:bg-red-50 flex items-center justify-center transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                title={t.removeFromQueue}
                aria-label={`Remove ${contact.name} from queue`}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          {queuedContacts.length > 8 && (
            <div className="pt-2 text-center text-[11.5px] text-[#8E95A2] font-medium">
              + {queuedContacts.length - 8} more contacts in queue
            </div>
          )}
        </div>
      )}
    </section>
  );
};
