import React from 'react';
import { ChevronDown, Globe, Sparkles } from 'lucide-react';
import { SessionStatus } from '../../types/dialer';
import { Campaign } from '../../types/campaign';
import { Translations, Language } from '../../i18n/translations';

interface DialerHeaderProps {
  selectedCampaign: Campaign | null;
  sessionStatus: SessionStatus;
  onOpenCampaignPicker: () => void;
  currentLanguage: Language;
  onToggleLanguage: () => void;
  onSimulateErrorToggle: () => void;
  t: Translations;
}

export const DialerHeader: React.FC<DialerHeaderProps> = ({
  selectedCampaign,
  sessionStatus,
  onOpenCampaignPicker,
  currentLanguage,
  onToggleLanguage,
  onSimulateErrorToggle,
  t,
}) => {
  const getStatusBadge = () => {
    switch (sessionStatus) {
      case 'running':
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
            {t.sessionStatusRunning}
          </span>
        );
      case 'waiting':
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">
            {t.sessionStatusWaiting}
          </span>
        );
      case 'paused':
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
            {t.sessionStatusPaused}
          </span>
        );
      case 'finished':
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-neutral-600 bg-neutral-100 px-2 py-0.5 rounded-full">
            {t.sessionStatusFinished}
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-red-700 bg-red-50 px-2 py-0.5 rounded-full">
            {t.sessionStatusError}
          </span>
        );
      case 'ready':
      default:
        return (
          <span className="inline-flex items-center text-[10.5px] font-semibold text-neutral-600 bg-neutral-100 px-2 py-0.5 rounded-full">
            {t.sessionStatusReady}
          </span>
        );
    }
  };

  return (
    <header className="px-6 pt-5 pb-3 bg-white border-b border-[#F0F2F5]">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-[24px] font-semibold tracking-tight text-[#111827] leading-none">
              {t.dialerTitle}
            </h1>
            <div>{getStatusBadge()}</div>
          </div>

          {/* Selected Campaign Button */}
          <button
            onClick={onOpenCampaignPicker}
            className="flex items-center gap-1.5 mt-1.5 text-left group max-w-full"
            aria-label="Change active campaign"
          >
            <span className="text-[12.5px] text-[#6B7280] group-hover:text-[#111827] truncate font-medium transition-colors">
              {selectedCampaign ? selectedCampaign.name : 'Select a campaign'}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#8E95A2] group-hover:text-[#111827] shrink-0 transition-colors" />
          </button>
        </div>

        {/* Top utility actions: Language & simulated error check */}
        <div className="flex items-center gap-1 shrink-0 pt-0.5">
          <button
            onClick={onSimulateErrorToggle}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#8E95A2] hover:text-[#111827] hover:bg-[#F4F5F7] transition-colors"
            title="Toggle simulated carrier state"
            aria-label="Toggle error state"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onToggleLanguage}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#8E95A2] hover:text-[#111827] hover:bg-[#F4F5F7] transition-colors"
            title={currentLanguage === 'en' ? 'العربية' : 'English'}
            aria-label="Toggle language"
          >
            <Globe className="w-4 h-4 stroke-[1.8]" />
          </button>
        </div>
      </div>
    </header>
  );
};
