import React from 'react';
import { Campaign } from '../../types/campaign';
import { Translations } from '../../i18n/translations';

interface DialerProgressProps {
  campaign: Campaign | null;
  t: Translations;
}

export const DialerProgress: React.FC<DialerProgressProps> = ({ campaign, t }) => {
  if (!campaign) return null;

  return (
    <section className="px-6 py-3.5 bg-white border-b border-[#F0F2F5]" aria-label="Campaign Progress">
      {/* 4 Unboxed Statistics */}
      <div className="grid grid-cols-4 gap-2 pb-2.5">
        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statTotalContacts}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {campaign.totalContacts.toLocaleString()}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statCompletedCalls}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {campaign.completedCalls.toLocaleString()}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statPendingCalls}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {campaign.pendingCalls.toLocaleString()}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            Progress
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {campaign.progressPercentage}%
          </span>
        </div>
      </div>

      {/* Modern Hairline Progress Bar */}
      <div className="w-full h-1 bg-[#F0F2F5] rounded-full overflow-hidden my-2">
        <div
          className="h-full bg-[#111827] rounded-full transition-all duration-300"
          style={{ width: `${Math.min(100, Math.max(0, campaign.progressPercentage))}%` }}
        />
      </div>

      {/* Calling Outcomes Breakdown */}
      <div className="flex items-center justify-between text-[11.5px] text-[#6B7280] pt-1">
        <div className="flex items-center gap-3">
          <span>
            <strong className="text-emerald-700 font-semibold tabular-nums">{campaign.answeredCalls}</strong> {t.outcomeAnswered}
          </span>
          <span aria-hidden="true" className="text-neutral-300">·</span>
          <span>
            <strong className="text-[#111827] font-semibold tabular-nums">
              {Math.max(0, campaign.completedCalls - campaign.answeredCalls - campaign.failedCalls)}
            </strong> {t.outcomeNoAnswer}
          </span>
          <span aria-hidden="true" className="text-neutral-300">·</span>
          <span>
            <strong className="text-red-600 font-semibold tabular-nums">{campaign.failedCalls}</strong> {t.outcomeFailed}
          </span>
        </div>

        <span className="text-[#8E95A2] font-mono text-[11px]">
          {campaign.dialerMode}
        </span>
      </div>
    </section>
  );
};
