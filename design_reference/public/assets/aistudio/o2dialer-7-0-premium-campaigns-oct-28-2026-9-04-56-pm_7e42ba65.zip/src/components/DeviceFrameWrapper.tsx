import React from 'react';

interface DeviceFrameWrapperProps {
  isDeviceFrame: boolean;
  children: React.ReactNode;
}

export const DeviceFrameWrapper: React.FC<DeviceFrameWrapperProps> = ({
  children,
}) => {
  return (
    <main className="w-full min-h-screen bg-[#ECEEF2] flex items-center justify-center sm:py-8 sm:px-4">
      {/* Physical Android Mobile Frame */}
      <div className="relative w-full max-w-[412px] bg-white sm:rounded-[44px] overflow-hidden sm:shadow-[0_20px_50px_rgba(0,0,0,0.12)] sm:border sm:border-black/5 flex flex-col h-screen sm:h-[844px] select-none">
        {/* Subtle camera punch-hole (only visible on mobile bezel) */}
        <div className="hidden sm:block absolute top-2.5 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-black/90 rounded-full z-40 pointer-events-none ring-1 ring-black/10" />

        {/* Screen container */}
        <div className="flex-1 flex flex-col overflow-hidden relative bg-white">
          {children}
        </div>
      </div>
    </main>
  );
};
