import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Campaign, DialerMode, CampaignStatus } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface EditCampaignSheetProps {
  campaign: Campaign | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedCampaign: Campaign) => void;
  t: Translations;
}

export const EditCampaignSheet: React.FC<EditCampaignSheetProps> = ({
  campaign,
  isOpen,
  onClose,
  onSave,
  t,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<CampaignStatus>('active');
  const [dialerMode, setDialerMode] = useState<DialerMode>('rapid');
  const [delaySec, setDelaySec] = useState<number>(4);
  const [callerId, setCallerId] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (campaign) {
      setName(campaign.name);
      setDescription(campaign.description || '');
      setStatus(campaign.status);
      setDialerMode(campaign.dialerMode);
      setDelaySec(campaign.delayBetweenCalls);
      setCallerId(campaign.callerId || '+1 (800) 555-0199');
    }
  }, [campaign]);

  if (!isOpen || !campaign) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Campaign name cannot be empty.');
      return;
    }

    onSave({
      ...campaign,
      name: name.trim(),
      description: description.trim() || undefined,
      status,
      dialerMode,
      delayBetweenCalls: delaySec,
      callerId,
      lastActivity: new Date().toISOString(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-white rounded-t-2xl sm:rounded-2xl border border-[#E9EBEF] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="edit-campaign-heading"
      >
        <div className="px-5 py-3.5 border-b border-[#E9EBEF] flex items-center justify-between">
          <div>
            <h2 id="edit-campaign-heading" className="text-[16px] font-semibold text-[#17191D]">
              {t.actionEdit}
            </h2>
            <p className="text-[12px] text-[#777E89]">Update dialer settings and metadata</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#777E89] hover:text-[#17191D] rounded-md transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-[12px] rounded-lg">
              {error}
            </div>
          )}

          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Campaign Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              className="w-full h-9 px-3 text-[13px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg focus:outline-none focus:border-[#2563EB] text-[#17191D]"
            />
          </div>

          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full h-9 px-3 text-[13px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg focus:outline-none focus:border-[#2563EB] text-[#17191D]"
            />
          </div>

          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Campaign Status
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['active', 'paused', 'completed', 'scheduled'] as CampaignStatus[]).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatus(st)}
                  className={`py-1.5 text-[12px] font-medium rounded-lg border capitalize transition-all ${
                    status === st
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-[#F7F8FA] text-[#777E89] border-[#E9EBEF] hover:text-[#17191D]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[12px] font-medium text-[#17191D] mb-1">
                Dialer Algorithm
              </label>
              <select
                value={dialerMode}
                onChange={(e) => setDialerMode(e.target.value as DialerMode)}
                className="w-full h-9 px-2 text-[12.5px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D]"
              >
                <option value="rapid">Rapid Auto-Dialer</option>
                <option value="predictive">Predictive Multi-Line</option>
                <option value="preview">Preview (Manual)</option>
              </select>
            </div>

            <div>
              <label className="block text-[12px] font-medium text-[#17191D] mb-1">
                Delay Between Calls
              </label>
              <select
                value={delaySec}
                onChange={(e) => setDelaySec(Number(e.target.value))}
                className="w-full h-9 px-2 text-[12.5px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D]"
              >
                <option value={2}>2s</option>
                <option value={4}>4s</option>
                <option value={6}>6s</option>
                <option value={10}>10s</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Outbound Caller ID
            </label>
            <input
              type="text"
              value={callerId}
              onChange={(e) => setCallerId(e.target.value)}
              className="w-full h-9 px-3 text-[13px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D]"
            />
          </div>

          <div className="pt-3 border-t border-[#E9EBEF] flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[12.5px] font-medium text-[#777E89] hover:text-[#17191D] hover:bg-[#F7F8FA] rounded-lg transition-colors"
            >
              {t.actionCancel}
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-[12.5px] font-medium bg-[#17191D] text-white hover:bg-neutral-800 rounded-lg transition-colors"
            >
              {t.actionSave}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
