import React, { useState, useRef, useEffect } from 'react';
import { Search, X, SlidersHorizontal, Check } from 'lucide-react';
import { CampaignStatus, SortField, SortOrder } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface SearchAndFilterBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedStatus: CampaignStatus | 'all';
  onStatusChange: (status: CampaignStatus | 'all') => void;
  sortBy: SortField;
  sortOrder: SortOrder;
  onSortChange: (field: SortField, order: SortOrder) => void;
  t: Translations;
  statusCounts: {
    all: number;
    active: number;
    completed: number;
    paused: number;
    scheduled: number;
  };
}

export const SearchAndFilterBar: React.FC<SearchAndFilterBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedStatus,
  onStatusChange,
  sortBy,
  sortOrder,
  onSortChange,
  t,
}) => {
  const [isSortOpen, setIsSortOpen] = useState(false);
  const sortRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) {
        setIsSortOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filterTabs: Array<{ id: CampaignStatus | 'all'; label: string }> = [
    { id: 'all', label: t.filterAll },
    { id: 'active', label: t.filterActive },
    { id: 'completed', label: t.filterCompleted },
    { id: 'paused', label: t.filterPaused },
    { id: 'scheduled', label: t.filterScheduled },
  ];

  const sortOptions: Array<{ field: SortField; label: string; defaultOrder: SortOrder }> = [
    { field: 'lastActivity', label: t.sortRecent, defaultOrder: 'desc' },
    { field: 'name', label: t.sortName, defaultOrder: 'asc' },
    { field: 'progress', label: t.sortProgress, defaultOrder: 'desc' },
    { field: 'contacts', label: t.sortContacts, defaultOrder: 'desc' },
    { field: 'createdAt', label: t.sortCreated, defaultOrder: 'desc' },
  ];

  return (
    <div className="px-6 pt-1 pb-3 bg-white space-y-2.5">
      {/* Clean Minimal Search Input with Inline Sort Button */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E95A2] pointer-events-none stroke-[1.8]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full h-9 pl-9 pr-8 text-[13px] bg-[#F4F5F7] text-[#111827] placeholder:text-[#8E95A2] rounded-xl focus:outline-none focus:bg-[#ECEEF2] transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#8E95A2] hover:text-[#111827] rounded-full"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Sort Menu Button */}
        <div className="relative" ref={sortRef}>
          <button
            onClick={() => setIsSortOpen(!isSortOpen)}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-[#F4F5F7] text-[#6B7280] hover:text-[#111827] hover:bg-[#ECEEF2] transition-colors"
            aria-label="Sort options"
            aria-expanded={isSortOpen}
          >
            <SlidersHorizontal className="w-4 h-4 stroke-[1.8]" />
          </button>

          {/* Sort Dropdown */}
          {isSortOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-48 bg-white border border-[#E9EBEF] rounded-2xl shadow-xl p-1.5 z-30">
              <span className="block px-3 py-1.5 text-[10px] font-semibold text-[#8E95A2] uppercase tracking-wider">
                {t.sortBy}
              </span>
              {sortOptions.map((opt) => {
                const isSelected = sortBy === opt.field;
                return (
                  <button
                    key={opt.field}
                    onClick={() => {
                      if (isSelected) {
                        onSortChange(opt.field, sortOrder === 'asc' ? 'desc' : 'asc');
                      } else {
                        onSortChange(opt.field, opt.defaultOrder);
                      }
                      setIsSortOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 text-[12.5px] rounded-lg text-left transition-colors ${
                      isSelected
                        ? 'bg-[#F4F5F7] text-[#111827] font-semibold'
                        : 'text-[#6B7280] hover:bg-[#F4F5F7] hover:text-[#111827]'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {isSelected && (
                      <span className="flex items-center gap-1 text-[11px] text-[#111827]">
                        <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Understated Minimal Filter Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
        {filterTabs.map((tab) => {
          const isActive = selectedStatus === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onStatusChange(tab.id)}
              className={`px-3 py-1 rounded-full text-[12px] font-medium transition-all whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-[#111827] text-white'
                  : 'text-[#8E95A2] hover:text-[#111827] hover:bg-[#F4F5F7]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};
