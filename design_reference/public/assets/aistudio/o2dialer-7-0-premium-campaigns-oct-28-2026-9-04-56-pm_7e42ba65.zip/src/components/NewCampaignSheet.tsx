import React, { useState } from 'react';
import { X, Upload, Check, Zap, Layers, Eye } from 'lucide-react';
import { Campaign, DialerMode } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface NewCampaignSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (campaignData: Partial<Campaign>) => void;
  t: Translations;
}

export const NewCampaignSheet: React.FC<NewCampaignSheetProps> = ({
  isOpen,
  onClose,
  onCreate,
  t,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [dialerMode, setDialerMode] = useState<DialerMode>('rapid');
  const [delaySec, setDelaySec] = useState<number>(4);
  const [callerId, setCallerId] = useState<string>('+1 (800) 555-0199');
  const [contactSource, setContactSource] = useState<'csv' | 'crm' | 'contacts'>('csv');
  const [sampleContactsCount, setSampleContactsCount] = useState<number>(250);
  const [startImmediately, setStartImmediately] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Campaign name is required.');
      return;
    }

    // Generate sample contacts based on count
    const generatedContacts = Array.from({ length: Math.min(sampleContactsCount, 15) }, (_, i) => ({
      id: `gen-${Date.now()}-${i}`,
      name: ['Alex Rivera', 'Maya Lin', 'Jordan Hayes', 'Sami Al-Khatib', 'Chloe Bennett', 'Liam Thorne'][i % 6] + (i > 5 ? ` #${i + 1}` : ''),
      phone: `+1 (${Math.floor(200 + Math.random() * 700)}) ${Math.floor(100 + Math.random() * 899)}-${Math.floor(1000 + Math.random() * 8999)}`,
      company: ['Aura Labs', 'Omni Corp', 'Horizon Logistics', 'Vertex Healthcare'][i % 4],
      status: 'pending' as const,
    }));

    onCreate({
      name: name.trim(),
      description: description.trim() || undefined,
      dialerMode,
      delayBetweenCalls: delaySec,
      callerId,
      totalContacts: sampleContactsCount,
      completedCalls: 0,
      pendingCalls: sampleContactsCount,
      answeredCalls: 0,
      failedCalls: 0,
      progressPercentage: 0,
      status: startImmediately ? 'active' : 'paused',
      contacts: generatedContacts,
      tags: ['New Campaign'],
      duplicateContactsFound: 0,
    });

    setName('');
    setDescription('');
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-white rounded-t-2xl sm:rounded-2xl border border-[#E9EBEF] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="new-campaign-heading"
      >
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#E9EBEF] flex items-center justify-between">
          <div>
            <h2 id="new-campaign-heading" className="text-[16px] font-semibold text-[#17191D]">
              {t.actionCreate}
            </h2>
            <p className="text-[12px] text-[#777E89]">Configure contacts and dialer rules</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#777E89] hover:text-[#17191D] rounded-md transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-[12px] rounded-lg">
              {error}
            </div>
          )}

          {/* Campaign Name */}
          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Campaign Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              placeholder="e.g. Q4 Customer Outreach Wave 1"
              className="w-full h-9 px-3 text-[13px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]/20 text-[#17191D] placeholder:text-[#777E89]"
              autoFocus
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1">
              Description (Optional)
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Objective or special instructions"
              className="w-full h-9 px-3 text-[13px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg focus:outline-none focus:border-[#2563EB] text-[#17191D] placeholder:text-[#777E89]"
            />
          </div>

          {/* Contact Source Selection */}
          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1.5">
              Contact List Source
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setContactSource('csv');
                  setSampleContactsCount(240);
                }}
                className={`p-2.5 rounded-lg border text-left transition-all ${
                  contactSource === 'csv'
                    ? 'border-[#2563EB] bg-blue-50/20 text-[#17191D]'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#777E89]'
                }`}
              >
                <Upload className="w-4 h-4 text-[#2563EB] mb-1" />
                <span className="block text-[12px] font-medium">CSV Import</span>
                <span className="text-[10px] text-[#777E89]">240 verified</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setContactSource('crm');
                  setSampleContactsCount(480);
                }}
                className={`p-2.5 rounded-lg border text-left transition-all ${
                  contactSource === 'crm'
                    ? 'border-[#2563EB] bg-blue-50/20 text-[#17191D]'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#777E89]'
                }`}
              >
                <Layers className="w-4 h-4 text-emerald-600 mb-1" />
                <span className="block text-[12px] font-medium">CRM Sync</span>
                <span className="text-[10px] text-[#777E89]">480 contacts</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setContactSource('contacts');
                  setSampleContactsCount(120);
                }}
                className={`p-2.5 rounded-lg border text-left transition-all ${
                  contactSource === 'contacts'
                    ? 'border-[#2563EB] bg-blue-50/20 text-[#17191D]'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#777E89]'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-600 mb-1" />
                <span className="block text-[12px] font-medium">Phone Book</span>
                <span className="text-[10px] text-[#777E89]">120 group</span>
              </button>
            </div>
          </div>

          {/* Dialer Mode */}
          <div>
            <label className="block text-[12px] font-medium text-[#17191D] mb-1.5">
              Auto-Dialer Algorithm
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDialerMode('rapid')}
                className={`p-2 rounded-lg border text-left transition-all ${
                  dialerMode === 'rapid'
                    ? 'border-[#17191D] bg-neutral-900 text-white'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#17191D]'
                }`}
              >
                <span className="block text-[12px] font-medium">Rapid Mode</span>
                <span className={`text-[10px] ${dialerMode === 'rapid' ? 'text-neutral-300' : 'text-[#777E89]'}`}>
                  Next on hangup
                </span>
              </button>

              <button
                type="button"
                onClick={() => setDialerMode('predictive')}
                className={`p-2 rounded-lg border text-left transition-all ${
                  dialerMode === 'predictive'
                    ? 'border-[#17191D] bg-neutral-900 text-white'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#17191D]'
                }`}
              >
                <span className="block text-[12px] font-medium">Predictive</span>
                <span className={`text-[10px] ${dialerMode === 'predictive' ? 'text-neutral-300' : 'text-[#777E89]'}`}>
                  Smart pacing
                </span>
              </button>

              <button
                type="button"
                onClick={() => setDialerMode('preview')}
                className={`p-2 rounded-lg border text-left transition-all ${
                  dialerMode === 'preview'
                    ? 'border-[#17191D] bg-neutral-900 text-white'
                    : 'border-[#E9EBEF] hover:bg-[#F7F8FA] text-[#17191D]'
                }`}
              >
                <span className="block text-[12px] font-medium">Preview</span>
                <span className={`text-[10px] ${dialerMode === 'preview' ? 'text-neutral-300' : 'text-[#777E89]'}`}>
                  Manual review
                </span>
              </button>
            </div>
          </div>

          {/* Delay Between Calls & Caller ID */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[12px] font-medium text-[#17191D] mb-1">
                Interval Between Calls
              </label>
              <select
                value={delaySec}
                onChange={(e) => setDelaySec(Number(e.target.value))}
                className="w-full h-9 px-2 text-[12.5px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D]"
              >
                <option value={2}>2 seconds</option>
                <option value={4}>4 seconds (Standard)</option>
                <option value={6}>6 seconds</option>
                <option value={10}>10 seconds</option>
              </select>
            </div>

            <div>
              <label className="block text-[12px] font-medium text-[#17191D] mb-1">
                Outbound Caller ID
              </label>
              <select
                value={callerId}
                onChange={(e) => setCallerId(e.target.value)}
                className="w-full h-9 px-2 text-[12.5px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D]"
              >
                <option value="+1 (800) 555-0199">+1 (800) 555-0199 (HQ)</option>
                <option value="+1 (888) 424-9090">+1 (888) 424-9090 (Support)</option>
                <option value="+1 (415) 309-8812">+1 (415) 309-8812 (Direct)</option>
              </select>
            </div>
          </div>

          {/* Start immediately toggle */}
          <div className="pt-2 flex items-center justify-between text-[12.5px]">
            <span className="text-[#17191D] font-medium">Activate campaign upon creation</span>
            <input
              type="checkbox"
              checked={startImmediately}
              onChange={(e) => setStartImmediately(e.target.checked)}
              className="w-4 h-4 accent-[#2563EB] rounded cursor-pointer"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-3 border-t border-[#E9EBEF] flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[12.5px] font-medium text-[#777E89] hover:text-[#17191D] hover:bg-[#F7F8FA] rounded-lg transition-colors"
            >
              {t.actionCancel}
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-[12.5px] font-medium bg-[#17191D] text-white hover:bg-neutral-800 rounded-lg transition-colors"
            >
              {t.actionCreate}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
