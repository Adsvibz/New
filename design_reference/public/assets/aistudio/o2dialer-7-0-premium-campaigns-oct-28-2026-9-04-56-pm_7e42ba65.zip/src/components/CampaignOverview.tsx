import React from 'react';
import { CampaignOverviewStats } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface CampaignOverviewProps {
  stats: CampaignOverviewStats;
  t: Translations;
}

export const CampaignOverview: React.FC<CampaignOverviewProps> = ({ stats, t }) => {
  return (
    <section className="px-6 pt-1 pb-4 bg-white" aria-label="Overview Statistics">
      {/* 4 Clean, unboxed metric points with generous breathing room */}
      <div className="grid grid-cols-4 gap-2 py-3 border-y border-[#F0F2F5]">
        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statTotalCampaigns}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {stats.totalCampaigns}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statTotalContacts}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {stats.totalContacts.toLocaleString()}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statCompletedCalls}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {stats.completedCalls.toLocaleString()}
          </span>
        </div>

        <div>
          <span className="block text-[11px] font-medium text-[#8E95A2] tracking-tight">
            {t.statPendingCalls}
          </span>
          <span className="block text-[18px] font-semibold text-[#111827] tabular-nums tracking-tight mt-0.5">
            {stats.pendingCalls.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Understated progress indicator */}
      <div className="pt-2.5 flex items-center justify-between text-[11.5px] text-[#8E95A2]">
        <span>
          <strong className="text-[#111827] font-medium tabular-nums">{stats.overallProgress}%</strong> completed
        </span>
        <div className="w-28 h-1 bg-[#F0F2F5] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#111827] rounded-full transition-all duration-300"
            style={{ width: `${Math.min(100, Math.max(0, stats.overallProgress))}%` }}
          />
        </div>
      </div>
    </section>
  );
};
