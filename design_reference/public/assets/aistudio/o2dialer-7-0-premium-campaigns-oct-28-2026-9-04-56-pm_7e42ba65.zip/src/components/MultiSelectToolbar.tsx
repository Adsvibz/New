import React from 'react';
import { Trash2, Pause, Play, Share2, CheckSquare, X } from 'lucide-react';
import { Translations } from '../i18n/translations';

interface MultiSelectToolbarProps {
  selectedCount: number;
  totalCount: number;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onBulkDelete: () => void;
  onBulkPause: () => void;
  onBulkResume: () => void;
  onBulkShare: () => void;
  onCancel: () => void;
  t: Translations;
}

export const MultiSelectToolbar: React.FC<MultiSelectToolbarProps> = ({
  selectedCount,
  totalCount,
  onSelectAll,
  onDeselectAll,
  onBulkDelete,
  onBulkPause,
  onBulkResume,
  onBulkShare,
  onCancel,
  t,
}) => {
  const isAllSelected = selectedCount > 0 && selectedCount === totalCount;

  return (
    <div className="sticky top-0 z-20 px-5 py-2.5 bg-neutral-900 text-white border-b border-neutral-800 shadow-md flex items-center justify-between gap-2">
      {/* Selection count & select/deselect all */}
      <div className="flex items-center gap-3">
        <button
          onClick={onCancel}
          className="p-1 text-neutral-400 hover:text-white rounded-md transition-colors"
          aria-label="Cancel selection"
        >
          <X className="w-4 h-4" />
        </button>
        <span className="text-[13px] font-semibold tabular-nums">
          {t.selectedCount(selectedCount)}
        </span>
        <button
          onClick={isAllSelected ? onDeselectAll : onSelectAll}
          className="text-[11.5px] text-blue-400 hover:text-blue-300 font-medium ml-1 transition-colors"
        >
          {isAllSelected ? t.deselectAll : t.selectAll}
        </button>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={onBulkResume}
          disabled={selectedCount === 0}
          className="p-1.5 text-neutral-300 hover:text-white hover:bg-neutral-800 disabled:opacity-40 disabled:pointer-events-none rounded-md transition-colors"
          title={t.bulkResume}
          aria-label={t.bulkResume}
        >
          <Play className="w-4 h-4 fill-current" />
        </button>
        <button
          onClick={onBulkPause}
          disabled={selectedCount === 0}
          className="p-1.5 text-neutral-300 hover:text-white hover:bg-neutral-800 disabled:opacity-40 disabled:pointer-events-none rounded-md transition-colors"
          title={t.bulkPause}
          aria-label={t.bulkPause}
        >
          <Pause className="w-4 h-4 fill-current" />
        </button>
        <button
          onClick={onBulkShare}
          disabled={selectedCount === 0}
          className="p-1.5 text-neutral-300 hover:text-white hover:bg-neutral-800 disabled:opacity-40 disabled:pointer-events-none rounded-md transition-colors"
          title={t.bulkShare}
          aria-label={t.bulkShare}
        >
          <Share2 className="w-4 h-4" />
        </button>
        <button
          onClick={onBulkDelete}
          disabled={selectedCount === 0}
          className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-950/40 disabled:opacity-40 disabled:pointer-events-none rounded-md transition-colors ml-1"
          title={t.bulkDelete}
          aria-label={t.bulkDelete}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
