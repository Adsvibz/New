import React from 'react';

export const AndroidNavBar: React.FC = () => {
  return (
    <div className="w-full py-2 flex items-center justify-center select-none bg-white">
      <div className="w-28 h-1 bg-neutral-300 rounded-full transition-colors hover:bg-neutral-400" />
    </div>
  );
};
