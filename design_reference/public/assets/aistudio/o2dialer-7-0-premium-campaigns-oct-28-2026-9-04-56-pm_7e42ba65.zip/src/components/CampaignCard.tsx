import React, { useState, useRef, useEffect } from 'react';
import {
  MoreHorizontal,
  Edit2,
  Trash2,
  Share2,
  RotateCcw,
  Users2,
  BarChart3,
  Check,
  Play,
  Pause,
} from 'lucide-react';
import { Campaign } from '../types/campaign';
import { Translations } from '../i18n/translations';
import { formatTimeAgo } from '../utils/campaignLogic';

interface CampaignCardProps {
  campaign: Campaign;
  isSelected: boolean;
  isMultiSelectMode: boolean;
  onToggleSelect: (id: string) => void;
  onOpenDetails: (campaign: Campaign) => void;
  onEdit: (campaign: Campaign) => void;
  onRename: (campaign: Campaign) => void;
  onTogglePlayPause: (campaign: Campaign) => void;
  onResetProgress: (campaign: Campaign) => void;
  onRemoveDuplicates: (campaign: Campaign) => void;
  onViewReport: (campaign: Campaign) => void;
  onShare: (campaign: Campaign) => void;
  onDelete: (campaign: Campaign) => void;
  t: Translations;
}

export const CampaignCard: React.FC<CampaignCardProps> = ({
  campaign,
  isSelected,
  isMultiSelectMode,
  onToggleSelect,
  onOpenDetails,
  onEdit,
  onRename,
  onTogglePlayPause,
  onResetProgress,
  onRemoveDuplicates,
  onViewReport,
  onShare,
  onDelete,
  t,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [menuOpen]);

  const handleTouchStart = () => {
    longPressTimerRef.current = setTimeout(() => {
      onToggleSelect(campaign.id);
    }, 450);
  };

  const handleTouchEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
  };

  const getStatusBadge = () => {
    switch (campaign.status) {
      case 'active':
        return (
          <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
            {t.statusActive}
          </span>
        );
      case 'paused':
        return (
          <span className="text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
            {t.statusPaused}
          </span>
        );
      case 'completed':
        return (
          <span className="text-[11px] font-medium text-neutral-600 bg-neutral-100 px-2 py-0.5 rounded-full">
            {t.statusCompleted}
          </span>
        );
      case 'scheduled':
        return (
          <span className="text-[11px] font-medium text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">
            {t.statusScheduled}
          </span>
        );
    }
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onClick={() => {
        if (isMultiSelectMode) {
          onToggleSelect(campaign.id);
        } else {
          onOpenDetails(campaign);
        }
      }}
      className={`group relative bg-white border rounded-2xl p-4 sm:p-5 transition-all duration-150 cursor-pointer select-none ${
        isSelected
          ? 'border-[#111827] ring-1 ring-[#111827]/10 bg-neutral-50/40'
          : 'border-[#EBECEF] hover:border-neutral-300'
      }`}
    >
      {/* Top Line: Name, Status & Overflow */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          {/* Checkbox (Multi-select) */}
          {isMultiSelectMode && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSelect(campaign.id);
              }}
              className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                isSelected
                  ? 'bg-[#111827] border-[#111827] text-white'
                  : 'bg-white border-[#D1D5DB]'
              }`}
              aria-label={`Select ${campaign.name}`}
            >
              {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
            </button>
          )}

          <h3 className="text-[15px] font-semibold text-[#111827] tracking-tight truncate">
            {campaign.name}
          </h3>

          <div className="shrink-0">{getStatusBadge()}</div>
        </div>

        {/* Discreet Overflow Trigger */}
        <div className="relative shrink-0" ref={menuRef}>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen(!menuOpen);
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#8E95A2] hover:text-[#111827] hover:bg-[#F4F5F7] transition-colors"
            aria-label="More options"
          >
            <MoreHorizontal className="w-4 h-4 stroke-[1.8]" />
          </button>

          {/* Clean Overflow Dropdown */}
          {menuOpen && (
            <div
              className="absolute right-0 top-full mt-1 w-52 bg-white border border-[#EBECEF] rounded-2xl shadow-xl py-1.5 z-30 divide-y divide-[#F0F2F5]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="py-1">
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onOpenDetails(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  <BarChart3 className="w-4 h-4 text-[#8E95A2]" />
                  <span>{t.campaignDetails}</span>
                </button>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onTogglePlayPause(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  {campaign.status === 'active' ? (
                    <>
                      <Pause className="w-4 h-4 text-[#8E95A2]" />
                      <span>{t.actionPause}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 text-[#8E95A2]" />
                      <span>{t.actionResume}</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onEdit(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  <Edit2 className="w-4 h-4 text-[#8E95A2]" />
                  <span>{t.actionEdit}</span>
                </button>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onRename(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  <Edit2 className="w-4 h-4 text-[#8E95A2]" />
                  <span>{t.actionRename}</span>
                </button>
              </div>

              <div className="py-1">
                {campaign.duplicateContactsFound > 0 && (
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onRemoveDuplicates(campaign);
                    }}
                    className="w-full px-3.5 py-1.5 text-[12.5px] text-amber-700 hover:bg-amber-50/60 flex items-center gap-2.5 text-left"
                  >
                    <Users2 className="w-4 h-4 text-amber-600" />
                    <span>{t.actionRemoveDuplicates} ({campaign.duplicateContactsFound})</span>
                  </button>
                )}
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onResetProgress(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  <RotateCcw className="w-4 h-4 text-[#8E95A2]" />
                  <span>{t.actionReset}</span>
                </button>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onShare(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-[#111827] hover:bg-[#F4F5F7] flex items-center gap-2.5 text-left"
                >
                  <Share2 className="w-4 h-4 text-[#8E95A2]" />
                  <span>{t.actionShare}</span>
                </button>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onDelete(campaign);
                  }}
                  className="w-full px-3.5 py-1.5 text-[12.5px] text-red-600 hover:bg-red-50 flex items-center gap-2.5 text-left"
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                  <span>{t.actionDelete}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Calling Progress Strip */}
      <div className="mt-3.5">
        <div className="flex items-center justify-between text-[12.5px]">
          <span className="text-[#6B7280] font-normal tabular-nums">
            {campaign.completedCalls.toLocaleString()} of {campaign.totalContacts.toLocaleString()} calls
          </span>
          <span className="text-[#111827] font-semibold tabular-nums text-[13px]">
            {campaign.progressPercentage}%
          </span>
        </div>

        {/* Precision Modern Progress Line */}
        <div className="w-full h-1 bg-[#F0F2F5] rounded-full overflow-hidden mt-1.5 mb-2">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              campaign.status === 'completed'
                ? 'bg-neutral-600'
                : campaign.status === 'paused'
                ? 'bg-amber-500'
                : 'bg-[#111827]'
            }`}
            style={{ width: `${Math.min(100, Math.max(0, campaign.progressPercentage))}%` }}
          />
        </div>
      </div>

      {/* Footer Metadata */}
      <div className="flex items-center justify-between text-[11.5px] text-[#8E95A2] pt-1">
        <div className="flex items-center gap-1.5 truncate">
          <span className="capitalize">{campaign.dialerMode} dialer</span>
          {campaign.callerId && (
            <>
              <span aria-hidden="true" className="text-neutral-300">·</span>
              <span className="font-mono tabular-nums text-[11px] truncate">{campaign.callerId}</span>
            </>
          )}
        </div>
        <div className="shrink-0 tabular-nums">
          {formatTimeAgo(campaign.lastActivity)}
        </div>
      </div>
    </div>
  );
};
