import React from 'react';
import { X, Download, Share2, Check, BarChart2 } from 'lucide-react';
import { Campaign } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface CampaignReportModalProps {
  campaign: Campaign | null;
  isOpen: boolean;
  onClose: () => void;
  onExportCsv: () => void;
  t: Translations;
}

export const CampaignReportModal: React.FC<CampaignReportModalProps> = ({
  campaign,
  isOpen,
  onClose,
  onExportCsv,
  t,
}) => {
  if (!isOpen || !campaign) return null;

  const connectedPercent =
    campaign.completedCalls > 0
      ? Math.round((campaign.answeredCalls / campaign.completedCalls) * 100)
      : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-white rounded-2xl border border-[#E9EBEF] shadow-2xl p-5"
        role="dialog"
        aria-modal="true"
        aria-labelledby="report-modal-heading"
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#E9EBEF]">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-[#2563EB]" />
            <h3 id="report-modal-heading" className="text-[15px] font-semibold text-[#17191D]">
              Campaign Analytics & Results
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#777E89] hover:text-[#17191D] rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-4 space-y-4">
          <div>
            <h4 className="text-[14px] font-semibold text-[#17191D]">{campaign.name}</h4>
            <p className="text-[12px] text-[#777E89]">{campaign.tags.join(' · ')}</p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-2.5 bg-[#F7F8FA] rounded-lg border border-[#E9EBEF]">
              <span className="text-[10.5px] font-medium text-[#777E89] uppercase">Total Contacts</span>
              <div className="text-[18px] font-bold text-[#17191D] tabular-nums">{campaign.totalContacts}</div>
            </div>
            <div className="p-2.5 bg-[#F7F8FA] rounded-lg border border-[#E9EBEF]">
              <span className="text-[10.5px] font-medium text-[#777E89] uppercase">Completed Calls</span>
              <div className="text-[18px] font-bold text-[#17191D] tabular-nums">{campaign.completedCalls}</div>
            </div>
            <div className="p-2.5 bg-[#F7F8FA] rounded-lg border border-[#E9EBEF]">
              <span className="text-[10.5px] font-medium text-[#777E89] uppercase">Answered Rate</span>
              <div className="text-[18px] font-bold text-emerald-600 tabular-nums">{connectedPercent}%</div>
            </div>
            <div className="p-2.5 bg-[#F7F8FA] rounded-lg border border-[#E9EBEF]">
              <span className="text-[10.5px] font-medium text-[#777E89] uppercase">Dialer Algorithm</span>
              <div className="text-[14px] font-semibold text-[#17191D] capitalize mt-0.5">{campaign.dialerMode}</div>
            </div>
          </div>

          <div className="text-[12px] text-[#777E89] bg-[#F7F8FA] p-3 rounded-lg border border-[#E9EBEF]">
            <p>
              Auto-dialer pacing: <strong>{campaign.delayBetweenCalls}s</strong> interval. Outbound caller identification verified via carrier route.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#E9EBEF]">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-[12px] font-medium text-[#777E89] hover:text-[#17191D] rounded-lg"
          >
            Close
          </button>
          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-[12px] font-medium bg-[#17191D] hover:bg-neutral-800 text-white rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};
