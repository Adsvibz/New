import React from 'react';
import { Phone, Users, Megaphone, Clock, Settings } from 'lucide-react';
import { Translations } from '../i18n/translations';

export type NavTab = 'dialer' | 'contacts' | 'campaigns' | 'history' | 'settings';

interface FloatingBottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  t: Translations;
  badgeCount?: number;
}

export const FloatingBottomNav: React.FC<FloatingBottomNavProps> = ({
  currentTab,
  onSelectTab,
  t,
  badgeCount = 0,
}) => {
  const tabs = [
    { id: 'dialer' as const, label: t.navKeypad, icon: Phone },
    { id: 'contacts' as const, label: t.navContacts, icon: Users },
    { id: 'campaigns' as const, label: t.navCampaigns, icon: Megaphone, badge: badgeCount },
    { id: 'history' as const, label: t.navHistory, icon: Clock },
    { id: 'settings' as const, label: t.navSettings, icon: Settings },
  ];

  return (
    <nav
      className="w-full px-6 py-2 bg-white/95 backdrop-blur-md border-t border-[#F0F2F5]"
      aria-label="Application Navigation"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 gap-1">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 rounded-xl transition-all duration-150 min-h-[44px] ${
                isActive ? 'text-[#111827]' : 'text-[#9CA3AF] hover:text-[#4B5563]'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-[19px] h-[19px] transition-transform duration-150 ${
                    isActive ? 'stroke-[2.2] text-[#111827]' : 'stroke-[1.6]'
                  }`}
                />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 px-1 min-w-[13px] h-[13px] bg-[#111827] text-white text-[9px] font-bold rounded-full flex items-center justify-center tabular-nums leading-none">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] mt-1 tracking-tight leading-none ${isActive ? 'font-semibold text-[#111827]' : 'font-normal text-[#9CA3AF]'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
