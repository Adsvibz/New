import React, { useState } from 'react';
import { X, Copy, Check, Share2 } from 'lucide-react';
import { Campaign } from '../types/campaign';
import { Translations } from '../i18n/translations';

interface ShareCampaignModalProps {
  campaign: Campaign | null;
  isOpen: boolean;
  onClose: () => void;
  onCopied: () => void;
  t: Translations;
}

export const ShareCampaignModal: React.FC<ShareCampaignModalProps> = ({
  campaign,
  isOpen,
  onClose,
  onCopied,
  t,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !campaign) return null;

  const exportSummary = `O2Dialer Campaign: ${campaign.name}
Status: ${campaign.status.toUpperCase()}
Contacts: ${campaign.totalContacts} (${campaign.completedCalls} completed, ${campaign.pendingCalls} pending)
Progress: ${campaign.progressPercentage}%
Dialer Mode: ${campaign.dialerMode}
Caller ID: ${campaign.callerId || 'None'}
Generated via O2Dialer 7.0`;

  const handleCopy = () => {
    navigator.clipboard?.writeText(exportSummary);
    setCopied(true);
    onCopied();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div
        className="w-full max-w-sm bg-white rounded-2xl border border-[#E9EBEF] shadow-2xl p-5"
        role="dialog"
        aria-modal="true"
        aria-labelledby="share-dialog-title"
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#E9EBEF]">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-[#2563EB]" />
            <h3 id="share-dialog-title" className="text-[15px] font-semibold text-[#17191D]">
              {t.actionShare}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#777E89] hover:text-[#17191D] rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-3">
          <p className="text-[12px] text-[#777E89] mb-2">
            Copy summary for your team or export campaign parameters:
          </p>
          <pre className="p-3 bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[11px] font-mono text-[#17191D] whitespace-pre-wrap select-all">
            {exportSummary}
          </pre>
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E9EBEF]">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-[12px] font-medium text-[#777E89] hover:text-[#17191D] rounded-lg"
          >
            Close
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-[12px] font-medium bg-[#17191D] hover:bg-neutral-800 text-white rounded-lg transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Summary'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
