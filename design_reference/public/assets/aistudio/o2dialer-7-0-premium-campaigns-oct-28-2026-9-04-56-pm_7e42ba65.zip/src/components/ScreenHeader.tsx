import React from 'react';
import { Plus, CheckSquare, Globe } from 'lucide-react';
import { Translations, Language } from '../i18n/translations';

interface ScreenHeaderProps {
  t: Translations;
  currentLanguage: Language;
  onToggleLanguage: () => void;
  campaignCount: number;
  contactCount: number;
  onNewCampaign: () => void;
  isMultiSelectMode: boolean;
  onToggleMultiSelect: () => void;
}

export const ScreenHeader: React.FC<ScreenHeaderProps> = ({
  t,
  currentLanguage,
  onToggleLanguage,
  campaignCount,
  contactCount,
  onNewCampaign,
  isMultiSelectMode,
  onToggleMultiSelect,
}) => {
  return (
    <header className="px-6 pt-5 pb-3 bg-white">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-semibold tracking-tight text-[#111827] leading-none">
            {t.campaignsTitle}
          </h1>
          <p className="text-[12.5px] text-[#8E95A2] mt-1.5 font-normal tabular-nums">
            {t.campaignsCount(campaignCount, contactCount)}
          </p>
        </div>

        <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
          {/* Subtle Language switcher */}
          <button
            onClick={onToggleLanguage}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#8E95A2] hover:text-[#111827] hover:bg-[#F4F5F7] transition-colors"
            title={currentLanguage === 'en' ? 'العربية' : 'English'}
            aria-label="Toggle language"
          >
            <Globe className="w-4 h-4 stroke-[1.8]" />
          </button>

          {/* Select mode toggle */}
          <button
            onClick={onToggleMultiSelect}
            className={`h-8 px-2.5 rounded-full text-[12px] font-medium transition-colors flex items-center gap-1.5 ${
              isMultiSelectMode
                ? 'bg-[#111827] text-white'
                : 'text-[#6B7280] hover:text-[#111827] hover:bg-[#F4F5F7]'
            }`}
            aria-label="Select campaigns"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">{t.actionSelect}</span>
          </button>

          {/* Clean, understated + New Campaign CTA */}
          <button
            onClick={onNewCampaign}
            className="h-8 px-3 rounded-full text-[12px] font-medium bg-[#111827] text-white hover:bg-neutral-800 active:scale-[0.98] transition-all flex items-center gap-1 shadow-xs"
            aria-label="Create new campaign"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{t.newCampaign.replace('+ ', '')}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
