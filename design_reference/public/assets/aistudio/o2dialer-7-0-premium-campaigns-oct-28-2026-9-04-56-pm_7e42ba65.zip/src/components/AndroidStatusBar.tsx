import React from 'react';
import { Wifi, Signal } from 'lucide-react';

interface AndroidStatusBarProps {
  isRtl?: boolean;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = () => {
  return (
    <div
      className="w-full px-6 pt-3.5 pb-2 flex items-center justify-between text-[#111827] text-[12px] font-medium tracking-tight select-none bg-white"
      dir="ltr"
      aria-label="Android System Status Bar"
    >
      <div className="font-semibold text-[#111827] tabular-nums">
        09:41
      </div>

      <div className="flex items-center gap-2 text-[#4B5563]">
        <Signal className="w-3.5 h-3.5 stroke-[2]" />
        <Wifi className="w-3.5 h-3.5 stroke-[2]" />
        <div className="w-5 h-2.5 rounded-[3px] border border-[#111827] p-[1.5px] flex items-center ml-0.5">
          <div className="w-3.5 h-full bg-[#111827] rounded-[1.5px]" />
        </div>
      </div>
    </div>
  );
};
