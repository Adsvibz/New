import React, { useState } from 'react';
import {
  X,
  Edit2,
  Play,
  Pause,
  PhoneCall,
  CheckCircle2,
  Clock,
  AlertCircle,
  PhoneForwarded,
  Search,
  RotateCcw,
  Users,
} from 'lucide-react';
import { Campaign, CampaignContact } from '../types/campaign';
import { Translations } from '../i18n/translations';
import { formatDuration } from '../utils/campaignLogic';

interface CampaignDetailModalProps {
  campaign: Campaign | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (campaign: Campaign) => void;
  onResetProgress: (campaign: Campaign) => void;
  onSimulateCall: (campaign: Campaign) => void;
  onLaunchDialerSession?: (campaign: Campaign) => void;
  t: Translations;
}

export const CampaignDetailModal: React.FC<CampaignDetailModalProps> = ({
  campaign,
  isOpen,
  onClose,
  onEdit,
  onResetProgress,
  onSimulateCall,
  onLaunchDialerSession,
  t,
}) => {
  const [contactSearch, setContactSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'contacts' | 'performance'>('contacts');

  if (!isOpen || !campaign) return null;

  const answeredRate =
    campaign.completedCalls > 0
      ? Math.round((campaign.answeredCalls / campaign.completedCalls) * 100)
      : 0;
  const unreachableRate =
    campaign.completedCalls > 0
      ? Math.round((campaign.failedCalls / campaign.completedCalls) * 100)
      : 0;

  // Filter contacts
  const filteredContacts = campaign.contacts.filter((c) => {
    if (!contactSearch) return true;
    const q = contactSearch.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      (c.company && c.company.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
      <div
        className="w-full max-w-xl bg-white rounded-t-2xl sm:rounded-2xl border border-[#E9EBEF] shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="campaign-detail-heading"
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-[#E9EBEF] flex items-center justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2
                id="campaign-detail-heading"
                className="text-[17px] font-semibold text-[#17191D] truncate tracking-tight"
              >
                {campaign.name}
              </h2>
              <span
                className={`text-[11px] font-medium px-2 py-0.5 rounded-md capitalize ${
                  campaign.status === 'active'
                    ? 'text-emerald-700 bg-emerald-50'
                    : campaign.status === 'paused'
                    ? 'text-amber-700 bg-amber-50'
                    : 'text-neutral-600 bg-neutral-100'
                }`}
              >
                {campaign.status}
              </span>
            </div>
            {campaign.description && (
              <p className="text-[12px] text-[#777E89] truncate mt-0.5">
                {campaign.description}
              </p>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => onEdit(campaign)}
              className="flex items-center gap-1 px-2.5 py-1.5 text-[12px] font-medium text-[#17191D] hover:bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg transition-colors"
              aria-label="Edit campaign"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{t.actionEdit}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-[#777E89] hover:text-[#17191D] rounded-md transition-colors"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab switchers: Overview KPIs vs Contact Roster */}
        <div className="px-5 pt-3 pb-2 flex items-center justify-between border-b border-[#E9EBEF]/60">
          <div className="flex items-center gap-1 p-0.5 bg-[#F7F8FA] rounded-lg">
            <button
              onClick={() => setActiveTab('contacts')}
              className={`px-3 py-1 text-[12px] font-medium rounded-md transition-colors ${
                activeTab === 'contacts'
                  ? 'bg-white text-[#17191D] shadow-xs'
                  : 'text-[#777E89] hover:text-[#17191D]'
              }`}
            >
              {t.contactList} ({campaign.contacts.length})
            </button>
            <button
              onClick={() => setActiveTab('performance')}
              className={`px-3 py-1 text-[12px] font-medium rounded-md transition-colors ${
                activeTab === 'performance'
                  ? 'bg-white text-[#17191D] shadow-xs'
                  : 'text-[#777E89] hover:text-[#17191D]'
              }`}
            >
              {t.performanceMetrics}
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {onLaunchDialerSession && campaign.pendingCalls > 0 && (
              <button
                onClick={() => {
                  onLaunchDialerSession(campaign);
                  onClose();
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 text-[11.5px] font-medium bg-[#111827] text-white hover:bg-neutral-800 rounded-md transition-colors"
                title="Launch Live Auto-Dialer session"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Launch Dialer</span>
              </button>
            )}

            {/* Quick Simulate Call Button */}
            {campaign.pendingCalls > 0 && (
              <button
                onClick={() => onSimulateCall(campaign)}
                className="flex items-center gap-1.5 px-2 py-1 text-[11.5px] font-medium text-[#4B5563] hover:text-[#111827] hover:bg-[#F4F5F7] rounded-md transition-colors"
                title="Simulate placing next call in sequence"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>{t.actionSimulateCall}</span>
              </button>
            )}
          </div>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto flex-1 p-5 space-y-4">
          {activeTab === 'performance' ? (
            <div className="space-y-4">
              {/* Progress Bar Strip */}
              <div className="p-3.5 bg-[#F7F8FA] border border-[#E9EBEF] rounded-xl space-y-2">
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="font-medium text-[#17191D]">Calling Progress</span>
                  <span className="font-semibold text-[#17191D] tabular-nums">
                    {campaign.completedCalls} / {campaign.totalContacts} ({campaign.progressPercentage}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-[#E9EBEF] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#2563EB] rounded-full transition-all duration-300"
                    style={{ width: `${campaign.progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* 4 Performance KPI boxes */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-[#F7F8FA] border border-[#E9EBEF] rounded-xl">
                  <span className="block text-[11px] font-medium text-[#777E89] uppercase tracking-wider mb-1">
                    {t.answeredRate}
                  </span>
                  <div className="text-[20px] font-semibold text-[#17191D] tabular-nums">
                    {answeredRate}%
                  </div>
                  <span className="text-[11px] text-[#777E89]">
                    {campaign.answeredCalls} calls connected
                  </span>
                </div>

                <div className="p-3 bg-[#F7F8FA] border border-[#E9EBEF] rounded-xl">
                  <span className="block text-[11px] font-medium text-[#777E89] uppercase tracking-wider mb-1">
                    {t.failedRate}
                  </span>
                  <div className="text-[20px] font-semibold text-[#17191D] tabular-nums">
                    {unreachableRate}%
                  </div>
                  <span className="text-[11px] text-[#777E89]">
                    {campaign.failedCalls} busy / no answer
                  </span>
                </div>

                <div className="p-3 bg-[#F7F8FA] border border-[#E9EBEF] rounded-xl">
                  <span className="block text-[11px] font-medium text-[#777E89] uppercase tracking-wider mb-1">
                    {t.avgDuration}
                  </span>
                  <div className="text-[20px] font-semibold text-[#17191D] tabular-nums">
                    2m 14s
                  </div>
                  <span className="text-[11px] text-[#777E89]">
                    Across connected calls
                  </span>
                </div>

                <div className="p-3 bg-[#F7F8FA] border border-[#E9EBEF] rounded-xl">
                  <span className="block text-[11px] font-medium text-[#777E89] uppercase tracking-wider mb-1">
                    Configuration
                  </span>
                  <div className="text-[15px] font-semibold text-[#17191D] capitalize">
                    {campaign.dialerMode}
                  </div>
                  <span className="text-[11px] text-[#777E89]">
                    Interval: {campaign.delayBetweenCalls}s
                  </span>
                </div>
              </div>

              {/* Reset progress action */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => onResetProgress(campaign)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium text-[#777E89] hover:text-[#17191D] border border-[#E9EBEF] rounded-lg hover:bg-[#F7F8FA] transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{t.actionReset}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Search contacts filter */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#777E89]" />
                <input
                  type="text"
                  value={contactSearch}
                  onChange={(e) => setContactSearch(e.target.value)}
                  placeholder="Search contacts in this campaign..."
                  className="w-full h-8 pl-8 pr-3 text-[12.5px] bg-[#F7F8FA] border border-[#E9EBEF] rounded-lg text-[#17191D] placeholder:text-[#777E89] focus:outline-none focus:border-[#2563EB]"
                />
              </div>

              {/* Contacts list */}
              <div className="divide-y divide-[#E9EBEF]/70 border border-[#E9EBEF] rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                {filteredContacts.length === 0 ? (
                  <div className="p-6 text-center text-[#777E89] text-[12.5px]">
                    No contacts found matching search query.
                  </div>
                ) : (
                  filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="p-3 bg-white hover:bg-[#F7F8FA] flex items-center justify-between gap-3 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[13px] font-medium text-[#17191D] truncate">
                            {contact.name}
                          </span>
                          {contact.company && (
                            <span className="text-[11px] text-[#777E89] truncate">
                              · {contact.company}
                            </span>
                          )}
                        </div>
                        <div className="text-[11.5px] text-[#777E89] font-mono tabular-nums">
                          {contact.phone}
                        </div>
                      </div>

                      {/* Status & duration */}
                      <div className="text-right shrink-0">
                        <span
                          className={`inline-block text-[11px] font-medium px-2 py-0.5 rounded-md capitalize ${
                            contact.status === 'completed'
                              ? 'bg-emerald-50 text-emerald-700'
                              : contact.status === 'busy' || contact.status === 'failed'
                              ? 'bg-red-50 text-red-700'
                              : 'bg-neutral-100 text-neutral-600'
                          }`}
                        >
                          {contact.status}
                        </span>
                        {contact.callDurationSeconds !== undefined && (
                          <div className="text-[10.5px] text-[#777E89] tabular-nums mt-0.5">
                            {formatDuration(contact.callDurationSeconds)}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#E9EBEF] flex items-center justify-between bg-[#F7F8FA]">
          <span className="text-[11.5px] text-[#777E89]">
            Outbound ID: <strong className="font-mono text-[#17191D]">{campaign.callerId || 'Default'}</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-[12.5px] font-medium bg-[#17191D] text-white hover:bg-neutral-800 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
