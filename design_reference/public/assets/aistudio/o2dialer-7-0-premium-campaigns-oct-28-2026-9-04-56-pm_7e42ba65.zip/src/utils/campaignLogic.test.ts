import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateOverviewStats,
  filterAndSortCampaigns,
  removeDuplicateContacts,
  resetCampaignProgress,
  formatDuration,
} from './campaignLogic';
import { Campaign } from '../types/campaign';

const sampleCampaigns: Campaign[] = [
  {
    id: 'camp-1',
    name: 'Enterprise VIP Outbound Q4',
    status: 'active',
    totalContacts: 100,
    completedCalls: 65,
    pendingCalls: 35,
    answeredCalls: 48,
    failedCalls: 17,
    progressPercentage: 65,
    createdAt: '2026-10-01T08:00:00.000Z',
    lastActivity: '2026-10-28T09:00:00.000Z',
    dialerMode: 'rapid',
    delayBetweenCalls: 5,
    duplicateContactsFound: 3,
    tags: ['vip', 'enterprise'],
    contacts: [
      { id: '1', name: 'John Doe', phone: '+15551234567', status: 'completed', callDurationSeconds: 120 },
      { id: '2', name: 'Jane Smith', phone: '+15559876543', status: 'pending' },
      { id: '3', name: 'John Duplicate', phone: '+1 555-123-4567', status: 'pending' }, // duplicate
    ],
  },
  {
    id: 'camp-2',
    name: 'Healthcare Follow-up Wave 2',
    status: 'completed',
    totalContacts: 50,
    completedCalls: 50,
    pendingCalls: 0,
    answeredCalls: 42,
    failedCalls: 8,
    progressPercentage: 100,
    createdAt: '2026-10-10T10:00:00.000Z',
    lastActivity: '2026-10-25T14:30:00.000Z',
    dialerMode: 'predictive',
    delayBetweenCalls: 3,
    duplicateContactsFound: 0,
    tags: ['healthcare', 'followup'],
    contacts: [],
  },
  {
    id: 'camp-3',
    name: 'SaaS Renewal Reminders',
    status: 'paused',
    totalContacts: 80,
    completedCalls: 20,
    pendingCalls: 60,
    answeredCalls: 15,
    failedCalls: 5,
    progressPercentage: 25,
    createdAt: '2026-10-15T12:00:00.000Z',
    lastActivity: '2026-10-20T11:00:00.000Z',
    dialerMode: 'preview',
    delayBetweenCalls: 10,
    duplicateContactsFound: 0,
    tags: ['renewals'],
    contacts: [],
  },
];

test('calculateOverviewStats correctly aggregates total metrics', () => {
  const stats = calculateOverviewStats(sampleCampaigns);
  assert.equal(stats.totalCampaigns, 3);
  assert.equal(stats.totalContacts, 230);
  assert.equal(stats.completedCalls, 135);
  assert.equal(stats.pendingCalls, 95);
  assert.equal(stats.activeCount, 1);
  assert.equal(stats.completedCount, 1);
  assert.equal(stats.pausedCount, 1);
  assert.equal(stats.overallProgress, Math.round((135 / 230) * 100));
});

test('filterAndSortCampaigns filters by search query and status', () => {
  const queryResult = filterAndSortCampaigns(sampleCampaigns, {
    query: 'health',
    status: 'all',
    sortBy: 'lastActivity',
    sortOrder: 'desc',
  });
  assert.equal(queryResult.length, 1);
  assert.equal(queryResult[0].id, 'camp-2');

  const activeResult = filterAndSortCampaigns(sampleCampaigns, {
    query: '',
    status: 'active',
    sortBy: 'lastActivity',
    sortOrder: 'desc',
  });
  assert.equal(activeResult.length, 1);
  assert.equal(activeResult[0].id, 'camp-1');
});

test('filterAndSortCampaigns sorts by name and progress', () => {
  const nameSorted = filterAndSortCampaigns(sampleCampaigns, {
    query: '',
    status: 'all',
    sortBy: 'name',
    sortOrder: 'asc',
  });
  assert.equal(nameSorted[0].name, 'Enterprise VIP Outbound Q4');
  assert.equal(nameSorted[2].name, 'SaaS Renewal Reminders');

  const progressSorted = filterAndSortCampaigns(sampleCampaigns, {
    query: '',
    status: 'all',
    sortBy: 'progress',
    sortOrder: 'desc',
  });
  assert.equal(progressSorted[0].progressPercentage, 100);
});

test('removeDuplicateContacts detects and removes duplicate phone numbers', () => {
  const { updatedCampaign, removedCount } = removeDuplicateContacts(sampleCampaigns[0]);
  assert.equal(removedCount, 1);
  assert.equal(updatedCampaign.contacts.length, 2);
  assert.equal(updatedCampaign.totalContacts, 2);
  assert.equal(updatedCampaign.duplicateContactsFound, 0);
});

test('resetCampaignProgress resets completed calls and marks contacts pending', () => {
  const reset = resetCampaignProgress(sampleCampaigns[0]);
  assert.equal(reset.completedCalls, 0);
  assert.equal(reset.progressPercentage, 0);
  assert.equal(reset.status, 'paused');
  assert.equal(reset.contacts.every((c) => c.status === 'pending'), true);
});

test('formatDuration formats seconds cleanly', () => {
  assert.equal(formatDuration(45), '45s');
  assert.equal(formatDuration(90), '1m 30s');
  assert.equal(formatDuration(3600), '1h 0m');
});
