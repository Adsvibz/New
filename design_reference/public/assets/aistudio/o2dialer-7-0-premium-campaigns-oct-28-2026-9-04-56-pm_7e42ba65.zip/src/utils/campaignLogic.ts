import {
  Campaign,
  CampaignFilterOptions,
  CampaignOverviewStats,
} from '../types/campaign';

/**
 * Calculates aggregated overview metrics for the campaign dashboard
 */
export function calculateOverviewStats(campaigns: Campaign[]): CampaignOverviewStats {
  const totalCampaigns = campaigns.length;
  let totalContacts = 0;
  let completedCalls = 0;
  let pendingCalls = 0;
  let activeCount = 0;
  let completedCount = 0;
  let pausedCount = 0;
  let scheduledCount = 0;

  for (const c of campaigns) {
    totalContacts += c.totalContacts;
    completedCalls += c.completedCalls;
    pendingCalls += c.pendingCalls;

    if (c.status === 'active') activeCount++;
    else if (c.status === 'completed') completedCount++;
    else if (c.status === 'paused') pausedCount++;
    else if (c.status === 'scheduled') scheduledCount++;
  }

  const overallProgress =
    totalContacts > 0 ? Math.round((completedCalls / totalContacts) * 100) : 0;

  return {
    totalCampaigns,
    totalContacts,
    completedCalls,
    pendingCalls,
    overallProgress,
    activeCount,
    completedCount,
    pausedCount,
    scheduledCount,
  };
}

/**
 * Filters and sorts campaigns according to query, status, and sorting fields
 */
export function filterAndSortCampaigns(
  campaigns: Campaign[],
  options: CampaignFilterOptions
): Campaign[] {
  const query = options.query.trim().toLowerCase();

  const filtered = campaigns.filter((c) => {
    // Status filter
    if (options.status !== 'all' && c.status !== options.status) {
      return false;
    }

    // Search query filter: check name, description, or tags
    if (query) {
      const matchName = c.name.toLowerCase().includes(query);
      const matchDesc = c.description?.toLowerCase().includes(query) ?? false;
      const matchTag = c.tags.some((t) => t.toLowerCase().includes(query));
      if (!matchName && !matchDesc && !matchTag) {
        return false;
      }
    }

    return true;
  });

  return filtered.sort((a, b) => {
    let comparison = 0;
    switch (options.sortBy) {
      case 'name':
        comparison = a.name.localeCompare(b.name);
        break;
      case 'progress':
        comparison = a.progressPercentage - b.progressPercentage;
        break;
      case 'contacts':
        comparison = a.totalContacts - b.totalContacts;
        break;
      case 'createdAt':
        comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        break;
      case 'lastActivity':
      default:
        comparison = new Date(a.lastActivity).getTime() - new Date(b.lastActivity).getTime();
        break;
    }
    return options.sortOrder === 'asc' ? comparison : -comparison;
  });
}

/**
 * Removes duplicate phone numbers in a campaign and recalculates metrics
 */
export function removeDuplicateContacts(campaign: Campaign): {
  updatedCampaign: Campaign;
  removedCount: number;
} {
  const seenPhones = new Set<string>();
  const uniqueContacts = [];
  let duplicates = 0;

  for (const contact of campaign.contacts) {
    const normalizedPhone = contact.phone.replace(/[\s\-\(\)\.]/g, '');
    if (seenPhones.has(normalizedPhone)) {
      duplicates++;
    } else {
      seenPhones.add(normalizedPhone);
      uniqueContacts.push(contact);
    }
  }

  const completed = uniqueContacts.filter((c) => c.status === 'completed').length;
  const pending = uniqueContacts.filter((c) => c.status === 'pending').length;
  const answered = uniqueContacts.filter(
    (c) => c.status === 'completed' && (c.callDurationSeconds ?? 0) > 0
  ).length;
  const failed = uniqueContacts.filter(
    (c) => c.status === 'failed' || c.status === 'no-answer' || c.status === 'busy'
  ).length;
  const total = uniqueContacts.length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  const updatedCampaign: Campaign = {
    ...campaign,
    contacts: uniqueContacts,
    totalContacts: total,
    completedCalls: completed,
    pendingCalls: pending,
    answeredCalls: answered,
    failedCalls: failed,
    progressPercentage: progress,
    duplicateContactsFound: 0,
    lastActivity: new Date().toISOString(),
  };

  return { updatedCampaign, removedCount: duplicates };
}

/**
 * Resets progress of a campaign to 0% and marks all contacts as pending
 */
export function resetCampaignProgress(campaign: Campaign): Campaign {
  const resetContacts = campaign.contacts.map((c) => ({
    ...c,
    status: 'pending' as const,
    callDurationSeconds: undefined,
    lastAttempt: undefined,
  }));

  return {
    ...campaign,
    contacts: resetContacts,
    completedCalls: 0,
    pendingCalls: resetContacts.length,
    answeredCalls: 0,
    failedCalls: 0,
    progressPercentage: 0,
    status: 'paused',
    lastActivity: new Date().toISOString(),
  };
}

/**
 * Human-friendly relative time formatter
 */
export function formatTimeAgo(isoString: string): string {
  try {
    const date = new Date(isoString);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffSec < 60) return 'Just now';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch {
    return 'Recent';
  }
}

/**
 * Format duration in mm:ss or hh:mm:ss
 */
export function formatDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '0s';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m === 0) return `${s}s`;
  if (m < 60) return `${m}m ${s > 0 ? `${s}s` : ''}`.trim();
  const h = Math.floor(m / 60);
  const remM = m % 60;
  return `${h}h ${remM}m`;
}
