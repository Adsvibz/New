import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatCallTimer,
  getQueuedContacts,
  getNextPendingContact,
  applyCallOutcomeToCampaign,
  removeContactFromCampaign,
} from './dialerLogic';
import { Campaign } from '../types/campaign';

const sampleCampaign: Campaign = {
  id: 'c-test',
  name: 'Test Campaign',
  status: 'active',
  totalContacts: 3,
  completedCalls: 1,
  pendingCalls: 2,
  answeredCalls: 1,
  failedCalls: 0,
  progressPercentage: 33,
  createdAt: '2026-10-01T00:00:00.000Z',
  lastActivity: '2026-10-01T00:00:00.000Z',
  dialerMode: 'rapid',
  delayBetweenCalls: 4,
  duplicateContactsFound: 0,
  tags: ['test'],
  contacts: [
    { id: '1', name: 'Alice Smith', phone: '+15551112222', status: 'completed', callDurationSeconds: 65 },
    { id: '2', name: 'Bob Jones', phone: '+15553334444', status: 'pending' },
    { id: '3', name: 'Carol White', phone: '+15555556666', status: 'pending' },
  ],
};

test('formatCallTimer formats seconds into mm:ss', () => {
  assert.equal(formatCallTimer(0), '00:00');
  assert.equal(formatCallTimer(5), '00:05');
  assert.equal(formatCallTimer(42), '00:42');
  assert.equal(formatCallTimer(60), '01:00');
  assert.equal(formatCallTimer(125), '02:05');
});

test('getQueuedContacts returns pending contacts excluding current caller', () => {
  const queued = getQueuedContacts(sampleCampaign.contacts, '2');
  assert.equal(queued.length, 1);
  assert.equal(queued[0].id, '3');
});

test('getNextPendingContact returns the first pending contact', () => {
  const next = getNextPendingContact(sampleCampaign.contacts);
  assert.ok(next);
  assert.equal(next?.id, '2');

  const afterBob = getNextPendingContact(sampleCampaign.contacts, '2');
  assert.ok(afterBob);
  assert.equal(afterBob?.id, '3');
});

test('applyCallOutcomeToCampaign marks contact completed and recalculates campaign counts', () => {
  const updated = applyCallOutcomeToCampaign(sampleCampaign, '2', 'answered', 90);
  assert.equal(updated.completedCalls, 2);
  assert.equal(updated.pendingCalls, 1);
  assert.equal(updated.answeredCalls, 2);
  assert.equal(updated.progressPercentage, 67);

  const bob = updated.contacts.find((c) => c.id === '2');
  assert.equal(bob?.status, 'completed');
  assert.equal(bob?.callDurationSeconds, 90);
});

test('removeContactFromCampaign removes contact from queue and updates total', () => {
  const updated = removeContactFromCampaign(sampleCampaign, '3');
  assert.equal(updated.contacts.length, 2);
  assert.equal(updated.totalContacts, 2);
  assert.equal(updated.pendingCalls, 1);
});
