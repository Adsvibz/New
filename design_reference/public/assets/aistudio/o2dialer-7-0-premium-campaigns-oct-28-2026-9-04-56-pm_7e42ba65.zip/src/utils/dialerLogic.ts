import { Campaign, CampaignContact } from '../types/campaign';
import { CallLogRecord, CallOutcome, LiveSessionState, SessionStatus } from '../types/dialer';

/**
 * Formats seconds into mm:ss (e.g. 00:42, 02:15)
 */
export function formatCallTimer(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const mStr = mins < 10 ? `0${mins}` : `${mins}`;
  const sStr = secs < 10 ? `0${secs}` : `${secs}`;
  return `${mStr}:${sStr}`;
}

/**
 * Returns the list of upcoming queued contacts for an active campaign,
 * skipping completed contacts and the contact currently on the line.
 */
export function getQueuedContacts(
  contacts: CampaignContact[],
  currentContactId?: string
): CampaignContact[] {
  return contacts.filter(
    (c) => c.status === 'pending' && c.id !== currentContactId
  );
}

/**
 * Finds the next pending contact to call in the campaign.
 */
export function getNextPendingContact(
  contacts: CampaignContact[],
  excludeContactId?: string
): CampaignContact | null {
  const pending = contacts.filter(
    (c) => c.status === 'pending' && c.id !== excludeContactId
  );
  return pending.length > 0 ? pending[0] : null;
}

/**
 * Pure function to record an outcome for the current call and update the campaign contacts.
 */
export function applyCallOutcomeToCampaign(
  campaign: Campaign,
  contactId: string,
  outcome: CallOutcome,
  durationSeconds: number
): Campaign {
  const updatedContacts = campaign.contacts.map((c) => {
    if (c.id !== contactId) return c;
    const newStatus =
      outcome === 'answered'
        ? ('completed' as const)
        : outcome === 'no-answer'
        ? ('no-answer' as const)
        : outcome === 'failed'
        ? ('failed' as const)
        : ('pending' as const); // skipped stays or moves to end

    return {
      ...c,
      status: newStatus,
      callDurationSeconds: durationSeconds,
      lastAttempt: new Date().toISOString(),
    };
  });

  const completed = updatedContacts.filter(
    (c) => c.status === 'completed' || c.status === 'no-answer' || c.status === 'failed'
  ).length;
  const pending = updatedContacts.filter((c) => c.status === 'pending').length;
  const answered = updatedContacts.filter(
    (c) => c.status === 'completed' && (c.callDurationSeconds ?? 0) > 0
  ).length;
  const failed = updatedContacts.filter(
    (c) => c.status === 'failed' || c.status === 'no-answer'
  ).length;
  const total = updatedContacts.length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
  const isFinished = pending === 0;

  return {
    ...campaign,
    contacts: updatedContacts,
    completedCalls: completed,
    pendingCalls: pending,
    answeredCalls: answered,
    failedCalls: failed,
    progressPercentage: progress,
    status: isFinished ? 'completed' : campaign.status,
    lastActivity: new Date().toISOString(),
  };
}

/**
 * Removes a contact from the campaign contact list
 */
export function removeContactFromCampaign(
  campaign: Campaign,
  contactId: string
): Campaign {
  const updatedContacts = campaign.contacts.filter((c) => c.id !== contactId);
  const total = updatedContacts.length;
  const completed = updatedContacts.filter((c) => c.status === 'completed').length;
  const pending = updatedContacts.filter((c) => c.status === 'pending').length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  return {
    ...campaign,
    contacts: updatedContacts,
    totalContacts: total,
    completedCalls: completed,
    pendingCalls: pending,
    progressPercentage: progress,
    lastActivity: new Date().toISOString(),
  };
}
