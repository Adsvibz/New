import React, { useState, useMemo } from 'react';
import { initialCampaigns } from './data/initialCampaigns';
import { Campaign, CampaignStatus, SortField, SortOrder } from './types/campaign';
import {
  calculateOverviewStats,
  filterAndSortCampaigns,
  removeDuplicateContacts,
  resetCampaignProgress,
} from './utils/campaignLogic';
import { translations, Language } from './i18n/translations';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidNavBar } from './components/AndroidNavBar';
import { ScreenHeader } from './components/ScreenHeader';
import { CampaignOverview } from './components/CampaignOverview';
import { SearchAndFilterBar } from './components/SearchAndFilterBar';
import { CampaignCard } from './components/CampaignCard';
import { MultiSelectToolbar } from './components/MultiSelectToolbar';
import { FloatingBottomNav, NavTab } from './components/FloatingBottomNav';
import { EmptyCampaignState } from './components/EmptyCampaignState';
import { NewCampaignSheet } from './components/NewCampaignSheet';
import { EditCampaignSheet } from './components/EditCampaignSheet';
import { CampaignDetailModal } from './components/CampaignDetailModal';
import { RenameModal } from './components/RenameModal';
import { DeleteConfirmDialog } from './components/DeleteConfirmDialog';
import { DuplicateContactsModal } from './components/DuplicateContactsModal';
import { CampaignReportModal } from './components/CampaignReportModal';
import { ShareCampaignModal } from './components/ShareCampaignModal';
import { Toast, ToastMessage } from './components/Toast';
import { DeviceFrameWrapper } from './components/DeviceFrameWrapper';
import { LiveDialerScreen } from './components/dialer/LiveDialerScreen';

export default function App() {
  // Main state
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns);
  const [language, setLanguage] = useState<Language>('en');
  const [isDeviceFrame, setIsDeviceFrame] = useState<boolean>(true);
  const [currentNavTab, setCurrentNavTab] = useState<NavTab>('dialer'); // Default to Dialer to showcase Screen 3!
  const [activeDialerCampaignId, setActiveDialerCampaignId] = useState<string | null>('camp-101');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<CampaignStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState<SortField>('lastActivity');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Multi-selection state
  const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Modal & Drawer states
  const [isNewSheetOpen, setIsNewSheetOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [detailCampaign, setDetailCampaign] = useState<Campaign | null>(null);
  const [renamingCampaign, setRenamingCampaign] = useState<Campaign | null>(null);
  const [deletingCampaign, setDeletingCampaign] = useState<Campaign | null>(null);
  const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false);
  const [duplicateCampaign, setDuplicateCampaign] = useState<Campaign | null>(null);
  const [reportCampaign, setReportCampaign] = useState<Campaign | null>(null);
  const [shareCampaign, setShareCampaign] = useState<Campaign | null>(null);

  // Toast feedback
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const t = translations[language];

  // Helper to trigger toast
  const addToast = (type: 'success' | 'info' | 'error', message: string) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  };

  // Derived statistics
  const overviewStats = useMemo(() => calculateOverviewStats(campaigns), [campaigns]);

  // Counts for each status tab
  const statusCounts = useMemo(() => {
    return {
      all: campaigns.length,
      active: campaigns.filter((c) => c.status === 'active').length,
      completed: campaigns.filter((c) => c.status === 'completed').length,
      paused: campaigns.filter((c) => c.status === 'paused').length,
      scheduled: campaigns.filter((c) => c.status === 'scheduled').length,
    };
  }, [campaigns]);

  // Filtered and sorted campaigns
  const filteredCampaigns = useMemo(() => {
    return filterAndSortCampaigns(campaigns, {
      query: searchQuery,
      status: selectedStatus,
      sortBy,
      sortOrder,
    });
  }, [campaigns, searchQuery, selectedStatus, sortBy, sortOrder]);

  // Multi-selection helpers
  const handleToggleSelect = (id: string) => {
    setIsMultiSelectMode(true);
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    setSelectedIds(new Set(filteredCampaigns.map((c) => c.id)));
  };

  const handleDeselectAll = () => {
    setSelectedIds(new Set());
  };

  const handleCancelMultiSelect = () => {
    setIsMultiSelectMode(false);
    setSelectedIds(new Set());
  };

  // Campaign lifecycle handlers
  const handleCreateCampaign = (data: Partial<Campaign>) => {
    const newCamp: Campaign = {
      id: `camp-${Date.now()}`,
      name: data.name || 'Untitled Campaign',
      description: data.description,
      status: data.status || 'active',
      totalContacts: data.totalContacts || 100,
      completedCalls: 0,
      pendingCalls: data.totalContacts || 100,
      answeredCalls: 0,
      failedCalls: 0,
      progressPercentage: 0,
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      dialerMode: data.dialerMode || 'rapid',
      delayBetweenCalls: data.delayBetweenCalls || 4,
      callerId: data.callerId,
      duplicateContactsFound: 0,
      tags: data.tags || ['Outbound'],
      contacts: data.contacts || [],
    };

    setCampaigns((prev) => [newCamp, ...prev]);
    addToast('success', `Campaign "${newCamp.name}" created.`);
  };

  const handleSaveEditedCampaign = (updated: Campaign) => {
    setCampaigns((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    if (detailCampaign && detailCampaign.id === updated.id) {
      setDetailCampaign(updated);
    }
    setEditingCampaign(null);
    addToast('success', `Saved changes to "${updated.name}".`);
  };

  const handleRenameCampaign = (campaignId: string, newName: string) => {
    setCampaigns((prev) =>
      prev.map((c) => (c.id === campaignId ? { ...c, name: newName } : c))
    );
    if (detailCampaign && detailCampaign.id === campaignId) {
      setDetailCampaign((prev) => (prev ? { ...prev, name: newName } : null));
    }
    addToast('success', `Renamed to "${newName}".`);
  };

  const handleTogglePlayPause = (campaign: Campaign) => {
    const newStatus: CampaignStatus = campaign.status === 'active' ? 'paused' : 'active';
    setCampaigns((prev) =>
      prev.map((c) => (c.id === campaign.id ? { ...c, status: newStatus } : c))
    );
    if (detailCampaign && detailCampaign.id === campaign.id) {
      setDetailCampaign((prev) => (prev ? { ...prev, status: newStatus } : null));
    }
    addToast(
      'info',
      newStatus === 'active'
        ? `Campaign resumed.`
        : `Campaign paused.`
    );
  };

  const handleResetProgress = (campaign: Campaign) => {
    const reset = resetCampaignProgress(campaign);
    setCampaigns((prev) => prev.map((c) => (c.id === campaign.id ? reset : c)));
    if (detailCampaign && detailCampaign.id === campaign.id) {
      setDetailCampaign(reset);
    }
    addToast('info', t.progressResetMsg);
  };

  const handleConfirmRemoveDuplicates = (campaign: Campaign) => {
    const { updatedCampaign, removedCount } = removeDuplicateContacts(campaign);
    setCampaigns((prev) =>
      prev.map((c) => (c.id === campaign.id ? updatedCampaign : c))
    );
    if (detailCampaign && detailCampaign.id === campaign.id) {
      setDetailCampaign(updatedCampaign);
    }
    setDuplicateCampaign(null);
    addToast('success', t.duplicatesCleanedMsg(removedCount));
  };

  const handleDeleteCampaign = (campaign: Campaign) => {
    setCampaigns((prev) => prev.filter((c) => c.id !== campaign.id));
    if (detailCampaign && detailCampaign.id === campaign.id) {
      setDetailCampaign(null);
    }
    setDeletingCampaign(null);
    addToast('info', `Campaign deleted.`);
  };

  // Bulk actions
  const handleBulkDelete = () => {
    setCampaigns((prev) => prev.filter((c) => !selectedIds.has(c.id)));
    const count = selectedIds.size;
    handleCancelMultiSelect();
    setIsBulkDeleteOpen(false);
    addToast('info', `${count} campaigns deleted.`);
  };

  const handleBulkPause = () => {
    setCampaigns((prev) =>
      prev.map((c) => (selectedIds.has(c.id) ? { ...c, status: 'paused' } : c))
    );
    addToast('info', `${selectedIds.size} campaigns paused.`);
    handleCancelMultiSelect();
  };

  const handleBulkResume = () => {
    setCampaigns((prev) =>
      prev.map((c) =>
        selectedIds.has(c.id) && c.status !== 'completed' ? { ...c, status: 'active' } : c
      )
    );
    addToast('success', `${selectedIds.size} campaigns resumed.`);
    handleCancelMultiSelect();
  };

  const handleBulkShare = () => {
    addToast('info', `Exported list of ${selectedIds.size} campaigns.`);
    handleCancelMultiSelect();
  };

  // Simulate placing next call in sequence
  const handleSimulateCall = (campaign: Campaign) => {
    const pendingIndex = campaign.contacts.findIndex((c) => c.status === 'pending');
    if (pendingIndex === -1 && campaign.pendingCalls === 0) {
      addToast('info', 'All contacts dialed.');
      return;
    }

    const duration = Math.floor(45 + Math.random() * 180);
    const updatedContacts = [...campaign.contacts];
    let dialedName = 'Contact';

    if (pendingIndex !== -1) {
      dialedName = updatedContacts[pendingIndex].name;
      updatedContacts[pendingIndex] = {
        ...updatedContacts[pendingIndex],
        status: 'completed',
        callDurationSeconds: duration,
        lastAttempt: new Date().toISOString(),
      };
    }

    const newCompleted = campaign.completedCalls + 1;
    const newPending = Math.max(0, campaign.totalContacts - newCompleted);
    const newAnswered = campaign.answeredCalls + 1;
    const newProgress = Math.round((newCompleted / campaign.totalContacts) * 100);
    const isNowCompleted = newCompleted >= campaign.totalContacts;

    const updated: Campaign = {
      ...campaign,
      contacts: updatedContacts,
      completedCalls: newCompleted,
      pendingCalls: newPending,
      answeredCalls: newAnswered,
      progressPercentage: newProgress,
      status: isNowCompleted ? 'completed' : campaign.status,
      lastActivity: new Date().toISOString(),
    };

    setCampaigns((prev) => prev.map((c) => (c.id === campaign.id ? updated : c)));
    if (detailCampaign && detailCampaign.id === campaign.id) {
      setDetailCampaign(updated);
    }

    addToast(
      'success',
      `Call with ${dialedName} completed (${Math.floor(duration / 60)}m ${duration % 60}s).`
    );
  };

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-screen bg-[#F5F6F8] text-[#111827]"
    >
      <DeviceFrameWrapper isDeviceFrame={isDeviceFrame}>
        {/* Android Status Bar */}
        <AndroidStatusBar isRtl={language === 'ar'} />

        {/* Dynamic Screen Viewport */}
        {currentNavTab === 'dialer' ? (
          <LiveDialerScreen
            campaigns={campaigns}
            activeCampaignId={activeDialerCampaignId}
            onSelectCampaign={(c) => setActiveDialerCampaignId(c.id)}
            onUpdateCampaign={(updated) => {
              setCampaigns((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
            }}
            onOpenCampaignDetails={(c) => {
              setDetailCampaign(c);
              setCurrentNavTab('campaigns');
            }}
            currentLanguage={language}
            onToggleLanguage={() => setLanguage((prev) => (prev === 'en' ? 'ar' : 'en'))}
            onTriggerToast={addToast}
            t={t}
          />
        ) : currentNavTab === 'campaigns' ? (
          <>
            {/* Multi-Selection Contextual Toolbar OR Standard Header */}
            {isMultiSelectMode ? (
              <MultiSelectToolbar
                selectedCount={selectedIds.size}
                totalCount={filteredCampaigns.length}
                onSelectAll={handleSelectAll}
                onDeselectAll={handleDeselectAll}
                onBulkDelete={() => setIsBulkDeleteOpen(true)}
                onBulkPause={handleBulkPause}
                onBulkResume={handleBulkResume}
                onBulkShare={handleBulkShare}
                onCancel={handleCancelMultiSelect}
                t={t}
              />
            ) : (
              <ScreenHeader
                t={t}
                currentLanguage={language}
                onToggleLanguage={() => setLanguage((prev) => (prev === 'en' ? 'ar' : 'en'))}
                campaignCount={overviewStats.totalCampaigns}
                contactCount={overviewStats.totalContacts}
                onNewCampaign={() => setIsNewSheetOpen(true)}
                isMultiSelectMode={isMultiSelectMode}
                onToggleMultiSelect={() => {
                  setIsMultiSelectMode(!isMultiSelectMode);
                  setSelectedIds(new Set());
                }}
              />
            )}

            {/* Scrollable Content Viewport */}
            <div className="flex-1 overflow-y-auto bg-white flex flex-col">
              {/* Campaign Overview Metrics (Shown when campaigns exist) */}
              {campaigns.length > 0 && (
                <CampaignOverview stats={overviewStats} t={t} />
              )}

              {/* Search & Status Filters */}
              {campaigns.length > 0 && (
                <SearchAndFilterBar
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                  selectedStatus={selectedStatus}
                  onStatusChange={setSelectedStatus}
                  sortBy={sortBy}
                  sortOrder={sortOrder}
                  onSortChange={(field, order) => {
                    setSortBy(field);
                    setSortOrder(order);
                  }}
                  t={t}
                  statusCounts={statusCounts}
                />
              )}

              {/* Campaign List / Empty / No-Results States */}
              <div className="px-6 py-2 space-y-3 flex-1 pb-6">
                {campaigns.length === 0 ? (
                  <EmptyCampaignState
                    onCreateCampaign={() => setIsNewSheetOpen(true)}
                    t={t}
                  />
                ) : filteredCampaigns.length === 0 ? (
                  <div className="py-16 text-center">
                    <p className="text-[14px] font-semibold text-[#111827]">
                      {t.noSearchResultsTitle}
                    </p>
                    <p className="text-[12.5px] text-[#8E95A2] mt-1 max-w-xs mx-auto">
                      {t.noSearchResultsSubtitle}
                    </p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedStatus('all');
                      }}
                      className="mt-3 text-[12.5px] font-medium text-[#111827] underline"
                    >
                      {t.clearSearch}
                    </button>
                  </div>
                ) : (
                  filteredCampaigns.map((campaign) => (
                    <CampaignCard
                      key={campaign.id}
                      campaign={campaign}
                      isSelected={selectedIds.has(campaign.id)}
                      isMultiSelectMode={isMultiSelectMode}
                      onToggleSelect={handleToggleSelect}
                      onOpenDetails={(c) => setDetailCampaign(c)}
                      onEdit={(c) => setEditingCampaign(c)}
                      onRename={(c) => setRenamingCampaign(c)}
                      onTogglePlayPause={(c) => {
                        setActiveDialerCampaignId(c.id);
                        setCurrentNavTab('dialer');
                      }}
                      onResetProgress={handleResetProgress}
                      onRemoveDuplicates={(c) => setDuplicateCampaign(c)}
                      onViewReport={(c) => setReportCampaign(c)}
                      onShare={(c) => setShareCampaign(c)}
                      onDelete={(c) => setDeletingCampaign(c)}
                      t={t}
                    />
                  ))
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto bg-white flex flex-col items-center justify-center p-8 text-center">
            <h2 className="text-[18px] font-semibold text-[#111827] capitalize tracking-tight mb-1">
              {currentNavTab}
            </h2>
            <p className="text-[13px] text-[#8E95A2] max-w-xs mb-5">
              Access calling campaigns or launch the automated live dialer session.
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentNavTab('dialer')}
                className="px-4 py-2 text-[12.5px] font-medium bg-[#111827] text-white rounded-lg hover:bg-neutral-800 transition-colors"
              >
                Go to Dialer
              </button>
              <button
                onClick={() => setCurrentNavTab('campaigns')}
                className="px-4 py-2 text-[12.5px] font-medium text-[#111827] hover:bg-[#F4F5F7] border border-[#EBECEF] rounded-lg transition-colors"
              >
                Go to Campaigns
              </button>
            </div>
          </div>
        )}

        {/* Floating Bottom Navigation Bar */}
        <FloatingBottomNav
          currentTab={currentNavTab}
          onSelectTab={(tab) => {
            setCurrentNavTab(tab);
          }}
          t={t}
          badgeCount={overviewStats.activeCount}
        />

        {/* Android Gesture Bar */}
        <AndroidNavBar />
      </DeviceFrameWrapper>

      {/* Modals & Bottom Sheets */}
      <NewCampaignSheet
        isOpen={isNewSheetOpen}
        onClose={() => setIsNewSheetOpen(false)}
        onCreate={handleCreateCampaign}
        t={t}
      />

      <EditCampaignSheet
        campaign={editingCampaign}
        isOpen={!!editingCampaign}
        onClose={() => setEditingCampaign(null)}
        onSave={handleSaveEditedCampaign}
        t={t}
      />

      <CampaignDetailModal
        campaign={detailCampaign}
        isOpen={!!detailCampaign}
        onClose={() => setDetailCampaign(null)}
        onEdit={(c) => {
          setDetailCampaign(null);
          setEditingCampaign(c);
        }}
        onResetProgress={handleResetProgress}
        onSimulateCall={handleSimulateCall}
        onLaunchDialerSession={(c) => {
          setActiveDialerCampaignId(c.id);
          setCurrentNavTab('dialer');
        }}
        t={t}
      />

      <RenameModal
        campaign={renamingCampaign}
        isOpen={!!renamingCampaign}
        onClose={() => setRenamingCampaign(null)}
        onRename={handleRenameCampaign}
        t={t}
      />

      <DeleteConfirmDialog
        isOpen={!!deletingCampaign}
        message={
          deletingCampaign
            ? t.confirmDeleteMsg(deletingCampaign.name)
            : ''
        }
        onConfirm={() => deletingCampaign && handleDeleteCampaign(deletingCampaign)}
        onCancel={() => setDeletingCampaign(null)}
        t={t}
      />

      <DeleteConfirmDialog
        isOpen={isBulkDeleteOpen}
        title="Delete Selected Campaigns"
        message={t.confirmBulkDeleteMsg(selectedIds.size)}
        onConfirm={handleBulkDelete}
        onCancel={() => setIsBulkDeleteOpen(false)}
        t={t}
      />

      <DuplicateContactsModal
        campaign={duplicateCampaign}
        isOpen={!!duplicateCampaign}
        onClose={() => setDuplicateCampaign(null)}
        onConfirmRemove={handleConfirmRemoveDuplicates}
        t={t}
      />

      <CampaignReportModal
        campaign={reportCampaign}
        isOpen={!!reportCampaign}
        onClose={() => setReportCampaign(null)}
        onExportCsv={() => {
          setReportCampaign(null);
          addToast('success', 'Report exported.');
        }}
        t={t}
      />

      <ShareCampaignModal
        campaign={shareCampaign}
        isOpen={!!shareCampaign}
        onClose={() => setShareCampaign(null)}
        onCopied={() => {
          addToast('success', 'Summary copied.');
        }}
        t={t}
      />

      {/* Global Toast notifications */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
