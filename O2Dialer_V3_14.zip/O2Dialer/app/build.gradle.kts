plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.o2dialer.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.o2dialer.app"
        minSdk = 26
        targetSdk = 34
        // Always rises with every GitHub run, so each build installs as an update over the previous one.
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "3.14"
    }
    // One fixed signing key for every build: Android only installs an APK as an update
    // when it is signed with the same key as the installed app.
    signingConfigs {
        create("o2dialer") {
            storeFile = file("o2dialer.keystore")
            storeType = "pkcs12"
            storePassword = "o2dialer-sign"
            keyAlias = "o2dialer"
            keyPassword = "o2dialer-sign"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("o2dialer") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.8" }
    lint { abortOnError = false }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
