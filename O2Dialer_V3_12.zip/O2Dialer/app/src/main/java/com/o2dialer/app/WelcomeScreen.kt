package com.o2dialer.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private class WelcomePage(val eyebrow: String, val title: String, val body: String, val icon: ImageVector)

/** Two overlapping circles: the small brand mark next to the name in the header. */
@Composable
private fun MiniLogo() {
    val cs = MaterialTheme.colorScheme
    val a = cs.primary
    val b = cs.secondary
    Canvas(Modifier.size(width = 28.dp, height = 18.dp)) {
        val r = 8.dp.toPx()
        drawCircle(a, r, Offset(9.dp.toPx(), size.height / 2f))
        drawCircle(b.copy(alpha = 0.75f), r, Offset(19.dp.toPx(), size.height / 2f))
    }
}

/** Floating white card used by the page visuals. */
@Composable
private fun VisualChip(modifier: Modifier, content: @Composable RowScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.l)
    Row(
        modifier.shadow(8.dp, shape).clip(shape).background(cs.surface).border(1.dp, cs.outline, shape)
            .padding(horizontal = Sp.m, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun ChipText(title: String, sub: String) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        Text(sub, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun WelcomeVisual(page: Int, icon: ImageVector) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "orbits")
    val a1 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "a1")
    val a2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "a2")
    val ring = cs.onSurfaceVariant.copy(alpha = 0.2f)
    val dot1 = cs.primary
    val dot2 = cs.secondary
    Box(Modifier.fillMaxWidth().height(320.dp), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r1 = 96.dp.toPx()
            val r2 = minOf(142.dp.toPx(), size.width / 2f - 2.dp.toPx())
            drawCircle(ring, r1, c, style = Stroke(1.dp.toPx()))
            drawCircle(ring, r2, c, style = Stroke(1.dp.toPx()))
            val p1 = a1 * PI / 180.0
            val p2 = (a2 + 140f) * PI / 180.0
            drawCircle(dot1, 5.dp.toPx(), Offset(c.x + (r1 * cos(p1)).toFloat(), c.y + (r1 * sin(p1)).toFloat()))
            drawCircle(dot2, 4.dp.toPx(), Offset(c.x + (r2 * cos(p2)).toFloat(), c.y + (r2 * sin(p2)).toFloat()))
        }
        Box(
            Modifier.size(84.dp).shadow(20.dp, CircleShape, ambientColor = HeroBg, spotColor = HeroBg)
                .clip(CircleShape).background(HeroBg),
            Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(38.dp)) }

        val topMod = Modifier.align(Alignment.TopEnd).padding(top = 12.dp)
        val bottomMod = Modifier.align(Alignment.BottomStart).padding(bottom = 12.dp)
        when (page) {
            0 -> {
                VisualChip(topMod) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)), Alignment.Center) {
                        Text(T("M", "م"), style = MaterialTheme.typography.titleSmall, color = cs.primary)
                    }
                    ChipText(T("Maya Nelson", "مي نبيل"), T("Calling now", "جاري الاتصال"))
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                        listOf(8, 12, 16).forEach { h -> Box(Modifier.width(4.dp).height(h.dp).clip(CircleShape).background(Sem.success)) }
                    }
                }
                VisualChip(bottomMod) {
                    Box(Modifier.size(26.dp).clip(CircleShape).background(Sem.success), Alignment.Center) {
                        Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                    ChipText(T("18 answered", "١٨ ردّوا"), T("Today's campaign", "حملة اليوم"))
                }
            }
            1 -> {
                VisualChip(topMod) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.primary.copy(alpha = 0.14f)), Alignment.Center) {
                        Text("01", style = MaterialTheme.typography.titleSmall, color = cs.primary)
                    }
                    ChipText(T("Summer Leads", "عملاء الصيف"), T("42 contacts", "٤٢ جهة اتصال"))
                    Pill(T("Ready", "جاهزة"), Sem.success)
                }
                VisualChip(bottomMod) {
                    Icon(Icons.Rounded.Timer, null, tint = cs.primary, modifier = Modifier.size(19.dp))
                    ChipText(T("5 sec rhythm", "إيقاع ٥ ثوانٍ"), T("Smart delay", "فاصل ذكي"))
                    Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(cs.onSurfaceVariant.copy(alpha = 0.2f))) {
                        Box(Modifier.fillMaxWidth(0.6f).fillMaxHeight().background(cs.primary))
                    }
                }
            }
            else -> {
                VisualChip(topMod) {
                    Text("68%", style = MaterialTheme.typography.headlineSmall, color = cs.primary)
                    ChipText(T("Answer rate", "نسبة الرد"), T("Up 12% this week", "أعلى بـ ١٢٪ هذا الأسبوع"))
                }
                VisualChip(bottomMod) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(Color(0xFF3B82F6), Color(0xFFF59E0B), Color(0xFF22C55E)).forEach { c ->
                            Box(Modifier.size(10.dp).clip(CircleShape).background(c))
                        }
                    }
                    ChipText(T("Lead stages", "مراحل العملاء"), T("Always organized", "دائمًا منظّمة"))
                }
            }
        }
    }
}

@Composable
fun WelcomeScreen() {
    val cs = MaterialTheme.colorScheme
    val pages = listOf(
        WelcomePage(
            T("CALL WITH MOMENTUM", "اتصل بلا توقف"),
            T("Your call list,\none smooth flow.", "قائمة مكالماتك،\nفي تدفّق واحد سلس."),
            T("$APP_NAME moves through every contact automatically, so you can focus on the conversation\u2014not the next number.",
                "$APP_NAME ينتقل بين كل جهات الاتصال تلقائيًا، فتركّز على المحادثة لا على الرقم التالي."),
            Icons.Rounded.Call
        ),
        WelcomePage(
            T("BUILT AROUND YOUR DAY", "مصمَّم حول يومك"),
            T("Set the rhythm.\nWe\u2019ll handle the queue.", "اضبط الإيقاع،\nونحن ندير الطابور."),
            T("Choose the pause between calls, add retry rules, and select the right SIM for every campaign.",
                "اختر الفاصل بين المكالمات، وأضف قواعد إعادة المحاولة، واختر الشريحة المناسبة لكل حملة."),
            Icons.Rounded.Campaign
        ),
        WelcomePage(
            T("EVERY CALL, ACCOUNTED FOR", "كل مكالمة محسوبة"),
            T("Turn conversations\ninto clear next steps.", "حوّل المحادثات\nإلى خطوات واضحة."),
            T("Tag outcomes, add notes, follow up on WhatsApp, and see campaign performance at a glance.",
                "صنّف النتائج، وأضف ملاحظات، وتابع على واتساب، وشاهد أداء الحملة بنظرة واحدة."),
            Icons.Rounded.BarChart
        )
    )
    var page by rememberSaveable { mutableStateOf(0) }
    val last = page == pages.lastIndex
    BackHandler(enabled = page > 0) { page -= 1 }
    val glow1 = cs.primary.copy(alpha = 0.20f)
    val glow2 = cs.secondary.copy(alpha = 0.18f)

    Box(
        Modifier.fillMaxSize().drawBehind {
            drawRect(Brush.radialGradient(listOf(glow1, Color.Transparent), Offset(size.width * 0.1f, size.height * 0.05f), size.width * 0.8f))
            drawRect(Brush.radialGradient(listOf(glow2, Color.Transparent), Offset(size.width * 0.95f, size.height * 0.9f), size.width * 0.8f))
        }
    ) {
        Responsive {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = Sp.xl, vertical = Sp.l)
            ) {
                // Header: brand on one side, language + skip on the other
                Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniLogo()
                    Spacer(Modifier.width(Sp.s))
                    Text(APP_NAME, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { Store.updateCfg { it.copy(lang = if (it.lang == 0) 1 else 0) } }) {
                        Text(if (Store.cfg.lang == 0) "العربية" else "English")
                    }
                    if (!last) TextButton(onClick = { Store.finishWelcome() }) { Text(T("Skip", "تخطي")) }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AnimatedContent(
                        targetState = page,
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                        label = "welcomePage"
                    ) { i ->
                        val p = pages[i]
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                            WelcomeVisual(i, p.icon)
                            Spacer(Modifier.height(Sp.l))
                            Text(
                                p.eyebrow,
                                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = if (Store.cfg.lang == 0) 1.5.sp else 0.sp),
                                color = cs.primary
                            )
                            Spacer(Modifier.height(Sp.s))
                            Text(p.title, style = MaterialTheme.typography.headlineLarge)
                            Spacer(Modifier.height(Sp.m))
                            Text(p.body, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = Sp.l), horizontalArrangement = Arrangement.Center) {
                    pages.indices.forEach { i ->
                        val w by animateDpAsState(if (i == page) 24.dp else 8.dp, label = "dot")
                        Box(
                            Modifier.padding(horizontal = 4.dp).height(8.dp).width(w).clip(CircleShape)
                                .background(if (i == page) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.35f))
                        )
                    }
                }
                BButton(
                    text = if (last) T("Get started", "ابدأ الآن") else T("Next", "التالي"),
                    onClick = { if (last) Store.finishWelcome() else page += 1 },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
