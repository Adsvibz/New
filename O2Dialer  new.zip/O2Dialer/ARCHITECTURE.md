# O2Dialer — Architecture (Command 01: Audit & Architecture Reset)

## 1. Audit of the previous implementation ("Blendora v3.1")

Measured on the old source tree (12 Kotlin files, 3,055 lines):

| # | Finding | Evidence | Severity |
|---|---------|----------|----------|
| 1 | **One global mutable singleton (`Store`) is the whole app**: persistence, domain data, navigation, toasts, permission ticks, engine state. | 186 `Store.` references; 40 in one screen file, 39 in the activity, 36 in the service. | High |
| 2 | **Calling engine was welded to the Android Service, the UI store and UI strings.** The service wrote UI state (`Store.stageTarget`, `Store.camp`), formatted localized text (`T()`), and contained business rules. | 51 `Store.`/`T(` references inside `DialerService`; engine could not be run or tested without Android. | High |
| 3 | **No unidirectional data flow, no ViewModels, no lifecycle-aware collection.** Composables read and *wrote* global state directly. | 0 ViewModel/StateFlow usages. | High |
| 4 | **Persistence on the main thread**: every status update re-serialised the whole JSON of all campaigns. | 7 save calls, each full rewrite. | Medium |
| 5 | **Android APIs inside composables** (ContentResolver, contacts query, SIM lookup, startActivity). | 11 hits in UI files. | Medium |
| 6 | Timers were `Handler` runnables mutated from several places (13 post/remove sites) — hard to reason about cancellation. | `DialerService` | Medium |
| 7 | Navigation = integers in a global object; back handling scattered. | `Store.tab`, `selectedListId`… | Medium |
| 8 | Localization read a global at call-sites, including inside the engine. | `T()` in service | Medium |
| 9 | Manifest: `allowBackup="true"` while the app stores personal phone numbers. | Manifest | Medium (privacy) |
| 10 | Build: no minification config; `material-icons-extended` pulled in wholesale (large APK). | build.gradle | Low (tracked for a later command) |
| 11 | Heuristics worth keeping but isolating: answered-detection via call log (retry up to 2×), 25 s "call never started" timeout, speaker/mic via deprecated `AudioManager` API (unreliable on Android 12+, device-dependent). | engine | Info |

**What was sound and is preserved (behavior-compatible):** resume-where-you-stopped queue semantics, retry rules, rounds, shuffle, quiet-hours window, per-campaign SIM, stage prompt after answered calls (with wait/skip), number auto-correction, answered detection via call log, speaker/mic automation, foreground service + wake lock, completion notification.

## 2. Target architecture

Single Activity · Jetpack Compose · unidirectional data flow · repository pattern · immutable state · coroutines.

```
┌──────────────────────────── ui ────────────────────────────┐
│ MainActivity (permissions, share, window flags only)       │
│ AppRoot ── drawer, AnimatedContent nav, toast, stage sheet │
│ screens/*  (stateless: state in, actions out)              │
│ components/* · theme/* (design system)                     │
│ viewmodel/*  AppViewModel · CampaignsViewModel ·           │
│              LiveViewModel · LogViewModel · SettingsVM     │
└───────────────┬────────────────────────────────────────────┘
                │ depends on interfaces only
┌───────────────▼──────────────── domain (pure Kotlin) ──────┐
│ model/   Campaign, Contact, CallStatus, Stage, AppSettings │
│ engine/  CallEngine, EngineState, TelephonyGateway,        │
│          EngineLauncher (interfaces + immutable state)     │
│ repo/    CampaignRepository, CallLogRepository,            │
│          SettingsRepository, ContactsSource, FileTextReader│
│ usecase/ QueuePlanner, ReportBuilder                       │
│ phone/   PhoneNumbers (normalisation, parsing)             │
└───────▲──────────────────▲──────────────────▲──────────────┘
        │                  │                  │
   data/ (JSON/prefs)  engine/ (CampaignEngine,  service/ (foreground
   implementations     AndroidTelephonyGateway)   host + notifications)
```

**Dependency rules (verified by script on this tree):**
* `domain` imports no `android.*` / `androidx.*` (0 imports).
* `engine/CampaignEngine` imports no `android.*` (0 imports) — it can run in a plain JVM unit test with a fake `TelephonyGateway`.
* `ui` never imports `engine`, `data` or `service` implementations (0 imports); it talks to `domain` interfaces through ViewModels.
* `AppContainer` is the only place that wires interfaces to implementations (manual DI; no framework).

## 3. Data flow

```
Compose screen ──action──▶ ViewModel ──▶ Repository / CallEngine
      ▲                                        │
      └──── immutable UiState (StateFlow) ◀────┘
```
* Every screen receives an immutable state object and an `…Actions` interface. No screen reads or writes global state.
* ViewModels expose `StateFlow`; Compose collects with `collectAsStateWithLifecycle()`.
* Repositories expose `StateFlow<List<…>>` as the single source of truth; mutations are atomic (`StateFlow.update`).
* Cross-cutting UI events go through typed channels: `FeedbackBus` (toasts) and `AppActions` (navigation, permissions, share) provided via `CompositionLocal` as an *interface*.
* The engine publishes `EngineState` using language-neutral `EngineMessage` codes; the presentation layer maps them to text (`core/Texts.kt`). The engine never formats strings.

## 4. Calling engine

* `CampaignEngine` owns the state machine (IDLE → RUNNING ⇄ PAUSED/WAITING → FINISHED) and all timers as cancellable coroutines on one dispatcher (main), so its mutable fields are never accessed concurrently.
* It is hosted by `CampaignService`, which only supplies what the OS requires: foreground notification, wake lock, process priority. The service observes `EngineState` and stops itself when the engine finishes; if the system kills the service mid-run it stops the engine so data stays consistent.
* `QueuePlanner` is a pure function (resume semantics + retry candidates).
* `TelephonyGateway` is the only seam to Android telephony / audio / call-log APIs.

## 5. Persistence
JSON via `SharedPreferences`, **serialised and written on `Dispatchers.IO`, debounced (150 ms)**. In-memory state is immutable lists in a `StateFlow`. `allowBackup=false`.

## 6. Behavior changes (intentional)
* New package/app id `com.o2dialer.app`, name **O2Dialer**, version 4.0 — installs next to the old app; old data is not migrated.
* Stage prompt: the engine now emits a unique `StageRequest`; the UI opens/closes the sheet from state (same UX as before).
* `allowBackup=false`.

## 7. Known limits / not verified
* **Not compiled in this environment** (no Android SDK). Verified by static checks only: brace balance, project-symbol imports, Compose/Android imports vs. usage, dependency rules above. First CI build is the real verification.
* Speaker/mic automation depends on the OEM (deprecated API).
* Answer detection requires the Call-log permission.
* Visual design is unchanged from v3.1 on purpose; redesign is a separate command. App icon still the previous placeholder.

## 8. Suggested next commands
1. Unit tests for `QueuePlanner`, `PhoneNumbers`, `CampaignEngine` (fake gateway + virtual time).
2. Release build: R8, icon subset instead of `icons-extended`, signing.
3. Brand pass: O2Dialer identity (icon, colours, copy).
4. Scheduling, backup/export, blocklist.
