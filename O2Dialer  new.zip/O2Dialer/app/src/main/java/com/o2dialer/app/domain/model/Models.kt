package com.o2dialer.app.domain.model

import java.util.UUID

enum class CallStatus(val code: Int) {
    PENDING(0), CALLING(1), ANSWERED(2), NO_ANSWER(3), FAILED(4), COMPLETED(5);

    val isAnswered: Boolean get() = this == ANSWERED || this == COMPLETED
    /** Has a final-or-retryable attempt result (i.e. counted as "called"). */
    val isCalled: Boolean get() = this != PENDING && this != CALLING
    val english: String
        get() = when (this) {
            PENDING -> "Pending"; CALLING -> "Calling"; ANSWERED -> "Answered"
            NO_ANSWER -> "No answer"; FAILED -> "Failed"; COMPLETED -> "Completed"
        }

    companion object {
        fun fromCode(c: Int): CallStatus = values().firstOrNull { it.code == c } ?: PENDING
    }
}

enum class Stage(val code: Int) {
    NONE(0), POTENTIAL(1), NOT_INTERESTED(2), CALL_BACK(3), WHATSAPP(4), VOICEMAIL(5);

    val needsFeedback: Boolean get() = this == POTENTIAL || this == CALL_BACK || this == WHATSAPP
    val english: String
        get() = when (this) {
            NONE -> ""; POTENTIAL -> "Potential"; NOT_INTERESTED -> "Not Interested"
            CALL_BACK -> "Call Back"; WHATSAPP -> "WhatsApp"; VOICEMAIL -> "Voicemail"
        }

    companion object {
        val selectable: List<Stage> = listOf(POTENTIAL, NOT_INTERESTED, CALL_BACK, WHATSAPP, VOICEMAIL)
        fun fromCode(c: Int): Stage = values().firstOrNull { it.code == c } ?: NONE
    }
}

data class Contact(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val number: String,
    val status: CallStatus = CallStatus.PENDING,
    val attempts: Int = 0,
    val durationSec: Int = 0,
    val calledAt: Long = 0L,
    val stage: Stage = Stage.NONE,
    val feedback: String = ""
)

data class Campaign(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val contacts: List<Contact> = emptyList(),
    val simSlot: Int = -1
)

data class CampaignProgress(val total: Int, val called: Int, val answered: Int, val noAnswer: Int, val failed: Int) {
    val remaining: Int get() = total - called
    val pct: Int get() = if (total == 0) 0 else called * 100 / total
}

fun Campaign.progress(): CampaignProgress = CampaignProgress(
    total = contacts.size,
    called = contacts.count { it.status.isCalled },
    answered = contacts.count { it.status.isAnswered },
    noAnswer = contacts.count { it.status == CallStatus.NO_ANSWER },
    failed = contacts.count { it.status == CallStatus.FAILED }
)

data class CallLogEntry(
    val time: Long, val campaignName: String, val contactName: String, val number: String,
    val status: CallStatus, val durationSec: Int, val attempt: Int
)

data class ImportedContact(val name: String, val number: String)
