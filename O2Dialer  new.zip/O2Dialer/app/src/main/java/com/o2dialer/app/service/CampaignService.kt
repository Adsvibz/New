package com.o2dialer.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.o2dialer.app.O2App
import com.o2dialer.app.R
import com.o2dialer.app.core.T
import com.o2dialer.app.core.text
import com.o2dialer.app.domain.engine.EngineLauncher
import com.o2dialer.app.domain.engine.EngineMessage
import com.o2dialer.app.domain.engine.EnginePhase
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.engine.Outcome
import com.o2dialer.app.domain.model.progress
import com.o2dialer.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android host for the calling engine. It only provides what the OS requires:
 * a foreground notification, a wake lock and process priority. All call logic is in CampaignEngine.
 */
class CampaignService : Service() {

    companion object {
        const val ACT_START = "com.o2dialer.app.START"
        const val ACT_PAUSE = "com.o2dialer.app.PAUSE"
        const val ACT_RESUME = "com.o2dialer.app.RESUME"
        const val ACT_STOP = "com.o2dialer.app.STOP"
        const val EXTRA_CAMPAIGN = "campaign"
        const val EXTRA_RESTART = "restart"
        private const val CH_RUN = "campaign_run"
        private const val CH_DONE = "campaign_done"
        private const val ID_RUN = 1
        private const val ID_DONE = 2
    }

    private val container get() = (application as O2App).container
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observeJob: Job? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val engine = container.engine
        when (intent?.action) {
            ACT_START -> {
                startForegroundNow()
                acquireWake()
                engine.start(intent?.getStringExtra(EXTRA_CAMPAIGN) ?: "", intent?.getBooleanExtra(EXTRA_RESTART, false) ?: false)
                observe()
            }
            ACT_PAUSE -> engine.pause()
            ACT_RESUME -> engine.resume()
            ACT_STOP -> engine.stop()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun observe() {
        if (observeJob != null) return
        observeJob = scope.launch {
            container.engine.state.collect { st ->
                if (st.phase == EnginePhase.FINISHED || st.phase == EnginePhase.IDLE) onFinished(st)
                else notificationManager().notify(ID_RUN, notification(st))
            }
        }
    }

    private fun onFinished(st: EngineState) {
        if (st.outcome == Outcome.COMPLETED) {
            notifyDone(st)
            if (container.settingsRepo.settings.value.vibrateOnFinish) buzz()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        releaseWake()
        stopSelf()
    }

    // ------------------------------------------------------------ notifications
    private fun notificationManager() = getSystemService(NotificationManager::class.java)

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 9, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun actionIntent(action: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, CampaignService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun notification(st: EngineState?): Notification {
        val progress = if (st == null) null else container.campaignRepo.get(st.campaignId)?.progress()
        val who = if (st == null) "" else st.currentName.ifEmpty { st.currentNumber }
        val stats = if (progress != null) "${progress.called}/${progress.total} • ${progress.pct}%" else ""
        val paused = st?.phase == EnginePhase.PAUSED
        val title = when {
            st == null -> "O2Dialer"
            who.isNotEmpty() -> T("Calling $who", "جارٍ الاتصال بـ $who")
            else -> st.campaignName
        }
        val text = when {
            st == null -> T("Starting…", "جارٍ البدء…")
            who.isNotEmpty() -> "${st.campaignName} • $stats"
            else -> "${st.message.text(st.messageArg)} • $stats"
        }
        val b = NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat_blend)
            .setColor(0xFF6C47FF.toInt())
            .setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(progress?.total ?: 0, progress?.called ?: 0, false)
            .setContentIntent(openAppIntent())
        if (paused) b.addAction(0, T("Resume", "استئناف"), actionIntent(ACT_RESUME, 1))
        else b.addAction(0, T("Pause", "إيقاف مؤقت"), actionIntent(ACT_PAUSE, 2))
        b.addAction(0, T("Stop", "إيقاف"), actionIntent(ACT_STOP, 3))
        return b.build()
    }

    private fun notifyDone(st: EngineState) {
        val nm = notificationManager()
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Campaign results", NotificationManager.IMPORTANCE_DEFAULT))
        val p = container.campaignRepo.get(st.campaignId)?.progress()
        val text = if (p != null) T(
            "${p.answered} answered • ${p.noAnswer} no answer • ${p.failed} failed",
            "${p.answered} ردّوا • ${p.noAnswer} لم يردّوا • ${p.failed} فشل"
        ) else ""
        nm.notify(ID_DONE, NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_blend)
            .setContentTitle(T("Campaign finished ✓", "اكتملت الحملة ✓") + " · " + st.campaignName)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setColor(0xFF6C47FF.toInt())
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build())
    }

    private fun startForegroundNow() {
        notificationManager().createNotificationChannel(
            NotificationChannel(CH_RUN, "Campaign", NotificationManager.IMPORTANCE_LOW)
        )
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, ID_RUN, notification(null), type)
    }

    // ------------------------------------------------------------ OS plumbing
    private fun acquireWake() {
        releaseWake()
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "o2dialer:campaign").also { it.acquire(8 * 60 * 60 * 1000L) }
    }

    private fun releaseWake() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    private fun buzz() {
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { /* no vibrator */ }
    }

    override fun onDestroy() {
        // If the system kills the service mid-campaign, leave the engine in a consistent state.
        if (container.engine.state.value.isActive) container.engine.stop()
        scope.cancel()
        releaseWake()
        super.onDestroy()
    }
}

class ServiceEngineLauncher(private val context: Context) : EngineLauncher {
    override fun start(campaignId: String, restart: Boolean) {
        val i = Intent(context, CampaignService::class.java)
            .setAction(CampaignService.ACT_START)
            .putExtra(CampaignService.EXTRA_CAMPAIGN, campaignId)
            .putExtra(CampaignService.EXTRA_RESTART, restart)
        ContextCompat.startForegroundService(context, i)
    }
}
