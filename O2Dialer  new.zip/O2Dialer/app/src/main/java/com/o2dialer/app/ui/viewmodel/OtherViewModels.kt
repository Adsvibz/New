package com.o2dialer.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.o2dialer.app.AppContainer
import com.o2dialer.app.domain.engine.CallEngine
import com.o2dialer.app.domain.engine.EngineLauncher
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.repo.CallLogRepository
import com.o2dialer.app.domain.repo.SettingsRepository
import com.o2dialer.app.domain.usecase.ReportBuilder
import kotlinx.coroutines.flow.StateFlow

class LiveViewModel(
    private val engine: CallEngine,
    private val launcher: EngineLauncher
) : ViewModel(), LiveActions {
    val state: StateFlow<EngineState> = engine.state
    override val isActive: Boolean get() = engine.state.value.isActive
    override fun start(campaignId: String, restart: Boolean) = launcher.start(campaignId, restart)
    override fun pause() = engine.pause()
    override fun resume() = engine.resume()
    override fun stop() = engine.stop()
    override fun endCurrentCall() = engine.endCurrentCall()
    override fun stageDone() = engine.stageDone()
}

class LogViewModel(private val callLog: CallLogRepository) : ViewModel(), LogActions {
    val entries: StateFlow<List<CallLogEntry>> = callLog.entries
    override fun clear() = callLog.clear()
    override fun report(): String = ReportBuilder.callLogCsv(callLog.entries.value)
}

class SettingsViewModel(private val repo: SettingsRepository) : ViewModel(), SettingsActions {
    val settings: StateFlow<AppSettings> = repo.settings
    override fun update(transform: (AppSettings) -> AppSettings) = repo.update(transform)
}

/** Builds every ViewModel from the manual container. */
class VmFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = when {
        modelClass.isAssignableFrom(AppViewModel::class.java) ->
            AppViewModel(c.settingsRepo, c.campaignRepo, c.engine, c.feedback) as VM
        modelClass.isAssignableFrom(CampaignsViewModel::class.java) ->
            CampaignsViewModel(c.campaignRepo, c.engine, c.settingsRepo, c.contactsSource, c.fileReader, c.gateway, c.feedback) as VM
        modelClass.isAssignableFrom(LiveViewModel::class.java) -> LiveViewModel(c.engine, c.launcher) as VM
        modelClass.isAssignableFrom(LogViewModel::class.java) -> LogViewModel(c.callLogRepo) as VM
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(c.settingsRepo) as VM
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
