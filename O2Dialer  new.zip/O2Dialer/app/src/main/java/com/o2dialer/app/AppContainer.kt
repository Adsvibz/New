package com.o2dialer.app

import android.app.Application
import com.o2dialer.app.core.FeedbackBus
import com.o2dialer.app.data.AndroidContactsSource
import com.o2dialer.app.data.AndroidFileTextReader
import com.o2dialer.app.data.JsonCallLogRepository
import com.o2dialer.app.data.JsonCampaignRepository
import com.o2dialer.app.data.PrefsSettingsRepository
import com.o2dialer.app.domain.engine.CallEngine
import com.o2dialer.app.domain.engine.EngineLauncher
import com.o2dialer.app.domain.engine.TelephonyGateway
import com.o2dialer.app.domain.repo.CallLogRepository
import com.o2dialer.app.domain.repo.CampaignRepository
import com.o2dialer.app.domain.repo.ContactsSource
import com.o2dialer.app.domain.repo.FileTextReader
import com.o2dialer.app.domain.repo.SettingsRepository
import com.o2dialer.app.engine.AndroidTelephonyGateway
import com.o2dialer.app.engine.CampaignEngine
import com.o2dialer.app.service.ServiceEngineLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Manual dependency container (no DI framework needed at this size).
 * It is the only place that knows which implementation backs each interface.
 */
class AppContainer(app: Application) {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepo: SettingsRepository = PrefsSettingsRepository(app)
    val campaignRepo: CampaignRepository = JsonCampaignRepository(app, appScope)
    val callLogRepo: CallLogRepository = JsonCallLogRepository(app, appScope)
    val contactsSource: ContactsSource = AndroidContactsSource(app)
    val fileReader: FileTextReader = AndroidFileTextReader(app)
    val feedback = FeedbackBus()

    val gateway: TelephonyGateway = AndroidTelephonyGateway(app)
    val engine: CallEngine = CampaignEngine(gateway, campaignRepo, settingsRepo, callLogRepo, appScope)
    val launcher: EngineLauncher = ServiceEngineLauncher(app)
}
