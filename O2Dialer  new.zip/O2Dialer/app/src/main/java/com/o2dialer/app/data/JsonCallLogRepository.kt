package com.o2dialer.app.data

import android.content.Context
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.repo.CallLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class JsonCallLogRepository(context: Context, private val scope: CoroutineScope) : CallLogRepository {
    private val prefs = context.applicationContext.getSharedPreferences("o2dialer_calllog", Context.MODE_PRIVATE)
    private val _entries = MutableStateFlow(load())
    override val entries: StateFlow<List<CallLogEntry>> = _entries.asStateFlow()
    private var saveJob: Job? = null

    override fun add(entry: CallLogEntry) {
        _entries.update { (listOf(entry) + it).take(MAX) }
        scheduleSave()
    }

    override fun clear() {
        _entries.value = emptyList()
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(150)
            val snapshot = _entries.value
            withContext(Dispatchers.IO) { prefs.edit().putString("log", encode(snapshot)).apply() }
        }
    }

    private fun load(): List<CallLogEntry> {
        val raw = prefs.getString("log", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                CallLogEntry(
                    time = o.getLong("t"), campaignName = o.optString("l"), contactName = o.optString("n"),
                    number = o.optString("p"), status = CallStatus.fromCode(o.optInt("s")),
                    durationSec = o.optInt("d"), attempt = o.optInt("a")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun encode(list: List<CallLogEntry>): String {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("t", it.time).put("l", it.campaignName).put("n", it.contactName)
                .put("p", it.number).put("s", it.status.code).put("d", it.durationSec).put("a", it.attempt))
        }
        return a.toString()
    }

    private companion object { const val MAX = 1000 }
}
