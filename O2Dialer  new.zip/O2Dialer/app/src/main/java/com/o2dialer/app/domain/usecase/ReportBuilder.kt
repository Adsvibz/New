package com.o2dialer.app.domain.usecase

import com.o2dialer.app.core.fmtTime
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.model.Campaign

object ReportBuilder {
    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun campaignCsv(c: Campaign): String =
        "Name,Number,Status,Duration(s),Called at,Stage,Feedback\n" + c.contacts.joinToString("\n") {
            listOf(
                csv(it.name), it.number, it.status.english, it.durationSec.toString(),
                if (it.calledAt > 0) fmtTime(it.calledAt) else "", it.stage.english, csv(it.feedback)
            ).joinToString(",")
        }

    fun callLogCsv(items: List<CallLogEntry>): String =
        "Time,Campaign,Name,Number,Status,Duration(s),Attempt\n" + items.joinToString("\n") {
            "${fmtTime(it.time)},${csv(it.campaignName)},${csv(it.contactName)},${it.number}," +
                "${it.status.english},${it.durationSec},${it.attempt}"
        }
}
