package com.o2dialer.app.data

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.ContactsSource
import com.o2dialer.app.domain.repo.FileTextReader

class AndroidContactsSource(context: Context) : ContactsSource {
    private val resolver = context.applicationContext.contentResolver

    override fun loadPhoneContacts(): List<ImportedContact> {
        val out = ArrayList<ImportedContact>()
        val seen = HashSet<String>()
        runCatching {
            resolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = PhoneNumbers.clean(c.getString(1) ?: "")
                    if (n.length >= 3 && seen.add(n)) out.add(ImportedContact(c.getString(0) ?: "", n))
                }
            }
        }
        return out
    }
}

class AndroidFileTextReader(context: Context) : FileTextReader {
    private val resolver = context.applicationContext.contentResolver

    override fun readText(uri: String): String =
        runCatching { resolver.openInputStream(Uri.parse(uri))?.bufferedReader()?.use { it.readText() } }
            .getOrNull() ?: ""
}
