package com.o2dialer.app.ui.viewmodel

import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.model.Stage

/** User intents on campaign data. Implemented by CampaignsViewModel; screens only see this interface. */
interface CampaignsActions {
    fun create(name: String, simSlot: Int): String
    fun update(campaignId: String, name: String, simSlot: Int)
    fun delete(campaignId: String)
    fun resetProgress(campaignId: String)
    fun removeDuplicates(campaignId: String)
    fun addContacts(campaignId: String, items: List<ImportedContact>)
    fun addFromText(campaignId: String, text: String)
    fun importFile(campaignId: String, uri: String)
    suspend fun loadPhoneContacts(): List<ImportedContact>
    fun editContact(campaignId: String, contactId: String, name: String, number: String)
    fun removeContact(campaignId: String, contactId: String)
    fun setStage(campaignId: String, contactId: String, stage: Stage, feedback: String)
    fun campaignReport(campaignId: String): String
    fun refreshSimLabels()
}

/** User intents on the running campaign. */
interface LiveActions {
    val isActive: Boolean
    fun start(campaignId: String, restart: Boolean)
    fun pause()
    fun resume()
    fun stop()
    fun endCurrentCall()
    fun stageDone()
}

interface SettingsActions {
    fun update(transform: (AppSettings) -> AppSettings)
}

interface LogActions {
    fun clear()
    fun report(): String
}
