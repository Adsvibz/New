package com.o2dialer.app.data

import android.content.Context
import android.telephony.TelephonyManager
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

class PrefsSettingsRepository(context: Context) : SettingsRepository {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("o2dialer_settings", Context.MODE_PRIVATE)
    private val simCountryCode: String = runCatching {
        val iso = (app.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).simCountryIso ?: ""
        PhoneNumbers.callingCodeForIso(iso)
    }.getOrDefault("")

    private val _settings = MutableStateFlow(read())
    override val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    override fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        prefs.edit().putString("json", encode(next).toString()).apply()
    }

    override fun effectiveCountryCode(): String =
        _settings.value.countryCode.filter { it.isDigit() }.ifEmpty { simCountryCode }

    private fun read(): AppSettings {
        val raw = prefs.getString("json", null) ?: return AppSettings()
        return runCatching { decode(JSONObject(raw)) }.getOrDefault(AppSettings())
    }

    private fun encode(s: AppSettings): JSONObject = JSONObject()
        .put("lang", s.lang).put("delaySec", s.delaySec).put("randomDelay", s.randomDelay)
        .put("delayMaxSec", s.delayMaxSec).put("startCountdown", s.startCountdown).put("maxCallSec", s.maxCallSec)
        .put("retries", s.retries).put("loops", s.loops).put("shuffle", s.shuffle)
        .put("skipAnswered", s.skipAnswered).put("useCallLog", s.useCallLog).put("countryCode", s.countryCode)
        .put("autoSpeaker", s.autoSpeaker).put("askStage", s.askStage).put("stageWaitSec", s.stageWaitSec)
        .put("quietEnabled", s.quietEnabled).put("quietFrom", s.quietFrom).put("quietTo", s.quietTo)
        .put("keepScreenOn", s.keepScreenOn).put("vibrateOnFinish", s.vibrateOnFinish)
        .put("themeMode", s.themeMode).put("dynamicColor", s.dynamicColor)

    private fun decode(o: JSONObject): AppSettings {
        val d = AppSettings()
        return AppSettings(
            lang = o.optInt("lang", d.lang),
            delaySec = o.optInt("delaySec", d.delaySec),
            randomDelay = o.optBoolean("randomDelay", d.randomDelay),
            delayMaxSec = o.optInt("delayMaxSec", d.delayMaxSec),
            startCountdown = o.optInt("startCountdown", d.startCountdown),
            maxCallSec = o.optInt("maxCallSec", d.maxCallSec),
            retries = o.optInt("retries", d.retries),
            loops = o.optInt("loops", d.loops),
            shuffle = o.optBoolean("shuffle", d.shuffle),
            skipAnswered = o.optBoolean("skipAnswered", d.skipAnswered),
            useCallLog = o.optBoolean("useCallLog", d.useCallLog),
            countryCode = o.optString("countryCode", d.countryCode),
            autoSpeaker = o.optBoolean("autoSpeaker", d.autoSpeaker),
            askStage = o.optBoolean("askStage", d.askStage),
            stageWaitSec = o.optInt("stageWaitSec", d.stageWaitSec),
            quietEnabled = o.optBoolean("quietEnabled", d.quietEnabled),
            quietFrom = o.optInt("quietFrom", d.quietFrom),
            quietTo = o.optInt("quietTo", d.quietTo),
            keepScreenOn = o.optBoolean("keepScreenOn", d.keepScreenOn),
            vibrateOnFinish = o.optBoolean("vibrateOnFinish", d.vibrateOnFinish),
            themeMode = o.optInt("themeMode", d.themeMode),
            dynamicColor = o.optBoolean("dynamicColor", d.dynamicColor)
        )
    }
}
