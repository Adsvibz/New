package com.o2dialer.app.domain.repo

import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.Contact
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.model.Stage
import kotlinx.coroutines.flow.StateFlow

/** Single source of truth for campaigns. All mutations go through here. */
interface CampaignRepository {
    val campaigns: StateFlow<List<Campaign>>
    fun get(id: String): Campaign?
    fun create(name: String, simSlot: Int): String
    fun update(id: String, transform: (Campaign) -> Campaign)
    fun delete(id: String)
    fun updateContact(campaignId: String, contactId: String, transform: (Contact) -> Contact)
    fun removeContact(campaignId: String, contactId: String)
    /** Returns how many contacts were actually added (duplicates / invalid numbers are skipped). */
    fun addContacts(campaignId: String, items: List<ImportedContact>, defaultCc: String): Int
    /** Returns how many duplicates were removed. */
    fun removeDuplicates(campaignId: String): Int
    /** Back to "not called yet". Answered contacts can be kept. Stages are always kept. */
    fun resetProgress(campaignId: String, keepAnswered: Boolean)
    fun setStage(campaignId: String, contactId: String, stage: Stage, feedback: String)
}

interface CallLogRepository {
    val entries: StateFlow<List<CallLogEntry>>
    fun add(entry: CallLogEntry)
    fun clear()
}

interface SettingsRepository {
    val settings: StateFlow<AppSettings>
    fun update(transform: (AppSettings) -> AppSettings)
    /** User-selected country code, otherwise guessed from the SIM country. */
    fun effectiveCountryCode(): String
}

interface ContactsSource {
    /** Blocking. Call from a background dispatcher. */
    fun loadPhoneContacts(): List<ImportedContact>
}

interface FileTextReader {
    /** Blocking. Call from a background dispatcher. */
    fun readText(uri: String): String
}
