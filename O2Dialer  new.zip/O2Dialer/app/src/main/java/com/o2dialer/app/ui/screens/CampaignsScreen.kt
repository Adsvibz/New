@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.T
import com.o2dialer.app.core.fmtDur
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.CampaignProgress
import com.o2dialer.app.domain.model.Contact
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.ui.LocalAppActions
import com.o2dialer.app.ui.Tab
import com.o2dialer.app.ui.components.ActionChip
import com.o2dialer.app.ui.components.AppBar
import com.o2dialer.app.ui.components.Avatar
import com.o2dialer.app.ui.components.BButton
import com.o2dialer.app.ui.components.BProgress
import com.o2dialer.app.ui.components.BTextField
import com.o2dialer.app.ui.components.BulkDialog
import com.o2dialer.app.ui.components.CampaignDialog
import com.o2dialer.app.ui.components.ConfirmDialog
import com.o2dialer.app.ui.components.ContactDialog
import com.o2dialer.app.ui.components.EmptyState
import com.o2dialer.app.ui.components.IconTile
import com.o2dialer.app.ui.components.NumText
import com.o2dialer.app.ui.components.Panel
import com.o2dialer.app.ui.components.PermissionBanner
import com.o2dialer.app.ui.components.PhoneContactsDialog
import com.o2dialer.app.ui.components.Pill
import com.o2dialer.app.ui.components.ProgressRing
import com.o2dialer.app.ui.components.StagePill
import com.o2dialer.app.ui.components.StatusPill
import com.o2dialer.app.ui.components.WhatsAppButton
import com.o2dialer.app.ui.theme.Rd
import com.o2dialer.app.ui.theme.Sem
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.theme.color
import com.o2dialer.app.ui.viewmodel.CampaignItem
import com.o2dialer.app.ui.viewmodel.CampaignsActions
import com.o2dialer.app.ui.viewmodel.CampaignsUiState

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ============================================================ campaigns list
@Composable
fun CampaignsScreen(state: CampaignsUiState, actions: CampaignsActions, onMenu: () -> Unit) {
    val app = LocalAppActions.current
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Campaign?>(null) }
    var deleting by remember { mutableStateOf<Campaign?>(null) }

    Scaffold(
        topBar = {
            AppBar(T("Campaigns", "الحملات"), onMenu,
                subtitle = if (state.items.isEmpty()) null else T("${state.items.size} campaigns", "${state.items.size} حملة"))
        },
        floatingActionButton = {
            if (state.items.isNotEmpty()) ExtendedFloatingActionButton(
                onClick = { creating = true }, shape = RoundedCornerShape(Rd.l),
                containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text(T("New campaign", "حملة جديدة"), style = MaterialTheme.typography.labelLarge) }
            )
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (state.items.isEmpty()) {
            EmptyState(Icons.Rounded.Campaign, T("No campaigns yet", "لا توجد حملات بعد"),
                T("Create a campaign, add your contacts and start calling.", "أنشئ حملة وأضف جهات الاتصال وابدأ الاتصال."),
                Modifier.padding(pad), actionText = T("Create campaign", "إنشاء حملة"), onAction = { creating = true })
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                items(state.items, key = { it.campaign.id }) { item ->
                    CampaignCard(item, actions,
                        onOpen = { app.openCampaign(item.campaign.id) },
                        onEdit = { editing = item.campaign }, onDelete = { deleting = item.campaign })
                }
            }
        }
    }

    if (creating) CampaignDialog(null, state.simLabels, { creating = false }) { name, sim ->
        creating = false
        app.openCampaign(actions.create(name, sim))
    }
    editing?.let { c ->
        CampaignDialog(c, state.simLabels, { editing = null }) { name, sim -> editing = null; actions.update(c.id, name, sim) }
    }
    deleting?.let { c ->
        ConfirmDialog(T("Delete \"${c.name}\" and all its numbers?", "حذف \"${c.name}\" وكل أرقامها؟"), { deleting = null }) {
            deleting = null; actions.delete(c.id)
        }
    }
}

@Composable
private fun CampaignCard(item: CampaignItem, actions: CampaignsActions, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val app = LocalAppActions.current
    val c = item.campaign
    val p = item.progress
    var menu by remember { mutableStateOf(false) }
    val sim = when (c.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }
    val grey = MaterialTheme.colorScheme.onSurfaceVariant
    val st = when {
        item.running -> Triple(T("Running", "قيد التشغيل"), Sem.success, Icons.Rounded.PlayArrow)
        p.total == 0 -> Triple(T("Empty", "فارغة"), grey, Icons.Rounded.Info)
        p.called == 0 -> Triple(T("Not started", "لم تبدأ"), grey, Icons.Rounded.Schedule)
        p.remaining > 0 -> Triple(T("In progress", "جارية"), Sem.info, Icons.Rounded.Replay)
        else -> Triple(T("Completed", "مكتملة"), Sem.success, Icons.Rounded.CheckCircle)
    }

    Panel(Modifier.fillMaxWidth(), onClick = onOpen) {
        Column(Modifier.padding(Sp.l)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Campaign)
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(c.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${p.total} " + T("contacts", "جهة اتصال") + "  •  " + sim,
                        style = MaterialTheme.typography.labelMedium, color = grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(T("Edit campaign", "تعديل الحملة")) },
                            leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text(T("View results", "عرض النتائج")) },
                            leadingIcon = { Icon(Icons.Rounded.BarChart, null) },
                            onClick = { menu = false; app.openResults(c.id) })
                        DropdownMenuItem(text = { Text(T("Reset progress", "إعادة ضبط التقدم")) },
                            leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                            onClick = { menu = false; actions.resetProgress(c.id) })
                        DropdownMenuItem(text = { Text(T("Remove duplicates", "حذف المكرر")) },
                            leadingIcon = { Icon(Icons.Rounded.ContentPaste, null) },
                            onClick = { menu = false; actions.removeDuplicates(c.id) })
                        DropdownMenuItem(text = { Text(T("Share report", "مشاركة التقرير")) },
                            leadingIcon = { Icon(Icons.Rounded.Share, null) },
                            onClick = { menu = false; app.share(actions.campaignReport(c.id)) })
                        DropdownMenuItem(text = { Text(T("Delete", "حذف"), color = Sem.danger) },
                            leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Sem.danger) },
                            onClick = { menu = false; onDelete() })
                    }
                }
            }
            if (p.total > 0) {
                Spacer(Modifier.height(Sp.l))
                BProgress(p.pct / 100f, color = if (p.remaining == 0) Sem.success else MaterialTheme.colorScheme.primary, height = 6.dp)
                Spacer(Modifier.height(Sp.m))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Pill(st.first, st.second, st.third)
                    Spacer(Modifier.weight(1f))
                    Text(T("${p.pct}% • ${p.answered} answered", "${p.pct}% • ${p.answered} ردّوا"),
                        style = MaterialTheme.typography.labelMedium, color = grey)
                }
            } else {
                Spacer(Modifier.height(Sp.m))
                Pill(st.first, st.second, st.third)
            }
        }
    }
}

// ============================================================ campaign contacts
@Composable
fun CampaignDetailScreen(campaignId: String, state: CampaignsUiState, actions: CampaignsActions) {
    val app = LocalAppActions.current
    val item = state.find(campaignId)
    if (item == null) { LaunchedEffect(Unit) { app.openCampaign(null) }; return }
    val campaign = item.campaign
    val p = item.progress
    var query by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Contact?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) actions.importFile(campaignId, uri.toString())
    }
    val shown = campaign.contacts.filter { query.isBlank() || it.name.contains(query, true) || it.number.contains(query) }
    val simText = when (campaign.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }

    val chips: @Composable () -> Unit = {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            ActionChip(Icons.Rounded.Add, T("Add number", "إضافة رقم")) { dlg = "add" }
            ActionChip(Icons.Rounded.ContentPaste, T("Paste", "لصق")) { dlg = "bulk" }
            ActionChip(Icons.Rounded.UploadFile, "CSV / TXT") { importer.launch(arrayOf("*/*")) }
            ActionChip(Icons.Rounded.Contacts, T("Contacts", "جهات الاتصال")) { app.ensureContactsPermission { dlg = "contacts" } }
        }
    }

    Scaffold(
        topBar = {
            AppBar(campaign.name, null, onBack = { app.openCampaign(null) },
                subtitle = T("${p.total} contacts · $simText", "${p.total} جهة · $simText"))
        },
        bottomBar = {
            if (campaign.contacts.isNotEmpty()) {
                val label = when {
                    p.called == 0 -> T("Start campaign", "ابدأ الحملة")
                    p.remaining > 0 -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                    else -> T("Restart campaign", "إعادة تشغيل الحملة")
                }
                Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m)) {
                    BButton(label, { app.startCampaign(campaignId, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.PlayArrow)
                }
            }
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (campaign.contacts.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = Sp.xl), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                PermissionBanner()
                chips()
                if (state.importing) LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)))
                EmptyState(Icons.Rounded.Groups, T("No contacts yet", "لا توجد أرقام"),
                    T("Add numbers manually, paste them, import a CSV/TXT file or pick from your contacts.",
                        "أضف الأرقام يدويًا أو بالصق أو من ملف CSV/TXT أو من جهات الاتصال."))
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xl),
                verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                item { PermissionBanner() }
                if (state.importing) item { LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(50))) }
                item { SummaryPanel(p) }
                item { chips() }
                item {
                    BTextField(query, { query = it }, placeholder = T("Search name or number", "بحث بالاسم أو الرقم"),
                        leading = Icons.Rounded.Search)
                }
                if (shown.isEmpty()) item { Text(T("No matches", "لا نتائج"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(shown, key = { it.id }) { c -> ContactRow(c, campaignId, actions) { editing = c } }
            }
        }
    }

    when (dlg) {
        "add" -> ContactDialog(null, { dlg = "" }) { n, num ->
            dlg = ""; actions.addContacts(campaignId, listOf(com.o2dialer.app.domain.model.ImportedContact(n, num)))
        }
        "bulk" -> BulkDialog({ dlg = "" }) { t -> dlg = ""; actions.addFromText(campaignId, t) }
        "contacts" -> PhoneContactsDialog({ actions.loadPhoneContacts() }, { dlg = "" }) { sel -> dlg = ""; actions.addContacts(campaignId, sel) }
    }
    editing?.let { e ->
        ContactDialog(e, { editing = null }) { n, num -> editing = null; actions.editContact(campaignId, e.id, n, num) }
    }
}

@Composable
private fun SummaryPanel(p: CampaignProgress) {
    Panel(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(Sp.l), verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(p.pct / 100f, 72.dp, 7.dp, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline) {
                Text("${p.pct}%", style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.width(Sp.l))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                Text(T("${p.called} of ${p.total} called", "${p.called} من ${p.total} تم الاتصال"), style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                    Legend(Sem.success, T("${p.answered} answered", "${p.answered} ردّوا"))
                    Legend(Sem.warning, T("${p.noAnswer} no answer", "${p.noAnswer} لم يردّوا"))
                }
                Legend(Sem.danger, T("${p.failed} failed", "${p.failed} فشل"))
            }
        }
    }
}

@Composable
private fun ContactRow(c: Contact, campaignId: String, actions: CampaignsActions, onEdit: () -> Unit) {
    val app = LocalAppActions.current
    val answered = c.status.isAnswered
    Panel(Modifier.fillMaxWidth(), onClick = onEdit) {
        Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.name.ifBlank { c.number }, if (c.stage != Stage.NONE) c.stage.color() else MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Sp.m))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                if (c.name.isNotBlank()) {
                    Text(c.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NumText(c.number,
                        style = if (c.name.isBlank()) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodySmall,
                        color = if (c.name.isBlank()) Color.Unspecified else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (answered && c.durationSec > 0) {
                        Spacer(Modifier.width(Sp.s))
                        Pill(fmtDur(c.durationSec), Sem.success, Icons.Rounded.Schedule)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (c.status != CallStatus.PENDING) StatusPill(c.status)
                    if (c.stage != Stage.NONE) StagePill(c.stage) { app.openStageSheet(campaignId, c.id) }
                    else if (answered) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) { app.openStageSheet(campaignId, c.id) }
                }
            }
            if (c.stage != Stage.NONE) {
                WhatsAppButton(c.number)
                Spacer(Modifier.width(Sp.xs))
            }
            IconButton(onClick = { actions.removeContact(campaignId, c.id) }) {
                Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
