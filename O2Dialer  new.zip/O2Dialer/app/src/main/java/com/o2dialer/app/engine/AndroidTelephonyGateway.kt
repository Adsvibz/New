package com.o2dialer.app.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.o2dialer.app.domain.engine.CallPhase
import com.o2dialer.app.domain.engine.TelephonyGateway

/** All direct Android telephony / audio / call-log access lives here. */
class AndroidTelephonyGateway(context: Context) : TelephonyGateway {
    private val ctx = context.applicationContext
    private val tm = ctx.getSystemService(TelephonyManager::class.java)
    private val telecom = ctx.getSystemService(TelecomManager::class.java)
    private var modernCallback: Any? = null
    private var legacyListener: PhoneStateListener? = null

    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun phaseOf(state: Int): CallPhase = when (state) {
        TelephonyManager.CALL_STATE_OFFHOOK -> CallPhase.OFFHOOK
        TelephonyManager.CALL_STATE_RINGING -> CallPhase.RINGING
        else -> CallPhase.IDLE
    }

    @RequiresApi(31)
    private inner class Callback(val sink: (CallPhase) -> Unit) : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) = sink(phaseOf(state))
    }

    @Suppress("DEPRECATION")
    override fun startObserving(onPhase: (CallPhase) -> Unit) {
        stopObserving()
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = Callback(onPhase)
            modernCallback = cb
            tm.registerTelephonyCallback(ctx.mainExecutor, cb)
        } else {
            val l = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) { onPhase(phaseOf(state)) }
            }
            legacyListener = l
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    @Suppress("DEPRECATION")
    override fun stopObserving() {
        try {
            if (Build.VERSION.SDK_INT >= 31) (modernCallback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            else legacyListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Exception) { /* nothing registered */ }
        modernCallback = null
        legacyListener = null
    }

    override fun placeCall(number: String, simSlot: Int) {
        val extras = Bundle()
        if (simSlot >= 0) {
            runCatching {
                telecom.callCapablePhoneAccounts.getOrNull(simSlot)?.let {
                    extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it)
                }
            }
        }
        telecom.placeCall(Uri.fromParts("tel", number, null), extras)
    }

    @Suppress("DEPRECATION")
    override fun endCall() {
        try {
            if (Build.VERSION.SDK_INT >= 28 && granted(Manifest.permission.ANSWER_PHONE_CALLS)) telecom.endCall()
        } catch (e: Exception) { /* nothing to end */ }
    }

    override fun canReadCallLog(): Boolean = granted(Manifest.permission.READ_CALL_LOG)

    override fun outgoingCallDurationSince(sinceMillis: Long): Int? = try {
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.DURATION),
            "${CallLog.Calls.DATE} >= ? AND ${CallLog.Calls.TYPE} = ?",
            arrayOf(sinceMillis.toString(), CallLog.Calls.OUTGOING_TYPE.toString()),
            "${CallLog.Calls.DATE} ASC"
        )?.use { c -> if (c.moveToFirst()) c.getInt(0) else null }
    } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    override fun setCallAudio(speakerOnMicMuted: Boolean) {
        try {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.isSpeakerphoneOn = speakerOnMicMuted
            am.isMicrophoneMute = speakerOnMicMuted
        } catch (e: Exception) { /* some devices refuse audio changes */ }
    }

    override fun simLabels(): List<String> {
        val base = mutableListOf("SIM 1", "SIM 2")
        if (granted(Manifest.permission.READ_PHONE_STATE)) {
            runCatching {
                val sm = ctx.getSystemService(SubscriptionManager::class.java)
                sm.activeSubscriptionInfoList?.forEach { i ->
                    val slot = i.simSlotIndex
                    if (slot in 0..1) base[slot] = "SIM ${slot + 1} · ${i.carrierName}"
                }
            }
        }
        return base
    }
}
