package com.o2dialer.app.domain.usecase

import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign

/**
 * Resume semantics: only contacts that were never called (plus retry candidates) are queued.
 * Contacts that already have a result are skipped, so "Start" continues where you stopped.
 */
object QueuePlanner {
    data class Plan(val queue: List<String>, val retriesLeft: Map<String, Int>)

    fun plan(campaign: Campaign, s: AppSettings, order: (List<String>) -> List<String> = { it.shuffled() }): Plan {
        var fresh = campaign.contacts
            .filter { it.status == CallStatus.PENDING || it.status == CallStatus.CALLING }
            .map { it.id }
        if (s.shuffle) fresh = order(fresh)
        val retry = if (s.retries > 0) {
            campaign.contacts.filter {
                (it.status == CallStatus.NO_ANSWER || it.status == CallStatus.FAILED) && it.attempts - 1 < s.retries
            }
        } else emptyList()
        return Plan(
            queue = fresh + retry.map { it.id },
            retriesLeft = retry.associate { it.id to (s.retries - (it.attempts - 1)) }
        )
    }
}
