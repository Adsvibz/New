package com.o2dialer.app.core

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

/** Feedback kinds shared by banners and toasts. */
object Tk {
    const val INFO = 0
    const val SUCCESS = 1
    const val ERROR = 2
    const val WARN = 3
}

data class UiToast(val kind: Int, val msg: String, val id: Long)

/** Lets ViewModels / the engine layer report user-visible feedback without touching the UI. */
class FeedbackBus {
    private val _toasts = MutableSharedFlow<UiToast>(extraBufferCapacity = 8)
    val toasts: SharedFlow<UiToast> = _toasts

    fun notify(kind: Int, msg: String) {
        _toasts.tryEmit(UiToast(kind, msg, System.nanoTime()))
    }
}
