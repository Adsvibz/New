package com.o2dialer.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.o2dialer.app.core.FeedbackBus
import com.o2dialer.app.core.Lang
import com.o2dialer.app.core.UiToast
import com.o2dialer.app.domain.engine.CallEngine
import com.o2dialer.app.domain.engine.EnginePhase
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.engine.Outcome
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.progress
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.CampaignRepository
import com.o2dialer.app.domain.repo.SettingsRepository
import com.o2dialer.app.ui.LiveBadge
import com.o2dialer.app.ui.Tab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StageRef(val campaignId: String, val contactId: String)

data class NavState(
    val tab: Int = Tab.CAMPAIGNS,
    val selectedCampaignId: String? = null,
    val runCampaignId: String? = null,
    val resultsCampaignId: String? = null,
    val previousTab: Int = Tab.CAMPAIGNS
)

/** Immutable state of the app shell: navigation, toast, stage prompt, live badge, settings. */
data class AppUiState(
    val nav: NavState = NavState(),
    val settings: AppSettings = AppSettings(),
    val toast: UiToast? = null,
    val stageTarget: StageRef? = null,
    val live: LiveBadge? = null,
    val permissionTick: Int = 0
) {
    val canGoBack: Boolean get() = nav.tab != Tab.CAMPAIGNS || nav.selectedCampaignId != null
}

class AppViewModel(
    private val settingsRepo: SettingsRepository,
    private val campaignRepo: CampaignRepository,
    private val engine: CallEngine,
    private val feedback: FeedbackBus
) : ViewModel() {

    private val _ui = MutableStateFlow(AppUiState(settings = settingsRepo.settings.value))
    val ui: StateFlow<AppUiState> = _ui.asStateFlow()

    private var handledStageToken = 0L
    private var stageFromEngine = false
    private var lastPhase: EnginePhase = engine.state.value.phase

    init {
        viewModelScope.launch {
            settingsRepo.settings.collect { s ->
                Lang.code = s.lang
                _ui.update { it.copy(settings = s) }
            }
        }
        viewModelScope.launch { feedback.toasts.collect { t -> _ui.update { it.copy(toast = t) } } }
        viewModelScope.launch {
            combine(engine.state, campaignRepo.campaigns) { e, list ->
                if (e.isActive) LiveBadge(e.campaignId, list.find { it.id == e.campaignId }?.progress()?.pct ?: 0) else null
            }.collect { badge -> _ui.update { it.copy(live = badge) } }
        }
        viewModelScope.launch { engine.state.collect { onEngine(it) } }
    }

    /** The engine asks for a call result / finishes a campaign: translate that into UI state. */
    private fun onEngine(e: EngineState) {
        val req = e.stageRequest
        if (req != null && req.token != handledStageToken) {
            handledStageToken = req.token
            stageFromEngine = true
            _ui.update { it.copy(stageTarget = StageRef(req.campaignId, req.contactId)) }
        } else if (req == null && stageFromEngine) {
            stageFromEngine = false
            _ui.update { it.copy(stageTarget = null) }
        }
        if (e.phase == EnginePhase.FINISHED && lastPhase != EnginePhase.FINISHED && e.outcome == Outcome.COMPLETED) {
            nav { it.copy(tab = Tab.RESULTS, resultsCampaignId = e.campaignId, selectedCampaignId = null) }
        }
        lastPhase = e.phase
    }

    private fun nav(f: (NavState) -> NavState) = _ui.update { it.copy(nav = f(it.nav)) }

    fun navigate(tab: Int) = nav { it.copy(tab = tab, selectedCampaignId = if (tab == Tab.CAMPAIGNS) null else it.selectedCampaignId) }

    fun openSettings() = nav { if (it.tab == Tab.SETTINGS) it else it.copy(previousTab = it.tab, tab = Tab.SETTINGS) }

    fun openCampaign(id: String?) = nav { it.copy(tab = Tab.CAMPAIGNS, selectedCampaignId = id) }

    fun openResults(id: String?) = nav { it.copy(tab = Tab.RESULTS, resultsCampaignId = id) }

    fun selectRun(id: String) = nav { it.copy(runCampaignId = id) }

    /** Returns true when the back press was consumed by in-app navigation. */
    fun back(): Boolean {
        val n = _ui.value.nav
        return when {
            n.tab == Tab.SETTINGS -> { nav { it.copy(tab = it.previousTab) }; true }
            n.tab == Tab.CAMPAIGNS && n.selectedCampaignId != null -> { nav { it.copy(selectedCampaignId = null) }; true }
            n.tab != Tab.CAMPAIGNS -> { nav { it.copy(tab = Tab.CAMPAIGNS) }; true }
            else -> false
        }
    }

    fun openStageSheet(campaignId: String, contactId: String) {
        stageFromEngine = false
        _ui.update { it.copy(stageTarget = StageRef(campaignId, contactId)) }
    }

    fun closeStageSheet() {
        stageFromEngine = false
        _ui.update { it.copy(stageTarget = null) }
    }

    fun notify(kind: Int, msg: String) = feedback.notify(kind, msg)

    fun dismissToast(id: Long) = _ui.update { if (it.toast?.id == id) it.copy(toast = null) else it }

    fun bumpPermissions() = _ui.update { it.copy(permissionTick = it.permissionTick + 1) }

    fun whatsAppUrl(number: String): String {
        val digits = PhoneNumbers.smartNumber(number, settingsRepo.effectiveCountryCode()).filter { it.isDigit() }
        return "https://wa.me/$digits"
    }
}
