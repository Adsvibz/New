@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui.components

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.T
import com.o2dialer.app.core.fmtDur
import com.o2dialer.app.core.label
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.Contact
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.ui.LocalAppActions
import com.o2dialer.app.ui.LocalPermissionTick
import com.o2dialer.app.ui.hasPermission
import com.o2dialer.app.ui.theme.Rd
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.theme.color
import kotlin.math.roundToInt

// ============================================================ SIM picker
@Composable
fun SimPicker(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val colors = listOf(Color(0xFF64748B), Color(0xFF3B82F6), Color(0xFFEC4899))
    val names = listOf(T("Default SIM", "الشريحة الافتراضية")) + labels
    Column(verticalArrangement = Arrangement.spacedBy(Sp.s)) {
        names.forEachIndexed { i, label ->
            val on = selected == i - 1
            val c = colors[minOf(i, colors.lastIndex)]
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m))
                    .background(c.copy(alpha = if (on) 0.14f else 0.05f))
                    .border(if (on) 2.dp else 1.dp, c.copy(alpha = if (on) 1f else 0.25f), RoundedCornerShape(Rd.m))
                    .clickable { onSelect(i - 1) }.padding(horizontal = Sp.l, vertical = Sp.m),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.SimCard, null, tint = c)
                Spacer(Modifier.width(Sp.m))
                Text(label, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (on) Icon(Icons.Rounded.Check, null, tint = c)
            }
        }
    }
}

// ============================================================ dialogs
@Composable
fun CampaignDialog(initial: Campaign?, simLabels: List<String>, onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sim by remember { mutableIntStateOf(initial?.simSlot ?: -1) }
    BDialog(
        title = if (initial == null) T("New campaign", "حملة جديدة") else T("Campaign settings", "إعدادات الحملة"),
        onDismiss = onDismiss, confirmText = T("Save", "حفظ"), confirmEnabled = name.isNotBlank(),
        onConfirm = { onSave(name.trim(), sim) }
    ) {
        BTextField(name, { name = it }, label = T("Campaign name", "اسم الحملة"))
        SectionLabel(T("SIM card for this campaign", "الشريحة المستخدمة لهذه الحملة"))
        SimPicker(simLabels, sim) { sim = it }
    }
}

@Composable
fun ContactDialog(initial: Contact?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var n by remember { mutableStateOf(initial?.name ?: "") }
    var p by remember { mutableStateOf(initial?.number ?: "") }
    BDialog(
        title = if (initial == null) T("Add number", "إضافة رقم") else T("Edit contact", "تعديل"),
        onDismiss = onDismiss, confirmText = T("Save", "حفظ"), confirmEnabled = PhoneNumbers.clean(p).length >= 3,
        onConfirm = { onSave(n, p) }
    ) {
        BTextField(n, { n = it }, label = T("Name (optional)", "الاسم (اختياري)"), leading = Icons.Rounded.Person)
        BTextField(p, { p = it }, label = T("Phone number", "رقم الموبايل"), leading = Icons.Rounded.Phone,
            keyboardType = KeyboardType.Phone,
            supporting = T("Country code is added automatically", "كود الدولة بيتضاف تلقائيًا"))
    }
}

@Composable
fun BulkDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    BDialog(
        title = T("Paste numbers", "لصق أرقام"), onDismiss = onDismiss, confirmText = T("Add", "إضافة"),
        confirmEnabled = t.isNotBlank(), onConfirm = { onAdd(t) }
    ) {
        BTextField(t, { t = it }, singleLine = false, minLines = 6,
            placeholder = T("One number per line\nor: Name,Number", "رقم في كل سطر\nأو: الاسم,الرقم"))
    }
}

@Composable
fun ConfirmDialog(text: String, onDismiss: () -> Unit, destructive: Boolean = true, onOk: () -> Unit) {
    BDialog(title = null, onDismiss = onDismiss, confirmText = T("Confirm", "تأكيد"), onConfirm = onOk, destructive = destructive) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun PhoneContactsDialog(load: suspend () -> List<ImportedContact>, onDismiss: () -> Unit, onAdd: (List<ImportedContact>) -> Unit) {
    val loaded by produceState<List<ImportedContact>?>(initialValue = null) { value = load() }
    var q by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    val all = loaded
    val shown = all?.filter { q.isBlank() || it.name.contains(q, true) || it.number.contains(q) } ?: emptyList()
    BDialog(
        title = T("Contacts", "جهات الاتصال") + if (sel.isNotEmpty()) " (${sel.size})" else "",
        onDismiss = onDismiss, confirmText = T("Add", "إضافة"), confirmEnabled = sel.isNotEmpty(),
        onConfirm = { onAdd((all ?: emptyList()).filter { it.number in sel }) }
    ) {
        BTextField(q, { q = it }, placeholder = T("Search", "بحث"), leading = Icons.Rounded.Search)
        if (all == null) {
            repeat(5) { Skeleton(Modifier.fillMaxWidth().height(44.dp)) }
        } else if (all.isEmpty()) {
            Text(T("No contacts found", "لا توجد جهات اتصال"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Row {
                TextButton(onClick = { sel.clear(); sel.addAll(shown.map { it.number }) }) { Text(T("Select all", "تحديد الكل")) }
                TextButton(onClick = { sel.clear() }) { Text(T("Clear", "مسح")) }
            }
            LazyColumn(Modifier.height(280.dp)) {
                items(shown, key = { it.number }) { c ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.s))
                        .clickable { if (c.number in sel) sel.remove(c.number) else sel.add(c.number) }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.number in sel, onCheckedChange = null, modifier = Modifier.padding(horizontal = Sp.m))
                        Column {
                            Text(c.name.ifBlank { c.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            NumText(c.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================ permissions banner (warning state)
@Composable
fun PermissionBanner() {
    val ctx = LocalContext.current
    val app = LocalAppActions.current
    val tick = LocalPermissionTick.current
    val ok = remember(tick) {
        ctx.hasPermission(Manifest.permission.CALL_PHONE) && ctx.hasPermission(Manifest.permission.READ_PHONE_STATE)
    }
    if (!ok) {
        Banner(com.o2dialer.app.core.Tk.WARN, T("Permissions needed", "صلاحيات مطلوبة"),
            T("O2Dialer needs calling and phone-state access to run campaigns.", "O2Dialer يحتاج صلاحية الاتصال وحالة الهاتف لتشغيل الحملات."),
            actionText = T("Grant", "منح")) { app.requestCallPermissions(null) }
    }
}

// ============================================================ call-result (stage) sheet
@Composable
fun StageTile(s: Stage, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = s.color()
    Column(
        modifier.clip(RoundedCornerShape(Rd.l)).background(c.copy(alpha = if (selected) 0.20f else 0.08f))
            .border(if (selected) 2.dp else 1.dp, c.copy(alpha = if (selected) 1f else 0.3f), RoundedCornerShape(Rd.l))
            .clickable { onClick() }.padding(vertical = Sp.l, horizontal = Sp.m),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Sp.s)
    ) {
        Icon(stageIcon(s), null, tint = c, modifier = Modifier.size(26.dp))
        Text(s.label(), color = c, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center)
    }
}

/**
 * Stateless w.r.t. data: the caller decides what choosing / saving / closing means.
 * [onChoose] fires on every tile tap; [onSaveFeedback] when the note is saved; [onClose] on skip / dismiss.
 */
@Composable
fun StageSheet(
    contact: Contact,
    onChoose: (Stage, String) -> Unit,
    onSaveFeedback: (Stage, String) -> Unit,
    onClose: () -> Unit
) {
    var selected by remember(contact.id) { mutableStateOf(contact.stage) }
    var fb by remember(contact.id) { mutableStateOf(contact.feedback) }

    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        shape = RoundedCornerShape(topStart = Rd.xl, topEnd = Rd.xl),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier.padding(horizontal = Sp.xl).padding(bottom = Sp.xxl).navigationBarsPadding().imePadding(),
            verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            Text(T("How did the call go?", "إزاي كانت المكالمة؟"), style = MaterialTheme.typography.headlineSmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(contact.name.ifBlank { contact.number })
                Spacer(Modifier.width(Sp.m))
                Column {
                    Text(contact.name.ifBlank { contact.number }, style = MaterialTheme.typography.titleMedium, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                    Row {
                        NumText(contact.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (contact.durationSec > 0) Text("  •  ${fmtDur(contact.durationSec)}", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Stage.selectable.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                    row.forEach { s ->
                        StageTile(s, selected == s, Modifier.weight(1f)) {
                            selected = s
                            onChoose(s, fb)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (selected.needsFeedback) {
                BTextField(fb, { fb = it }, singleLine = false, minLines = 3, label = T("Feedback", "ملاحظات"),
                    placeholder = T("What did they say?", "قال إيه العميل؟"))
                BButton(T("Save feedback", "حفظ الملاحظات"), { onSaveFeedback(selected, fb.trim()) }, Modifier.fillMaxWidth())
            } else {
                BButton(T("Skip", "تخطي"), onClose, Modifier.fillMaxWidth(), kind = BtnKind.Ghost, compact = true)
            }
        }
    }
}

// ============================================================ settings widgets
@Composable
fun SettingsSection(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(icon, size = 36.dp)
                Spacer(Modifier.width(Sp.m))
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
fun SliderRow(
    title: String, value: Int, min: Int, max: Int, suffix: String, zeroText: String? = null,
    onChange: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Pill(if (value == 0 && zeroText != null) zeroText else "$value $suffix".trim(), cs.primary)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary, inactiveTrackColor = cs.outline)
        )
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(Sp.m))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
