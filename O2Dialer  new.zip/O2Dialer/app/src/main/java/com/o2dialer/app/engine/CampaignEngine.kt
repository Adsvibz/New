package com.o2dialer.app.engine

import com.o2dialer.app.domain.engine.CallEngine
import com.o2dialer.app.domain.engine.CallPhase
import com.o2dialer.app.domain.engine.EngineMessage
import com.o2dialer.app.domain.engine.EnginePhase
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.engine.Outcome
import com.o2dialer.app.domain.engine.StageRequest
import com.o2dialer.app.domain.engine.TelephonyGateway
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.CallLogRepository
import com.o2dialer.app.domain.repo.CampaignRepository
import com.o2dialer.app.domain.repo.SettingsRepository
import com.o2dialer.app.domain.usecase.QueuePlanner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.random.Random

/**
 * The calling engine. It knows nothing about Compose, Activities, Services or notifications:
 * it talks to the phone through [TelephonyGateway], to data through repositories and
 * publishes immutable [EngineState]. All work happens on [scope]'s (main) dispatcher, so the
 * mutable fields below are never touched concurrently. Timers are cancellable coroutines.
 */
class CampaignEngine(
    private val gateway: TelephonyGateway,
    private val campaigns: CampaignRepository,
    private val settingsRepo: SettingsRepository,
    private val callLog: CallLogRepository,
    private val scope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val hourOfDay: () -> Int = { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
) : CallEngine {

    private val _state = MutableStateFlow(EngineState())
    override val state: StateFlow<EngineState> = _state.asStateFlow()

    private val s: AppSettings get() = settingsRepo.settings.value

    private val queue = ArrayDeque<String>()
    private val retriesLeft = HashMap<String, Int>()
    private var campaignId = ""
    private var currentId: String? = null
    private var callStartedAt = 0L
    private var offhookAt = 0L
    private var sawOffhook = false
    private var busy = false
    private var running = false
    private var paused = false
    private var awaiting = false
    private var loop = 1

    private var nextJob: Job? = null
    private var noCallJob: Job? = null
    private var hangupJob: Job? = null
    private var audioJob: Job? = null
    private var evalJob: Job? = null

    // ------------------------------------------------------------ public commands
    override fun start(campaignId: String, restart: Boolean) {
        if (running) return
        val first = campaigns.get(campaignId)
        if (first == null || first.contacts.isEmpty()) {
            _state.value = EngineState(
                phase = EnginePhase.FINISHED, campaignId = campaignId, campaignName = first?.name ?: "",
                message = EngineMessage.EMPTY_CAMPAIGN, outcome = Outcome.ERROR
            )
            return
        }
        this.campaignId = campaignId
        running = true; paused = false; busy = false; awaiting = false; loop = 1
        if (restart) campaigns.resetProgress(campaignId, s.skipAnswered)
        val campaign = campaigns.get(campaignId) ?: first
        val countdownMs = s.startCountdown * 1000L
        _state.value = EngineState(
            phase = EnginePhase.RUNNING, campaignId = campaignId, campaignName = campaign.name,
            loops = s.loops, loop = 1, message = EngineMessage.STARTING_IN, nextAtMillis = clock() + countdownMs
        )
        try {
            gateway.startObserving { onPhase(it) }
        } catch (e: SecurityException) {
            finish(EngineMessage.PERM_PHONE_STATE, Outcome.ERROR); return
        }
        if (buildQueue(campaign) == 0) { finish(EngineMessage.NOTHING_LEFT, Outcome.STOPPED); return }
        scheduleNextCall(countdownMs)
    }

    override fun pause() {
        if (!running || paused) return
        paused = true
        nextJob?.cancel(); nextJob = null
        _state.update { it.copy(phase = EnginePhase.PAUSED, message = EngineMessage.PAUSED, nextAtMillis = 0L) }
    }

    override fun resume() {
        if (!running || !paused) return
        paused = false
        _state.update { it.copy(phase = EnginePhase.RUNNING, message = EngineMessage.RESUMING) }
        if (!busy) scheduleNextCall(1000)
    }

    override fun stop() {
        if (running) finish(EngineMessage.STOPPED, Outcome.STOPPED)
    }

    override fun endCurrentCall() = gateway.endCall()

    override fun stageDone() {
        _state.update { it.copy(stageRequest = null, awaitingStage = false) }
        if (!running || !awaiting) return
        awaiting = false
        nextJob?.cancel(); nextJob = null
        scheduleNext()
    }

    // ------------------------------------------------------------ queue / scheduling
    private fun buildQueue(c: Campaign): Int {
        val plan = QueuePlanner.plan(c, s)
        queue.clear(); queue.addAll(plan.queue)
        retriesLeft.clear(); retriesLeft.putAll(plan.retriesLeft)
        return queue.size
    }

    private fun inAllowedHours(): Boolean {
        if (!s.quietEnabled) return true
        val h = hourOfDay()
        return if (s.quietFrom <= s.quietTo) h >= s.quietFrom && h < s.quietTo else h >= s.quietFrom || h < s.quietTo
    }

    private fun launchAfter(ms: Long, block: () -> Unit): Job = scope.launch { delay(ms); block() }

    private fun scheduleNextCall(ms: Long) {
        nextJob?.cancel()
        nextJob = launchAfter(ms) { next() }
    }

    private fun scheduleNext() {
        if (!running) return
        if (paused) {
            _state.update { it.copy(phase = EnginePhase.PAUSED, message = EngineMessage.PAUSED, nextAtMillis = 0L) }
            return
        }
        if (awaiting) {
            val ms = s.stageWaitSec * 1000L
            _state.update {
                it.copy(phase = EnginePhase.RUNNING, currentName = "", currentNumber = "", awaitingStage = true,
                    message = EngineMessage.CHOOSE_RESULT, nextAtMillis = clock() + ms)
            }
            scheduleNextCall(ms)
            return
        }
        if (queue.isEmpty()) { scheduleNextCall(0); return }
        val lo = s.delaySec
        val hi = maxOf(lo, s.delayMaxSec)
        val sec = if (s.randomDelay) Random.nextInt(lo, hi + 1) else lo
        _state.update {
            it.copy(phase = EnginePhase.RUNNING, currentName = "", currentNumber = "", awaitingStage = false,
                message = EngineMessage.NEXT_CALL_IN, nextAtMillis = clock() + sec * 1000L)
        }
        scheduleNextCall(sec * 1000L)
    }

    private fun next() {
        nextJob = null
        if (!running || paused) return
        if (awaiting) {                      // the user didn't answer in time: move on and close the prompt
            awaiting = false
            _state.update { it.copy(stageRequest = null, awaitingStage = false) }
        }
        if (queue.isEmpty()) {
            if (loop < s.loops) {
                loop++
                campaigns.resetProgress(campaignId, s.skipAnswered)
                val c = campaigns.get(campaignId)
                if (c == null || buildQueue(c) == 0) { finish(EngineMessage.COMPLETED, Outcome.COMPLETED); return }
                _state.update { it.copy(loop = loop) }
            } else {
                finish(EngineMessage.COMPLETED, Outcome.COMPLETED); return
            }
        }
        if (!inAllowedHours()) {
            _state.update {
                it.copy(phase = EnginePhase.WAITING, nextAtMillis = 0L, message = EngineMessage.WAITING_HOURS,
                    messageArg = s.quietFrom)
            }
            scheduleNextCall(30_000)
            return
        }
        place(queue.removeFirst())
    }

    // ------------------------------------------------------------ one call
    private fun place(id: String) {
        val campaign = campaigns.get(campaignId)
        val contact = campaign?.contacts?.find { it.id == id }
        if (campaign == null || contact == null) { scheduleNext(); return }
        busy = true; currentId = id; sawOffhook = false; callStartedAt = clock()
        campaigns.updateContact(campaignId, id) { it.copy(status = CallStatus.CALLING, attempts = it.attempts + 1) }
        _state.update {
            it.copy(phase = EnginePhase.RUNNING, currentName = contact.name, currentNumber = contact.number,
                message = EngineMessage.CALLING, nextAtMillis = 0L, awaitingStage = false)
        }
        try {
            gateway.placeCall(PhoneNumbers.smartNumber(contact.number, settingsRepo.effectiveCountryCode()), campaign.simSlot)
            noCallJob?.cancel()
            noCallJob = launchAfter(25_000) { onNoCall() }
        } catch (e: SecurityException) {
            finish(EngineMessage.PERM_CALL, Outcome.ERROR)
        }
    }

    private fun onPhase(phase: CallPhase) {
        if (!running) return
        if (phase == CallPhase.OFFHOOK) {
            if (currentId != null && !sawOffhook) {
                sawOffhook = true
                offhookAt = clock()
                noCallJob?.cancel()
                if (s.maxCallSec > 0) {
                    hangupJob?.cancel()
                    hangupJob = launchAfter(s.maxCallSec * 1000L) { gateway.endCall() }
                }
                if (s.autoSpeaker) {
                    audioJob?.cancel()
                    audioJob = scope.launch {
                        // the dialer UI resets audio routing a few times while connecting
                        for (d in longArrayOf(400, 1100, 2000)) {
                            delay(d)
                            if (sawOffhook) gateway.setCallAudio(true)
                        }
                    }
                }
            }
        } else if (phase == CallPhase.IDLE && sawOffhook && currentId != null) {
            sawOffhook = false
            hangupJob?.cancel(); audioJob?.cancel()
            if (s.autoSpeaker) gateway.setCallAudio(false)
            val id = currentId!!
            currentId = null
            val dur = ((clock() - offhookAt) / 1000).toInt()
            val since = callStartedAt
            evalJob?.cancel()
            evalJob = launchAfter(1500) { evaluate(id, since, dur, 0) }
        }
    }

    private fun onNoCall() {
        val id = currentId ?: return
        if (sawOffhook) return
        currentId = null
        record(id, CallStatus.FAILED, 0)
    }

    private fun evaluate(id: String, since: Long, dur: Int, tries: Int) {
        if (!running) return
        if (s.useCallLog && gateway.canReadCallLog()) {
            val d = gateway.outgoingCallDurationSince(since)
            if (d == null && tries < 2) {       // the system call log can lag behind the call end
                evalJob = launchAfter(1500) { evaluate(id, since, dur, tries + 1) }
                return
            }
            if (d != null) { record(id, if (d > 0) CallStatus.ANSWERED else CallStatus.NO_ANSWER, d); return }
        }
        record(id, CallStatus.COMPLETED, dur)
    }

    private fun record(id: String, status: CallStatus, dur: Int) {
        busy = false
        val campaign = campaigns.get(campaignId)
        if (campaign == null) { scheduleNext(); return }
        val contact = campaign.contacts.find { it.id == id }
        val started = callStartedAt
        campaigns.updateContact(campaignId, id) { it.copy(status = status, durationSec = dur, calledAt = started) }
        if (contact != null) {
            callLog.add(CallLogEntry(clock(), campaign.name, contact.name, contact.number, status, dur, contact.attempts))
        }

        // Ask for the call result (stage) after answered calls only.
        if (contact != null && s.askStage && status.isAnswered && !(status == CallStatus.COMPLETED && dur < 8)) {
            _state.update { it.copy(stageRequest = StageRequest(campaignId, id, clock())) }
            if (s.stageWaitSec > 0) awaiting = true
        }

        val unanswered = status == CallStatus.NO_ANSWER || status == CallStatus.FAILED
        val left = retriesLeft.getOrPut(id) { s.retries - ((contact?.attempts ?: 1) - 1) }
        if (unanswered && left > 0) {
            retriesLeft[id] = left - 1
            queue.addLast(id)
            _state.update { it.copy(message = EngineMessage.RETRY_LATER) }
        }
        scheduleNext()
    }

    private fun cancelJobs() {
        nextJob?.cancel(); noCallJob?.cancel(); hangupJob?.cancel(); audioJob?.cancel(); evalJob?.cancel()
        nextJob = null; noCallJob = null; hangupJob = null; audioJob = null; evalJob = null
    }

    private fun finish(msg: EngineMessage, outcome: Outcome) {
        if (currentId != null || sawOffhook) gateway.endCall()
        running = false; paused = false; busy = false; currentId = null; sawOffhook = false; awaiting = false
        cancelJobs()
        if (s.autoSpeaker) gateway.setCallAudio(false)
        gateway.stopObserving()
        if (campaignId.isNotEmpty()) {
            // an interrupted call goes back to "not called yet", so Resume picks it up again
            campaigns.update(campaignId) { c ->
                c.copy(contacts = c.contacts.map {
                    if (it.status == CallStatus.CALLING) it.copy(status = CallStatus.PENDING) else it
                })
            }
        }
        _state.update {
            it.copy(phase = EnginePhase.FINISHED, message = msg, messageArg = 0, currentName = "", currentNumber = "",
                nextAtMillis = 0L, awaitingStage = false, outcome = outcome)
        }
    }
}
