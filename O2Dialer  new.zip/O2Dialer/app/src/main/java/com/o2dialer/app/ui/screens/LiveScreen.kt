@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.core.text
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.engine.EnginePhase
import com.o2dialer.app.domain.engine.Outcome
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.CampaignProgress
import com.o2dialer.app.ui.LocalAppActions
import com.o2dialer.app.ui.Tab
import com.o2dialer.app.ui.components.AppBar
import com.o2dialer.app.ui.components.Avatar
import com.o2dialer.app.ui.components.Banner
import com.o2dialer.app.ui.components.BButton
import com.o2dialer.app.ui.components.BtnKind
import com.o2dialer.app.ui.components.NumText
import com.o2dialer.app.ui.components.Panel
import com.o2dialer.app.ui.components.PermissionBanner
import com.o2dialer.app.ui.components.ProgressRing
import com.o2dialer.app.ui.components.PulseDot
import com.o2dialer.app.ui.components.SectionLabel
import com.o2dialer.app.ui.components.isCompact
import com.o2dialer.app.ui.theme.Brand
import com.o2dialer.app.ui.theme.Rd
import com.o2dialer.app.ui.theme.Sem
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.viewmodel.CampaignsUiState
import com.o2dialer.app.ui.viewmodel.LiveActions
import kotlinx.coroutines.delay

@Composable
private fun MiniStat(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text(label, color = Color.White.copy(alpha = 0.78f), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StatCard(label: String, value: Int, color: Color, modifier: Modifier) {
    Panel(modifier) {
        Column(Modifier.padding(vertical = Sp.m).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", style = MaterialTheme.typography.headlineSmall, color = color)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Sp.m))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun LiveScreen(
    engine: EngineState,
    campaigns: CampaignsUiState,
    settings: AppSettings,
    selectedRunId: String?,
    live: LiveActions,
    onMenu: () -> Unit
) {
    val app = LocalAppActions.current
    val active = engine.isActive
    val compact = isCompact()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }
    val item = campaigns.find(engine.campaignId)
    val finished = engine.phase == EnginePhase.FINISHED
    val showHero = (active || finished) && item != null
    val failed = engine.outcome == Outcome.ERROR

    Scaffold(
        topBar = { AppBar(T("Live", "التشغيل"), onMenu) },
        bottomBar = { if (active) Controls(engine, live, compact) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.xl, vertical = Sp.s),
            verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            PermissionBanner()
            if (showHero && item != null) {
                val p = item.progress
                Hero(engine, p, now, compact)
                if (finished) Banner(if (failed) Tk.ERROR else Tk.SUCCESS, engine.message.text(engine.messageArg))
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m), modifier = Modifier.fillMaxWidth()) {
                    StatCard(T("Answered", "ردّوا"), p.answered, Sem.success, Modifier.weight(1f))
                    StatCard(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, Modifier.weight(1f))
                    StatCard(T("Failed", "فشل"), p.failed, Sem.danger, Modifier.weight(1f))
                }
                if (active && !settings.shuffle) UpNext(item.campaign)
            }
            if (!active) {
                if (finished && item != null && !failed) {
                    BButton(T("View campaign results", "عرض نتائج الحملة"), { app.openResults(engine.campaignId) },
                        Modifier.fillMaxWidth(), kind = BtnKind.Tonal, icon = Icons.Rounded.BarChart)
                }
                Launcher(campaigns, settings, selectedRunId)
            }
            Spacer(Modifier.height(Sp.l))
        }
    }
}

@Composable
private fun Hero(e: EngineState, p: CampaignProgress, now: Long, compact: Boolean) {
    val finished = e.phase == EnginePhase.FINISHED
    val calling = e.phase == EnginePhase.RUNNING && e.currentNumber.isNotEmpty()
    val secs = if (e.nextAtMillis > now) ((e.nextAtMillis - now + 999) / 1000).toInt() else 0
    val msg = e.message.text(e.messageArg)

    val label = when {
        finished -> if (e.outcome == Outcome.ERROR) T("Stopped", "توقفت") else T("Finished", "انتهت")
        e.phase == EnginePhase.PAUSED -> T("Paused", "متوقفة")
        e.phase == EnginePhase.WAITING -> T("Waiting", "في الانتظار")
        calling -> T("Calling now", "جارٍ الاتصال")
        e.awaitingStage -> T("Your input", "بانتظارك")
        else -> T("Next call", "الاتصال التالي")
    }
    val big = when {
        calling -> e.currentName.ifBlank { e.currentNumber }
        finished -> msg
        e.phase == EnginePhase.PAUSED -> T("Paused", "متوقفة مؤقتًا")
        e.awaitingStage -> T("Choose the call result", "اختر نتيجة المكالمة")
        e.phase == EnginePhase.WAITING -> T("Waiting", "في الانتظار")
        secs > 0 -> "${secs}s"
        else -> msg.ifBlank { "…" }
    }
    val small = when {
        calling && e.currentName.isNotBlank() -> e.currentNumber
        finished -> T("${p.answered} answered · ${p.noAnswer} no answer · ${p.failed} failed",
            "${p.answered} ردّوا · ${p.noAnswer} لم يردّوا · ${p.failed} فشل")
        e.phase == EnginePhase.PAUSED -> T("Tap Resume to continue", "اضغط استئناف للمتابعة")
        e.awaitingStage && secs > 0 -> T("Continuing in ${secs}s", "المتابعة بعد ${secs} ث")
        e.phase == EnginePhase.WAITING -> msg
        secs > 0 -> msg
        else -> ""
    }

    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.xl)).background(Brand).padding(Sp.xxl)) {
        Column(verticalArrangement = Arrangement.spacedBy(Sp.l), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (finished) Icon(Icons.Rounded.CheckCircle, null, tint = Color.White, modifier = Modifier.size(16.dp))
                else PulseDot(Color.White, 8.dp)
                Spacer(Modifier.width(Sp.s))
                Text(label, color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text(e.campaignName, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelLarge,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(big, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = if (compact) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.headlineMedium)
                if (small.isNotEmpty()) {
                    if (calling && e.currentName.isNotBlank()) NumText(small, color = Color.White.copy(alpha = 0.88f),
                        style = MaterialTheme.typography.titleMedium)
                    else Text(small, color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodyMedium)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProgressRing(p.pct / 100f, 84.dp, 8.dp, Color.White, Color.White.copy(alpha = 0.25f)) {
                    Text("${p.pct}%", color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.width(Sp.xl))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MiniStat(p.total, T("Total", "الإجمالي"))
                    MiniStat(p.called, T("Called", "تم الاتصال"))
                    MiniStat(p.remaining, T("Left", "المتبقي"))
                }
            }
            if (e.loops > 1) Text(T("Round ${e.loop} of ${e.loops}", "الجولة ${e.loop} من ${e.loops}"),
                color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun UpNext(campaign: Campaign) {
    val next = campaign.contacts.filter { it.status == CallStatus.PENDING }.take(3)
    if (next.isNotEmpty()) {
        Panel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                SectionLabel(T("Up next", "التالي"))
                next.forEach { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name.ifBlank { c.number }, size = 34.dp)
                        Spacer(Modifier.width(Sp.m))
                        Column {
                            Text(c.name.ifBlank { c.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            if (c.name.isNotBlank()) NumText(c.number, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Controls(e: EngineState, live: LiveActions, compact: Boolean) {
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 10.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m),
            horizontalArrangement = Arrangement.spacedBy(Sp.s)
        ) {
            if (e.phase == EnginePhase.PAUSED)
                BButton(T("Resume", "استئناف"), { live.resume() }, Modifier.weight(1.4f), icon = Icons.Rounded.PlayArrow, compact = true)
            else
                BButton(T("Pause", "إيقاف مؤقت"), { live.pause() }, Modifier.weight(1.4f),
                    kind = BtnKind.Tonal, icon = Icons.Rounded.Pause, compact = true)
            BButton(T("End call", "إنهاء"), { live.endCurrentCall() }, Modifier.weight(1f),
                kind = BtnKind.Outline, icon = Icons.Rounded.SkipNext, compact = true, iconOnly = compact)
            BButton(T("Stop", "إيقاف"), { live.stop() }, Modifier.weight(1f),
                kind = BtnKind.Danger, icon = Icons.Rounded.Stop, compact = true, iconOnly = compact)
        }
    }
}

@Composable
private fun Launcher(campaigns: CampaignsUiState, settings: AppSettings, selectedRunId: String?) {
    val app = LocalAppActions.current
    val selected = campaigns.find(selectedRunId) ?: campaigns.items.firstOrNull()
    val selId = selected?.campaign?.id
    val p = selected?.progress

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            SectionLabel(T("Choose a campaign", "اختر الحملة"))
            if (campaigns.items.isEmpty()) {
                Text(T("Create a campaign first.", "أنشئ حملة أولاً."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                BButton(T("Go to campaigns", "الذهاب إلى الحملات"), { app.navigate(Tab.CAMPAIGNS) }, kind = BtnKind.Tonal, compact = true)
            }
            campaigns.items.forEach { it0 ->
                val c = it0.campaign
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).clickable { app.selectRun(c.id) }
                        .background(if (c.id == selId) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                        .padding(horizontal = Sp.s, vertical = Sp.xs),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = c.id == selId, onClick = { app.selectRun(c.id) })
                    Column(Modifier.weight(1f)) {
                        Text(c.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(T("${it0.progress.total} contacts · ${it0.progress.remaining} left", "${it0.progress.total} جهة · ${it0.progress.remaining} متبقي"),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (selId != null && p != null && p.total > 0) {
        val resumable = p.called > 0 && p.remaining > 0
        BButton(
            when {
                resumable -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                p.called > 0 -> T("Restart campaign", "إعادة تشغيل الحملة")
                else -> T("Start campaign", "ابدأ الحملة")
            },
            { app.startCampaign(selId, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
        )
        if (resumable) {
            BButton(T("Restart from the beginning", "ابدأ من الأول"), { app.startCampaign(selId, true) },
                Modifier.fillMaxWidth(), kind = BtnKind.Outline, icon = Icons.Rounded.Refresh)
        }
    }

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionLabel(T("Run setup", "إعدادات التشغيل"), Modifier.weight(1f))
                TextButton(onClick = { app.openSettings() }) { Text(T("Change", "تعديل")) }
            }
            val gap = if (settings.randomDelay) "${settings.delaySec}–${settings.delayMaxSec}s" else "${settings.delaySec}s"
            InfoRow(Icons.Rounded.Timer, T("Delay between calls: $gap", "الانتظار بين المكالمات: $gap"))
            InfoRow(Icons.Rounded.Replay, T("Retries: ${settings.retries} · Rounds: ${settings.loops}", "إعادة المحاولة: ${settings.retries} · الجولات: ${settings.loops}"))
            InfoRow(Icons.Rounded.VolumeUp, T("Speaker & muted mic: ${if (settings.autoSpeaker) "on" else "off"}",
                "السماعة وكتم المايك: ${if (settings.autoSpeaker) "مفعّل" else "مغلق"}"))
        }
    }
}
