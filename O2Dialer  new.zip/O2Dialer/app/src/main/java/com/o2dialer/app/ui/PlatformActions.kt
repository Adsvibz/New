package com.o2dialer.app.ui

/** Things only an Activity can do. The Compose layer receives this interface, never the Activity itself. */
interface PlatformActions {
    fun requestCallPermissions(after: (() -> Unit)?)
    fun ensureContactsPermission(after: () -> Unit)
    fun share(text: String)
    fun openUrl(url: String)
    fun setKeepScreenOn(on: Boolean)
}
