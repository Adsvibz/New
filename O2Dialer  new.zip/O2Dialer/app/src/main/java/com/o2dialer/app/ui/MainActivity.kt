package com.o2dialer.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.o2dialer.app.AppContainer
import com.o2dialer.app.O2App
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.ui.viewmodel.AppViewModel
import com.o2dialer.app.ui.viewmodel.VmFactory

/**
 * The only Activity. It owns what needs an Activity (permission dialogs, share sheet, window flags)
 * and hosts the Compose tree. All app state lives in ViewModels.
 */
class MainActivity : ComponentActivity(), PlatformActions {

    private val container: AppContainer get() = (application as O2App).container
    private val appVm: AppViewModel by viewModels { VmFactory(container) }

    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            appVm.bumpPermissions()
            if (hasPermission(Manifest.permission.CALL_PHONE) && hasPermission(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
            else appVm.notify(Tk.ERROR, T("Calling and phone-state permissions are required", "صلاحيات الاتصال وحالة الهاتف مطلوبة"))
            afterPerms = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            appVm.bumpPermissions()
            if (granted) afterContacts?.invoke()
            else appVm.notify(Tk.ERROR, T("Contacts permission was denied", "تم رفض صلاحية جهات الاتصال"))
            afterContacts = null
        }

    override fun requestCallPermissions(after: (() -> Unit)?) {
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !hasPermission(it) }
        if (missing.isEmpty()) { after?.invoke(); return }
        afterPerms = after
        permLauncher.launch(missing.toTypedArray())
    }

    override fun ensureContactsPermission(after: () -> Unit) {
        if (hasPermission(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    override fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(i, null))
    }

    override fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            appVm.notify(Tk.ERROR, T("WhatsApp is not available", "واتساب غير متاح"))
        }
    }

    override fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val factory = VmFactory(container)
        setContent { AppRoot(factory, this@MainActivity) }
    }

    override fun onResume() {
        super.onResume()
        appVm.bumpPermissions()
    }
}
