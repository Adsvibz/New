package com.o2dialer.app.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Current UI language. Backed by Compose state so every composable using [T] recomposes on change. */
object Lang {
    var code by mutableIntStateOf(0)   // 0 = English, 1 = Arabic
}

/** English by default, Arabic when selected in Settings. */
fun T(en: String, ar: String): String = if (Lang.code == 1) ar else en
