@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.core.fmtDur
import com.o2dialer.app.core.fmtTime
import com.o2dialer.app.core.label
import com.o2dialer.app.domain.model.CallLogEntry
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Contact
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.ui.LocalAppActions
import com.o2dialer.app.ui.Tab
import com.o2dialer.app.ui.components.AppBar
import com.o2dialer.app.ui.components.Avatar
import com.o2dialer.app.ui.components.Banner
import com.o2dialer.app.ui.components.BProgress
import com.o2dialer.app.ui.components.ConfirmDialog
import com.o2dialer.app.ui.components.EmptyState
import com.o2dialer.app.ui.components.IconTile
import com.o2dialer.app.ui.components.NumText
import com.o2dialer.app.ui.components.Panel
import com.o2dialer.app.ui.components.Pill
import com.o2dialer.app.ui.components.StagePill
import com.o2dialer.app.ui.components.StatusPill
import com.o2dialer.app.ui.components.WhatsAppButton
import com.o2dialer.app.ui.components.stageIcon
import com.o2dialer.app.ui.theme.Rd
import com.o2dialer.app.ui.theme.Sem
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.theme.color
import com.o2dialer.app.ui.theme.statusColor
import com.o2dialer.app.ui.viewmodel.CampaignsActions
import com.o2dialer.app.ui.viewmodel.CampaignsUiState
import com.o2dialer.app.ui.viewmodel.LogActions

@Composable
private fun FilterTile(label: String, value: Int, color: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(Rd.m)).background(color.copy(alpha = if (selected) 0.18f else 0.07f))
            .border(if (selected) 2.dp else 1.dp, color.copy(alpha = if (selected) 1f else 0.25f), RoundedCornerShape(Rd.m))
            .clickable { onClick() }.padding(vertical = Sp.m),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$value", style = MaterialTheme.typography.headlineSmall, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ResultRow(c: Contact, campaignId: String) {
    val app = LocalAppActions.current
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.m), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(c.name.ifBlank { c.number }, if (c.stage != Stage.NONE) c.stage.color() else statusColor(c.status))
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(c.name.ifBlank { c.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (c.name.isNotBlank()) NumText(c.number, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (c.stage != Stage.NONE) WhatsAppButton(c.number)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.horizontalScroll(rememberScrollState())) {
                StatusPill(c.status)
                if (c.calledAt > 0) Pill(fmtTime(c.calledAt), MaterialTheme.colorScheme.onSurfaceVariant, Icons.Rounded.History)
                if (c.durationSec > 0) Pill(fmtDur(c.durationSec), Sem.success, Icons.Rounded.Schedule)
                if (c.stage != Stage.NONE) StagePill(c.stage) { app.openStageSheet(campaignId, c.id) }
                else if (c.status.isAnswered) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) {
                    app.openStageSheet(campaignId, c.id)
                }
            }
            if (c.feedback.isNotBlank()) {
                Text(c.feedback, style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ResultsScreen(state: CampaignsUiState, selectedId: String?, actions: CampaignsActions, onMenu: () -> Unit) {
    val app = LocalAppActions.current
    val item = state.find(selectedId) ?: state.items.firstOrNull()
    var f by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            AppBar(T("Results", "النتائج"), onMenu, subtitle = item?.campaign?.name, actions = {
                if (item != null) IconButton(onClick = { app.share(actions.campaignReport(item.campaign.id)) }) {
                    Icon(Icons.Rounded.Share, null)
                }
            })
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (item == null) {
            EmptyState(Icons.Rounded.BarChart, T("No results yet", "لا توجد نتائج بعد"),
                T("Run a campaign and its results will appear here.", "شغّل حملة وستظهر نتائجها هنا."), Modifier.padding(pad),
                actionText = T("Go to campaigns", "الذهاب إلى الحملات"), onAction = { app.navigate(Tab.CAMPAIGNS) })
        } else {
            val campaign = item.campaign
            val p = item.progress
            val rows = campaign.contacts.filter {
                when {
                    f == 0 -> it.status.isCalled
                    f == 1 -> it.status.isAnswered
                    f == 2 -> it.status == CallStatus.NO_ANSWER
                    f == 3 -> it.status == CallStatus.FAILED
                    f >= 10 -> it.stage.code == f - 10
                    else -> true
                }
            }.sortedByDescending { it.calledAt }
            val staged = campaign.contacts.count { it.stage != Stage.NONE }
            val filterName = when {
                f == 0 -> T("All called numbers", "كل الأرقام المتصل بها")
                f == 1 -> T("Answered", "ردّوا")
                f == 2 -> T("No answer", "لم يردّوا")
                f == 3 -> T("Failed", "فشل")
                else -> Stage.fromCode(f - 10).label()
            }
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 100.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.l)) {

                if (state.items.size > 1) item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                        state.items.forEach { it0 ->
                            FilterChip(selected = it0.campaign.id == campaign.id,
                                onClick = { f = 0; app.openResults(it0.campaign.id) },
                                label = { Text(it0.campaign.name, maxLines = 1) })
                        }
                    }
                }

                if (p.total > 0 && p.remaining == 0) item {
                    Banner(Tk.SUCCESS, T("Campaign completed", "اكتملت الحملة"),
                        T("${p.answered} of ${p.total} answered", "${p.answered} من ${p.total} ردّوا"))
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(T("Overview", "نظرة عامة"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Text("${p.pct}%", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                            }
                            BProgress(p.pct / 100f)
                            Text(T("${p.called} of ${p.total} called · ${p.remaining} left", "${p.called} من ${p.total} · ${p.remaining} متبقي"),
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.fillMaxWidth()) {
                                FilterTile(T("Answered", "ردّوا"), p.answered, Sem.success, f == 1, Modifier.weight(1f)) { f = 1 }
                                FilterTile(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, f == 2, Modifier.weight(1f)) { f = 2 }
                                FilterTile(T("Failed", "فشل"), p.failed, Sem.danger, f == 3, Modifier.weight(1f)) { f = 3 }
                            }
                        }
                    }
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                            Text(T("Stage statistics", "إحصائيات المراحل"), style = MaterialTheme.typography.titleMedium)
                            Stage.selectable.forEach { s ->
                                val n = campaign.contacts.count { it.stage == s }
                                val share = if (staged == 0) 0f else n / staged.toFloat()
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.s))
                                        .background(if (f == 10 + s.code) s.color().copy(alpha = 0.10f) else Color.Transparent)
                                        .clickable { f = 10 + s.code }.padding(Sp.xs),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconTile(stageIcon(s), s.color(), size = 38.dp)
                                    Spacer(Modifier.width(Sp.m))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(s.label(), style = MaterialTheme.typography.titleSmall)
                                            Text("$n  ·  ${(share * 100).toInt()}%", color = s.color(), style = MaterialTheme.typography.labelLarge)
                                        }
                                        BProgress(share, color = s.color(), track = s.color().copy(alpha = 0.12f), height = 6.dp)
                                    }
                                }
                            }
                            val unstaged = p.answered - campaign.contacts.count { it.status.isAnswered && it.stage != Stage.NONE }
                            if (unstaged > 0) Text(T("$unstaged answered calls have no stage yet", "$unstaged مكالمة تم الرد عليها بدون نتيجة"),
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(filterName + "  (${rows.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        if (f != 0) TextButton(onClick = { f = 0 }) { Text(T("Show all", "عرض الكل")) }
                    }
                }
                if (rows.isEmpty()) item {
                    Text(T("Nothing here yet.", "لا يوجد شيء هنا بعد."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(rows, key = { it.id }) { c -> ResultRow(c, campaign.id) }
            }
        }
    }
}

// ============================================================ call log
@Composable
fun LogScreen(entries: List<CallLogEntry>, actions: LogActions, onMenu: () -> Unit) {
    val app = LocalAppActions.current
    var filter by remember { mutableStateOf<CallStatus?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val shown = entries.filter { filter == null || it.status == filter }
    Scaffold(
        topBar = {
            AppBar(T("Call log", "سجل المكالمات"), onMenu, actions = {
                IconButton(onClick = { if (entries.isNotEmpty()) app.share(actions.report()) }) { Icon(Icons.Rounded.Share, null) }
                IconButton(onClick = { if (entries.isNotEmpty()) confirm = true }) { Icon(Icons.Rounded.Delete, null) }
            })
        },
        containerColor = Color.Transparent
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = Sp.xl),
                horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                val options: List<CallStatus?> = listOf(null, CallStatus.ANSWERED, CallStatus.NO_ANSWER, CallStatus.FAILED, CallStatus.COMPLETED)
                options.forEach { opt ->
                    FilterChip(selected = filter == opt, onClick = { filter = opt },
                        label = { Text(opt?.label() ?: T("All", "الكل")) })
                }
            }
            if (shown.isEmpty()) {
                EmptyState(Icons.Rounded.History, T("No calls logged", "لا يوجد سجل"),
                    T("Every call will be listed here.", "كل مكالمة هتظهر هنا."))
            } else {
                LazyColumn(contentPadding = PaddingValues(Sp.xl, Sp.m, Sp.xl, 100.dp), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                    items(shown) { l ->
                        Panel(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(l.contactName.ifBlank { l.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis)
                                    if (l.contactName.isNotBlank()) NumText(l.number, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(fmtTime(l.time) + " · " + l.campaignName + (if (l.durationSec > 0) " · ${fmtDur(l.durationSec)}" else "") +
                                        " · #${l.attempt}", style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                StatusPill(l.status)
                            }
                        }
                    }
                }
            }
        }
    }
    if (confirm) ConfirmDialog(T("Clear the whole call log?", "مسح كل السجل؟"), { confirm = false }) {
        confirm = false
        actions.clear()
        app.notify(Tk.INFO, T("Call log cleared", "تم مسح السجل"))
    }
}
