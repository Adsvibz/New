package com.o2dialer.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.o2dialer.app.R
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Stage

// ------------------------------------------------------------------ design tokens
/** Spacing scale (4-pt grid). */
object Sp {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 20.dp
    val xxl = 24.dp
    val xxxl = 32.dp
}

/** Corner radii. */
object Rd {
    val s = 12.dp
    val m = 16.dp
    val l = 20.dp
    val xl = 28.dp
}

/** Semantic colours: always use these for meaning, never ad-hoc colours. */
object Sem {
    val success = Color(0xFF16A34A)
    val warning = Color(0xFFF59E0B)
    val danger = Color(0xFFDC2626)
    val info = Color(0xFF2563EB)
}

val Brand: Brush = Brush.linearGradient(listOf(Color(0xFF6D4AFF), Color(0xFF4F46E5), Color(0xFF0EA5E9)))

private val Outfit = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

private val LightC = lightColorScheme(
    primary = Color(0xFF6246EA), onPrimary = Color.White,
    primaryContainer = Color(0xFFECE8FF), onPrimaryContainer = Color(0xFF1B0B5C),
    secondary = Color(0xFF0EA5E9), background = Color(0xFFF7F7FA), surface = Color.White,
    surfaceVariant = Color(0xFFF0F0F6), onSurface = Color(0xFF14131A), onBackground = Color(0xFF14131A),
    onSurfaceVariant = Color(0xFF6A6A7A), outline = Color(0xFFE3E3EC),
    inverseSurface = Color(0xFF1F1E26), inverseOnSurface = Color(0xFFF4F4F8)
)
private val DarkC = darkColorScheme(
    primary = Color(0xFFB3A1FF), onPrimary = Color(0xFF1B0B5C),
    primaryContainer = Color(0xFF3A2A8F), onPrimaryContainer = Color(0xFFECE8FF),
    secondary = Color(0xFF7DD3FC), background = Color(0xFF0B0B10), surface = Color(0xFF15151C),
    surfaceVariant = Color(0xFF1E1E27), onSurface = Color(0xFFF2F2F7), onBackground = Color(0xFFF2F2F7),
    onSurfaceVariant = Color(0xFF9A9AAC), outline = Color(0xFF2B2B37),
    inverseSurface = Color(0xFFEDEDF3), inverseOnSurface = Color(0xFF1B1B22)
)

fun statusColor(s: CallStatus): Color = when (s) {
    CallStatus.ANSWERED -> Sem.success
    CallStatus.NO_ANSWER -> Sem.warning
    CallStatus.FAILED -> Sem.danger
    CallStatus.CALLING -> Sem.info
    CallStatus.COMPLETED -> Color(0xFF0D9488)
    CallStatus.PENDING -> Color(0xFF8A90A5)
}

fun Stage.color(): Color = when (this) {
    Stage.POTENTIAL -> Color(0xFF3B82F6)
    Stage.NOT_INTERESTED -> Color(0xFFEF4444)
    Stage.CALL_BACK -> Color(0xFFF59E0B)
    Stage.WHATSAPP -> Color(0xFF22C55E)
    Stage.VOICEMAIL -> Color(0xFF8B5CF6)
    Stage.NONE -> Color(0xFF94A3B8)
}

private fun typography(ff: FontFamily): Typography {
    fun st(w: FontWeight, size: Int, lh: Int) =
        TextStyle(fontFamily = ff, fontWeight = w, fontSize = size.sp, lineHeight = lh.sp)
    val b = FontWeight.Bold
    val n = FontWeight.Normal
    return Typography(
        displayLarge = st(b, 40, 48), displayMedium = st(b, 34, 42), displaySmall = st(b, 30, 38),
        headlineLarge = st(b, 28, 36), headlineMedium = st(b, 24, 32), headlineSmall = st(b, 22, 28),
        titleLarge = st(b, 20, 26), titleMedium = st(b, 16, 22), titleSmall = st(b, 14, 20),
        bodyLarge = st(n, 16, 24), bodyMedium = st(n, 14, 20), bodySmall = st(n, 12, 16),
        labelLarge = st(b, 14, 20), labelMedium = st(n, 12, 16), labelSmall = st(n, 11, 14)
    )
}

@Composable
fun AppTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkC else LightC
    // Outfit for Latin text; the system Arabic font for Arabic mode.
    val ty = remember(settings.lang) { typography(if (settings.lang == 1) FontFamily.Default else Outfit) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val ic = WindowCompat.getInsetsController(w, view)
                ic.isAppearanceLightStatusBars = !dark
                ic.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = scheme, typography = ty,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(14.dp), small = RoundedCornerShape(Rd.s), medium = RoundedCornerShape(Rd.m),
            large = RoundedCornerShape(Rd.l), extraLarge = RoundedCornerShape(Rd.xl)
        )
    ) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
