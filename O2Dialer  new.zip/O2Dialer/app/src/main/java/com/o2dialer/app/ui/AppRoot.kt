@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.domain.engine.EnginePhase
import com.o2dialer.app.ui.components.LogoMark
import com.o2dialer.app.ui.components.PulseDot
import com.o2dialer.app.ui.components.Responsive
import com.o2dialer.app.ui.components.StageSheet
import com.o2dialer.app.ui.components.ToastHost
import com.o2dialer.app.ui.screens.CampaignDetailScreen
import com.o2dialer.app.ui.screens.CampaignsScreen
import com.o2dialer.app.ui.screens.LiveScreen
import com.o2dialer.app.ui.screens.LogScreen
import com.o2dialer.app.ui.screens.ResultsScreen
import com.o2dialer.app.ui.screens.SettingsScreen
import com.o2dialer.app.ui.theme.AppTheme
import com.o2dialer.app.ui.theme.Brand
import com.o2dialer.app.ui.theme.Sem
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.viewmodel.AppViewModel
import com.o2dialer.app.ui.viewmodel.CampaignsViewModel
import com.o2dialer.app.ui.viewmodel.LiveViewModel
import com.o2dialer.app.ui.viewmodel.LogViewModel
import com.o2dialer.app.ui.viewmodel.SettingsViewModel
import com.o2dialer.app.ui.viewmodel.VmFactory
import kotlinx.coroutines.launch

/** Bridges screen intents to the ViewModels and to the platform. Contains no state of its own. */
private class AppActionsImpl(
    private val app: AppViewModel,
    private val live: LiveViewModel,
    private val platform: PlatformActions
) : AppActions {
    override fun notify(kind: Int, msg: String) = app.notify(kind, msg)
    override fun navigate(tab: Int) = app.navigate(tab)
    override fun openSettings() = app.openSettings()
    override fun openCampaign(id: String?) = app.openCampaign(id)
    override fun openResults(campaignId: String?) = app.openResults(campaignId)
    override fun selectRun(campaignId: String) = app.selectRun(campaignId)
    override fun openStageSheet(campaignId: String, contactId: String) = app.openStageSheet(campaignId, contactId)
    override fun openWhatsApp(number: String) = platform.openUrl(app.whatsAppUrl(number))
    override fun share(text: String) = platform.share(text)
    override fun requestCallPermissions(after: (() -> Unit)?) = platform.requestCallPermissions(after)
    override fun ensureContactsPermission(after: () -> Unit) = platform.ensureContactsPermission(after)

    override fun startCampaign(campaignId: String, restart: Boolean) {
        if (live.isActive) {
            app.notify(Tk.INFO, T("A campaign is already running", "توجد حملة جارية بالفعل"))
            app.navigate(Tab.LIVE)
            return
        }
        platform.requestCallPermissions {
            app.selectRun(campaignId)
            app.navigate(Tab.LIVE)
            live.start(campaignId, restart)
        }
    }
}

@Composable
fun AppRoot(factory: VmFactory, platform: PlatformActions) {
    val appVm: AppViewModel = viewModel(factory = factory)
    val campaignsVm: CampaignsViewModel = viewModel(factory = factory)
    val liveVm: LiveViewModel = viewModel(factory = factory)
    val logVm: LogViewModel = viewModel(factory = factory)
    val settingsVm: SettingsViewModel = viewModel(factory = factory)

    val ui by appVm.ui.collectAsStateWithLifecycle()
    val campaigns by campaignsVm.ui.collectAsStateWithLifecycle()
    val engine by liveVm.state.collectAsStateWithLifecycle()
    val log by logVm.entries.collectAsStateWithLifecycle()

    val actions = remember(appVm, liveVm, platform) { AppActionsImpl(appVm, liveVm, platform) }
    val direction = if (ui.settings.lang == 1) LayoutDirection.Rtl else LayoutDirection.Ltr
    val nav = ui.nav

    val keepAwake = ui.settings.keepScreenOn && (engine.phase == EnginePhase.RUNNING || engine.phase == EnginePhase.WAITING)
    LaunchedEffect(keepAwake) { platform.setKeepScreenOn(keepAwake) }
    LaunchedEffect(ui.permissionTick) { campaignsVm.refreshSimLabels() }

    CompositionLocalProvider(
        LocalLayoutDirection provides direction,
        LocalAppActions provides actions,
        LocalLiveBadge provides (if (nav.tab != Tab.LIVE) ui.live else null),
        LocalPermissionTick provides ui.permissionTick
    ) {
        AppTheme(ui.settings) {
            val drawer = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()
            val openMenu: () -> Unit = { scope.launch { drawer.open() } }
            val cs = MaterialTheme.colorScheme

            BackHandler(enabled = drawer.isOpen || ui.canGoBack) {
                if (drawer.isOpen) scope.launch { drawer.close() } else appVm.back()
            }

            ModalNavigationDrawer(
                drawerState = drawer,
                drawerContent = {
                    ModalDrawerSheet(drawerContainerColor = cs.surface) {
                        Box(Modifier.fillMaxWidth().background(Brand).padding(horizontal = Sp.xxl, vertical = Sp.xxxl)) {
                            Column(verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                                LogoMark(56.dp)
                                Text("O2Dialer", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                                Text(T("Smart calling, beautifully simple", "اتصال ذكي بكل بساطة"),
                                    color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Spacer(Modifier.height(Sp.m))
                        val items = listOf(
                            Triple(Tab.CAMPAIGNS, T("Campaigns", "الحملات"), Icons.Rounded.Campaign),
                            Triple(Tab.LIVE, T("Live", "التشغيل"), Icons.Rounded.Call),
                            Triple(Tab.RESULTS, T("Results", "النتائج"), Icons.Rounded.BarChart),
                            Triple(Tab.LOG, T("Call log", "سجل المكالمات"), Icons.Rounded.History)
                        )
                        val colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = cs.primary.copy(alpha = 0.12f), unselectedContainerColor = Color.Transparent,
                            selectedIconColor = cs.primary, selectedTextColor = cs.primary
                        )
                        items.forEach { (id, label, icon) ->
                            NavigationDrawerItem(
                                label = { Text(label, style = MaterialTheme.typography.titleSmall) }, icon = { Icon(icon, null) },
                                badge = { if (id == Tab.LIVE && engine.isActive) PulseDot(Sem.success) },
                                selected = nav.tab == id, colors = colors,
                                onClick = { appVm.navigate(id); scope.launch { drawer.close() } },
                                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        NavigationDrawerItem(
                            label = { Text(T("Settings", "الإعدادات"), style = MaterialTheme.typography.titleSmall) },
                            icon = { Icon(Icons.Rounded.Settings, null) }, selected = nav.tab == Tab.SETTINGS, colors = colors,
                            onClick = { appVm.openSettings(); scope.launch { drawer.close() } },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                        Text("v4.0", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = Sp.xxl, vertical = Sp.l))
                    }
                }
            ) {
                Box(Modifier.fillMaxSize()) {
                    val screenKey = if (nav.tab == Tab.CAMPAIGNS && nav.selectedCampaignId != null) 10 else nav.tab
                    Responsive {
                        AnimatedContent(
                            targetState = screenKey,
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                            label = "screen"
                        ) { key ->
                            when (key) {
                                Tab.CAMPAIGNS -> CampaignsScreen(campaigns, campaignsVm, openMenu)
                                10 -> nav.selectedCampaignId?.let { CampaignDetailScreen(it, campaigns, campaignsVm) }
                                Tab.LIVE -> LiveScreen(engine, campaigns, ui.settings, nav.runCampaignId, liveVm, openMenu)
                                Tab.RESULTS -> ResultsScreen(campaigns, nav.resultsCampaignId, campaignsVm, openMenu)
                                Tab.LOG -> LogScreen(log, logVm, openMenu)
                                else -> SettingsScreen(ui.settings, settingsVm, onBack = { appVm.back() })
                            }
                        }
                    }
                    ToastHost(
                        ui.toast, appVm::dismissToast,
                        Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp, start = Sp.l, end = Sp.l)
                    )
                    ui.stageTarget?.let { ref ->
                        val contact = campaigns.find(ref.campaignId)?.campaign?.contacts?.find { it.id == ref.contactId }
                        if (contact == null) {
                            LaunchedEffect(ref) { appVm.closeStageSheet() }
                        } else {
                            StageSheet(
                                contact = contact,
                                onChoose = { stage, fb ->
                                    campaignsVm.setStage(ref.campaignId, ref.contactId, stage, fb)
                                    liveVm.stageDone()
                                    if (!stage.needsFeedback) {
                                        appVm.closeStageSheet()
                                        appVm.notify(Tk.SUCCESS, T("Saved", "تم الحفظ"))
                                    }
                                },
                                onSaveFeedback = { stage, fb ->
                                    campaignsVm.setStage(ref.campaignId, ref.contactId, stage, fb)
                                    appVm.closeStageSheet()
                                    appVm.notify(Tk.SUCCESS, T("Saved", "تم الحفظ"))
                                },
                                onClose = { liveVm.stageDone(); appVm.closeStageSheet() }
                            )
                        }
                    }
                }
            }
        }
    }
}
