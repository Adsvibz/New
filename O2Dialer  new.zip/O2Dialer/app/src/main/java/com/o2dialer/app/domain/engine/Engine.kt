package com.o2dialer.app.domain.engine

import kotlinx.coroutines.flow.StateFlow

enum class EnginePhase { IDLE, RUNNING, PAUSED, WAITING, FINISHED }

enum class Outcome { NONE, COMPLETED, STOPPED, ERROR }

/** Language-neutral status codes. The presentation layer maps them to text. */
enum class EngineMessage {
    NONE, STARTING_IN, CALLING, NEXT_CALL_IN, PAUSED, RESUMING, WAITING_HOURS, CHOOSE_RESULT, RETRY_LATER,
    STOPPED, COMPLETED, EMPTY_CAMPAIGN, NOTHING_LEFT, PERM_PHONE_STATE, PERM_CALL, SERVICE_STOPPED
}

/** The engine asks the UI to collect a call result for this contact. [token] makes every request unique. */
data class StageRequest(val campaignId: String, val contactId: String, val token: Long)

data class EngineState(
    val phase: EnginePhase = EnginePhase.IDLE,
    val campaignId: String = "",
    val campaignName: String = "",
    val currentName: String = "",
    val currentNumber: String = "",
    val message: EngineMessage = EngineMessage.NONE,
    val messageArg: Int = 0,
    val loop: Int = 1,
    val loops: Int = 1,
    val nextAtMillis: Long = 0L,
    val awaitingStage: Boolean = false,
    val outcome: Outcome = Outcome.NONE,
    val stageRequest: StageRequest? = null
) {
    val isActive: Boolean
        get() = phase == EnginePhase.RUNNING || phase == EnginePhase.PAUSED || phase == EnginePhase.WAITING
}

/** What the UI and the service are allowed to know about the calling engine. */
interface CallEngine {
    val state: StateFlow<EngineState>
    fun start(campaignId: String, restart: Boolean)
    fun pause()
    fun resume()
    fun stop()
    fun endCurrentCall()
    fun stageDone()
}

/** Starts the engine inside a process-keeping foreground host (implemented by the service layer). */
interface EngineLauncher {
    fun start(campaignId: String, restart: Boolean)
}

enum class CallPhase { IDLE, RINGING, OFFHOOK }

/** Everything the engine needs from the phone. Implemented with Android APIs in the engine package. */
interface TelephonyGateway {
    /** Starts reporting call-phase changes on the main thread. Throws SecurityException without permission. */
    fun startObserving(onPhase: (CallPhase) -> Unit)
    fun stopObserving()
    /** Places an outgoing call. [simSlot] < 0 = system default. Throws SecurityException without permission. */
    fun placeCall(number: String, simSlot: Int)
    fun endCall()
    fun canReadCallLog(): Boolean
    /** Duration (seconds) of the first outgoing call logged at/after [sinceMillis], or null if not logged yet. */
    fun outgoingCallDurationSince(sinceMillis: Long): Int?
    fun setCallAudio(speakerOnMicMuted: Boolean)
    fun simLabels(): List<String>
}
