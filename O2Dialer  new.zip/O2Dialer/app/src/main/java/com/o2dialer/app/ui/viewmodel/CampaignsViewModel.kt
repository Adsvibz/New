package com.o2dialer.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.o2dialer.app.core.FeedbackBus
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.domain.engine.CallEngine
import com.o2dialer.app.domain.engine.EngineState
import com.o2dialer.app.domain.engine.TelephonyGateway
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.CampaignProgress
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.domain.model.progress
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.CampaignRepository
import com.o2dialer.app.domain.repo.ContactsSource
import com.o2dialer.app.domain.repo.FileTextReader
import com.o2dialer.app.domain.repo.SettingsRepository
import com.o2dialer.app.domain.usecase.ReportBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class CampaignItem(val campaign: Campaign, val progress: CampaignProgress, val running: Boolean)

data class CampaignsUiState(
    val items: List<CampaignItem> = emptyList(),
    val importing: Boolean = false,
    val simLabels: List<String> = listOf("SIM 1", "SIM 2")
) {
    fun find(id: String?): CampaignItem? = if (id == null) null else items.find { it.campaign.id == id }
}

class CampaignsViewModel(
    private val campaigns: CampaignRepository,
    private val engine: CallEngine,
    private val settings: SettingsRepository,
    private val contactsSource: ContactsSource,
    private val fileReader: FileTextReader,
    private val gateway: TelephonyGateway,
    private val feedback: FeedbackBus
) : ViewModel(), CampaignsActions {

    private val importing = MutableStateFlow(false)
    private val simLabels = MutableStateFlow(gateway.simLabels())

    private fun build(list: List<Campaign>, e: EngineState, imp: Boolean, sims: List<String>) = CampaignsUiState(
        items = list.map { CampaignItem(it, it.progress(), e.isActive && e.campaignId == it.id) },
        importing = imp, simLabels = sims
    )

    val ui: StateFlow<CampaignsUiState> =
        combine(campaigns.campaigns, engine.state, importing, simLabels) { list, e, imp, sims -> build(list, e, imp, sims) }
            .stateIn(
                viewModelScope, SharingStarted.WhileSubscribed(5_000),
                build(campaigns.campaigns.value, engine.state.value, false, simLabels.value)
            )

    private fun reportAdded(n: Int) {
        if (n > 0) feedback.notify(Tk.SUCCESS, T("$n numbers added", "تمت إضافة $n رقم"))
        else feedback.notify(Tk.INFO, T("No new numbers (duplicates or invalid)", "لا أرقام جديدة (مكررة أو غير صالحة)"))
    }

    override fun create(name: String, simSlot: Int): String {
        val id = campaigns.create(name, simSlot)
        feedback.notify(Tk.SUCCESS, T("Campaign created", "تم إنشاء الحملة"))
        return id
    }

    override fun update(campaignId: String, name: String, simSlot: Int) {
        campaigns.update(campaignId) { it.copy(name = name, simSlot = simSlot) }
        feedback.notify(Tk.SUCCESS, T("Campaign updated", "تم تحديث الحملة"))
    }

    override fun delete(campaignId: String) {
        campaigns.delete(campaignId)
        feedback.notify(Tk.INFO, T("Campaign deleted", "تم حذف الحملة"))
    }

    override fun resetProgress(campaignId: String) {
        campaigns.resetProgress(campaignId, keepAnswered = false)
        feedback.notify(Tk.SUCCESS, T("Progress reset", "تمت إعادة الضبط"))
    }

    override fun removeDuplicates(campaignId: String) {
        val removed = campaigns.removeDuplicates(campaignId)
        feedback.notify(Tk.SUCCESS, T("Removed $removed duplicates", "تم حذف $removed مكرر"))
    }

    override fun addContacts(campaignId: String, items: List<ImportedContact>) =
        reportAdded(campaigns.addContacts(campaignId, items, settings.effectiveCountryCode()))

    override fun addFromText(campaignId: String, text: String) =
        addContacts(campaignId, PhoneNumbers.parseLines(text))

    override fun importFile(campaignId: String, uri: String) {
        viewModelScope.launch {
            importing.value = true
            val parsed = withContext(Dispatchers.IO) { PhoneNumbers.parseLines(fileReader.readText(uri)) }
            importing.value = false
            if (parsed.isEmpty()) feedback.notify(Tk.ERROR, T("No valid numbers found in the file", "لم يتم العثور على أرقام صالحة في الملف"))
            else addContacts(campaignId, parsed)
        }
    }

    override suspend fun loadPhoneContacts(): List<ImportedContact> =
        withContext(Dispatchers.IO) { contactsSource.loadPhoneContacts() }

    override fun editContact(campaignId: String, contactId: String, name: String, number: String) {
        val cc = settings.effectiveCountryCode()
        campaigns.updateContact(campaignId, contactId) {
            it.copy(name = name.trim(), number = PhoneNumbers.smartNumber(number, cc))
        }
        feedback.notify(Tk.SUCCESS, T("Contact updated", "تم تحديث الجهة"))
    }

    override fun removeContact(campaignId: String, contactId: String) = campaigns.removeContact(campaignId, contactId)

    override fun setStage(campaignId: String, contactId: String, stage: Stage, feedback: String) =
        campaigns.setStage(campaignId, contactId, stage, feedback)

    override fun campaignReport(campaignId: String): String =
        campaigns.get(campaignId)?.let { ReportBuilder.campaignCsv(it) } ?: ""

    override fun refreshSimLabels() { simLabels.value = gateway.simLabels() }
}
