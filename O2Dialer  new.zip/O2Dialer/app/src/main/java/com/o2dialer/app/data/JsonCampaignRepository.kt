package com.o2dialer.app.data

import android.content.Context
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Campaign
import com.o2dialer.app.domain.model.Contact
import com.o2dialer.app.domain.model.ImportedContact
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.domain.phone.PhoneNumbers
import com.o2dialer.app.domain.repo.CampaignRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Campaigns live in memory as an immutable list (StateFlow) and are persisted as JSON.
 * Serialisation + disk write happen on a background dispatcher and are debounced,
 * so frequent updates during a running campaign never block the main thread.
 */
class JsonCampaignRepository(context: Context, private val scope: CoroutineScope) : CampaignRepository {
    private val prefs = context.applicationContext.getSharedPreferences("o2dialer_campaigns", Context.MODE_PRIVATE)
    private val _campaigns = MutableStateFlow(load())
    override val campaigns: StateFlow<List<Campaign>> = _campaigns.asStateFlow()
    private var saveJob: Job? = null

    override fun get(id: String): Campaign? = _campaigns.value.find { it.id == id }

    override fun create(name: String, simSlot: Int): String {
        val c = Campaign(name = name, simSlot = simSlot)
        mutate { it + c }
        return c.id
    }

    override fun update(id: String, transform: (Campaign) -> Campaign) =
        mutate { list -> list.map { if (it.id == id) transform(it) else it } }

    override fun delete(id: String) = mutate { list -> list.filter { it.id != id } }

    override fun updateContact(campaignId: String, contactId: String, transform: (Contact) -> Contact) =
        update(campaignId) { c -> c.copy(contacts = c.contacts.map { if (it.id == contactId) transform(it) else it }) }

    override fun removeContact(campaignId: String, contactId: String) =
        update(campaignId) { c -> c.copy(contacts = c.contacts.filter { it.id != contactId }) }

    override fun addContacts(campaignId: String, items: List<ImportedContact>, defaultCc: String): Int {
        var added = 0
        update(campaignId) { c ->
            val seen = c.contacts.map { it.number }.toMutableSet()
            val fresh = items.mapNotNull { imp ->
                val n = PhoneNumbers.smartNumber(imp.number, defaultCc)
                if (n.count { it.isDigit() } < 3 || !seen.add(n)) null else Contact(name = imp.name.trim(), number = n)
            }
            added = fresh.size
            c.copy(contacts = c.contacts + fresh)
        }
        return added
    }

    override fun removeDuplicates(campaignId: String): Int {
        var removed = 0
        update(campaignId) { c ->
            val seen = HashSet<String>()
            val out = c.contacts.filter { seen.add(it.number) }
            removed = c.contacts.size - out.size
            c.copy(contacts = out)
        }
        return removed
    }

    override fun resetProgress(campaignId: String, keepAnswered: Boolean) =
        update(campaignId) { c ->
            c.copy(contacts = c.contacts.map {
                if (keepAnswered && it.status.isAnswered) it
                else it.copy(status = CallStatus.PENDING, attempts = 0, durationSec = 0, calledAt = 0L)
            })
        }

    override fun setStage(campaignId: String, contactId: String, stage: Stage, feedback: String) =
        updateContact(campaignId, contactId) { it.copy(stage = stage, feedback = feedback) }

    // ------------------------------------------------------------ persistence
    private fun mutate(transform: (List<Campaign>) -> List<Campaign>) {
        _campaigns.update(transform)
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(150)
            val snapshot = _campaigns.value
            withContext(Dispatchers.IO) { prefs.edit().putString("campaigns", encode(snapshot)).apply() }
        }
    }

    private fun load(): List<Campaign> {
        val raw = prefs.getString("campaigns", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ca = o.getJSONArray("contacts")
                Campaign(
                    id = o.getString("id"), name = o.getString("name"), simSlot = o.optInt("sim", -1),
                    contacts = (0 until ca.length()).map { k ->
                        val e = ca.getJSONObject(k)
                        val st = CallStatus.fromCode(e.optInt("status"))
                        Contact(
                            id = e.getString("id"), name = e.optString("name"), number = e.getString("number"),
                            // a call that was in flight when the process died is retried
                            status = if (st == CallStatus.CALLING) CallStatus.PENDING else st,
                            attempts = e.optInt("attempts"), durationSec = e.optInt("duration"),
                            calledAt = e.optLong("calledAt"), stage = Stage.fromCode(e.optInt("stage")),
                            feedback = e.optString("feedback")
                        )
                    }
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun encode(list: List<Campaign>): String {
        val a = JSONArray()
        list.forEach { c ->
            val ca = JSONArray()
            c.contacts.forEach { e ->
                ca.put(JSONObject().put("id", e.id).put("name", e.name).put("number", e.number)
                    .put("status", e.status.code).put("attempts", e.attempts).put("duration", e.durationSec)
                    .put("calledAt", e.calledAt).put("stage", e.stage.code).put("feedback", e.feedback))
            }
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("sim", c.simSlot).put("contacts", ca))
        }
        return a.toString()
    }
}
