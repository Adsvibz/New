package com.o2dialer.app

import android.app.Application
import com.o2dialer.app.core.Lang

class O2App : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // language must be known before the first frame is composed
        Lang.code = container.settingsRepo.settings.value.lang
    }
}
