package com.o2dialer.app.core

import com.o2dialer.app.domain.engine.EngineMessage
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Stage

/** Presentation-neutral text mapping, shared by the UI and the notification layer. */
fun CallStatus.label(): String = when (this) {
    CallStatus.PENDING -> T("Pending", "في الانتظار")
    CallStatus.CALLING -> T("Calling", "جارٍ الاتصال")
    CallStatus.ANSWERED -> T("Answered", "تم الرد")
    CallStatus.NO_ANSWER -> T("No answer", "لم يُرد")
    CallStatus.FAILED -> T("Failed", "فشل")
    CallStatus.COMPLETED -> T("Completed", "انتهت")
}

fun Stage.label(): String = when (this) {
    Stage.NONE -> "—"
    Stage.POTENTIAL -> T("Potential", "مهتم")
    Stage.NOT_INTERESTED -> T("Not Interested", "غير مهتم")
    Stage.CALL_BACK -> T("Call Back", "معاودة الاتصال")
    Stage.WHATSAPP -> T("WhatsApp", "واتساب")
    Stage.VOICEMAIL -> T("Voicemail", "بريد صوتي")
}

fun EngineMessage.text(arg: Int = 0): String = when (this) {
    EngineMessage.NONE -> ""
    EngineMessage.STARTING_IN -> T("Starting in", "تبدأ بعد")
    EngineMessage.CALLING -> T("Calling…", "جارٍ الاتصال…")
    EngineMessage.NEXT_CALL_IN -> T("Next call in", "الاتصال التالي بعد")
    EngineMessage.PAUSED -> T("Paused", "متوقفة مؤقتًا")
    EngineMessage.RESUMING -> T("Resuming…", "استئناف…")
    EngineMessage.WAITING_HOURS -> T("Outside allowed hours — waiting until $arg:00", "خارج ساعات السماح — الانتظار حتى $arg:00")
    EngineMessage.CHOOSE_RESULT -> T("Choose the call result", "اختر نتيجة المكالمة")
    EngineMessage.RETRY_LATER -> T("Will retry this number later", "سيُعاد الاتصال بهذا الرقم لاحقًا")
    EngineMessage.STOPPED -> T("Campaign stopped", "تم إيقاف الحملة")
    EngineMessage.COMPLETED -> T("Campaign completed ✓", "اكتملت الحملة ✓")
    EngineMessage.EMPTY_CAMPAIGN -> T("The campaign is empty", "الحملة فارغة")
    EngineMessage.NOTHING_LEFT -> T("Nothing left to call", "لا توجد أرقام متبقية للاتصال")
    EngineMessage.PERM_PHONE_STATE -> T("Phone-state permission is missing", "صلاحية حالة الهاتف غير ممنوحة")
    EngineMessage.PERM_CALL -> T("Call permission is missing", "صلاحية الاتصال غير ممنوحة")
    EngineMessage.SERVICE_STOPPED -> T("Service stopped", "توقفت الخدمة")
}
