package com.o2dialer.app.ui

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf

object Tab {
    const val CAMPAIGNS = 0
    const val LIVE = 1
    const val RESULTS = 2
    const val LOG = 3
    const val SETTINGS = 4
}

data class LiveBadge(val campaignId: String, val pct: Int)

/**
 * Everything a screen may ask the app shell to do. Screens depend on this interface only,
 * never on the Activity, the navigation state holder or the engine.
 */
interface AppActions {
    fun notify(kind: Int, msg: String)
    fun navigate(tab: Int)
    fun openSettings()
    fun openCampaign(id: String?)
    fun openResults(campaignId: String?)
    fun selectRun(campaignId: String)
    fun openStageSheet(campaignId: String, contactId: String)
    fun openWhatsApp(number: String)
    fun share(text: String)
    fun requestCallPermissions(after: (() -> Unit)? = null)
    fun ensureContactsPermission(after: () -> Unit)
    fun startCampaign(campaignId: String, restart: Boolean)
}

val LocalAppActions = staticCompositionLocalOf<AppActions> { error("AppActions not provided") }
val LocalLiveBadge = compositionLocalOf<LiveBadge?> { null }
val LocalPermissionTick = compositionLocalOf { 0 }
