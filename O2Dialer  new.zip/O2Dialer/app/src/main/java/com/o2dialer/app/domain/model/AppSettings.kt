package com.o2dialer.app.domain.model

data class AppSettings(
    val lang: Int = 0,                       // 0 = English, 1 = Arabic
    val delaySec: Int = 5,
    val randomDelay: Boolean = false,
    val delayMaxSec: Int = 15,
    val startCountdown: Int = 3,
    val maxCallSec: Int = 0,                 // 0 = off
    val retries: Int = 0,
    val loops: Int = 1,
    val shuffle: Boolean = false,
    val skipAnswered: Boolean = true,
    val useCallLog: Boolean = true,
    val countryCode: String = "",
    val autoSpeaker: Boolean = true,
    val askStage: Boolean = true,
    val stageWaitSec: Int = 15,              // 0 = don't wait
    val quietEnabled: Boolean = false,
    val quietFrom: Int = 9,
    val quietTo: Int = 21,
    val keepScreenOn: Boolean = true,
    val vibrateOnFinish: Boolean = true,
    val themeMode: Int = 0,                  // 0 auto, 1 light, 2 dark
    val dynamicColor: Boolean = false
)
