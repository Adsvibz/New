@file:OptIn(ExperimentalMaterial3Api::class)

package com.blendora.app

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            Store.permTick = Store.permTick + 1
            if (has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
            else Store.notify(Tk.ERROR, T("Calling and phone-state permissions are required", "صلاحيات الاتصال وحالة الهاتف مطلوبة"))
            afterPerms = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) afterContacts?.invoke()
            else Store.notify(Tk.ERROR, T("Contacts permission was denied", "تم رفض صلاحية جهات الاتصال"))
            afterContacts = null
        }

    fun ensureContacts(after: () -> Unit) {
        if (has(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    /** Asks for everything a campaign needs, then runs [after] once calling is allowed. */
    fun requestCallPermissions(after: (() -> Unit)? = null) {
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !has(it) }
        if (missing.isEmpty()) { after?.invoke(); return }
        afterPerms = after
        permLauncher.launch(missing.toTypedArray())
    }

    /** restart = false -> continue from the first number not called yet. */
    fun startCampaign(listId: String, restart: Boolean = false) {
        if (Store.campActive()) {
            Store.notify(Tk.INFO, T("A campaign is already running", "توجد حملة جارية بالفعل"))
            Store.tab = 1
            return
        }
        requestCallPermissions {
            Store.runListId = listId
            Store.tab = 1
            DialerService.send(this, DialerService.ACT_START, listId, restart)
        }
    }

    override fun onResume() {
        super.onResume()
        Store.permTick = Store.permTick + 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val dir = if (Store.cfg.lang == 1) LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                AppTheme { Root(this@MainActivity) }
            }
        }
    }
}

/** Pill with a smooth swell in the top edge, centred, where the raised dial sits. */
private class BumpPillShape(private val bump: Dp, private val halfWidth: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val b = with(density) { bump.toPx() }
        val hw = with(density) { halfWidth.toPx() }
        val w = size.width
        val h = size.height
        val r = (h - b) / 2f
        val cx = w / 2f
        val path = Path().apply {
            moveTo(r, b)
            lineTo(cx - hw, b)
            cubicTo(cx - hw * 0.55f, b, cx - hw * 0.45f, 0f, cx, 0f)
            cubicTo(cx + hw * 0.45f, 0f, cx + hw * 0.55f, b, cx + hw, b)
            lineTo(w - r, b)
            arcTo(Rect(w - 2f * r, b, w, h), -90f, 180f, false)
            lineTo(r, h)
            arcTo(Rect(0f, b, 2f * r, h), 90f, 180f, false)
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
private fun NavItem(label: String, filled: ImageVector, outline: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(Rd.l)).clickable(role = Role.Tab, onClick = onClick).heightIn(min = 56.dp)
            .semantics { contentDescription = label; this.selected = selected },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(if (selected) filled else outline, null, tint = if (selected) cs.onSurface else cs.onSurfaceVariant,
            modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Box(Modifier.size(5.dp).clip(CircleShape).background(if (selected) cs.primary else Color.Transparent))
    }
}

/** The raised centre orb: the live dialer. Turns green and its dotted ring spins while a campaign runs. */
@Composable
private fun CenterDial(selected: Boolean, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (active) Sem.success else cs.primary
    val fg = if (active) Color.White else cs.onPrimary
    val label = T("Live dialer", "التشغيل المباشر")
    val sc by animateFloatAsState(if (selected) 1f else 0.92f, tween(160), label = "dial")
    val spin = if (active) {
        val t = rememberInfiniteTransition(label = "ring")
        val v by t.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "spin")
        v
    } else 0f
    Box(modifier.size(80.dp), Alignment.Center) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ = spin }) {
            val n = 30
            val rad = size.minDimension / 2f - 2.dp.toPx()
            val dot = bg.copy(alpha = if (selected || active) 0.75f else 0.4f)
            repeat(n) { i ->
                val a = 2.0 * PI * i / n
                drawCircle(dot, 1.6.dp.toPx(), Offset(center.x + (rad * cos(a)).toFloat(), center.y + (rad * sin(a)).toFloat()))
            }
        }
        Box(
            Modifier.size(60.dp).graphicsLayer { scaleX = sc; scaleY = sc }
                .shadow(16.dp, CircleShape, ambientColor = bg, spotColor = bg)
                .clip(CircleShape).background(Brush.linearGradient(listOf(lerp(bg, Color.White, 0.25f), bg)))
                .clickable(role = Role.Tab, onClick = onClick)
                .semantics { contentDescription = label; this.selected = selected },
            Alignment.Center
        ) {
            Icon(Icons.Rounded.Call, null, tint = fg, modifier = Modifier.size(28.dp))
        }
    }
}

/** Floating pill bar: Campaigns, Results | Live (raised orb) | Log, Settings. Icons only; the dot marks the current tab. */
@Composable
private fun AppNavBar() {
    val cs = MaterialTheme.colorScheme
    val shape = remember { BumpPillShape(24.dp, 62.dp) }
    Box(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.l).padding(bottom = Sp.s),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(Modifier.widthIn(max = 520.dp).fillMaxWidth().height(96.dp)) {
            Row(
                Modifier.fillMaxSize().shadow(12.dp, shape).clip(shape).background(cs.surface)
                    .border(1.dp, cs.outline, shape).padding(top = 24.dp, start = Sp.s, end = Sp.s),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavItem(T("Campaigns", "الحملات"), Icons.Rounded.Campaign, Icons.Outlined.Campaign, Store.tab == 0, Modifier.weight(1f)) {
                    Store.selectedListId = null; Store.tab = 0
                }
                NavItem(T("Results", "النتائج"), Icons.Rounded.BarChart, Icons.Outlined.BarChart, Store.tab == 2, Modifier.weight(1f)) { Store.tab = 2 }
                Spacer(Modifier.weight(1.3f))
                NavItem(T("Log", "السجل"), Icons.Rounded.History, Icons.Outlined.History, Store.tab == 3, Modifier.weight(1f)) { Store.tab = 3 }
                NavItem(T("Settings", "الإعدادات"), Icons.Rounded.Settings, Icons.Outlined.Settings, Store.tab == 4, Modifier.weight(1f)) { Store.openSettings() }
            }
            CenterDial(Store.tab == 1, Store.campActive(), Modifier.align(Alignment.TopCenter).padding(top = 4.dp)) { Store.tab = 1 }
        }
    }
}

@Composable
fun Root(act: MainActivity) {
    val activity = LocalContext.current as Activity

    val keep = Store.cfg.keepScreenOn && (Store.camp.status == CS.RUNNING || Store.camp.status == CS.WAITING)
    LaunchedEffect(keep) {
        if (keep) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    // When a campaign completes, jump to its results.
    LaunchedEffect(Store.pendingResultsNav) {
        if (Store.pendingResultsNav) { Store.tab = 2; Store.pendingResultsNav = false }
    }

    BackHandler(enabled = Store.tab != 0 || Store.selectedListId != null) {
        when {
            Store.tab == 4 -> Store.tab = Store.prevTab
            Store.tab == 0 && Store.selectedListId != null -> Store.selectedListId = null
            else -> Store.tab = 0
        }
    }

    val screenKey = if (Store.tab == 0 && Store.selectedListId != null) 10 else Store.tab
    // The floating bar belongs to the five main destinations; the campaign detail page is full-screen.
    val showNav = screenKey in 0..4

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = { if (showNav) AppNavBar() }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
            Responsive {
                AnimatedContent(
                    targetState = screenKey,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                    label = "screen"
                ) { k ->
                    when (k) {
                        0 -> ListsScreen()
                        10 -> Store.selectedListId?.let { ListDetail(it, act) }
                        1 -> LiveScreen(act)
                        2 -> ResultsScreen()
                        3 -> LogScreen()
                        else -> SettingsScreen()
                    }
                }
            }
            ToastHost(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp, start = Sp.l, end = Sp.l)
            )
            Store.stageTarget?.let { (lid, eid) -> StageSheet(lid, eid) }
        }
    }
}
