O2Dialer v3.19 (package com.o2dialer.app)
Push this project to your GitHub repo root (keep .github/workflows/build.yml), run Actions, download the O2Dialer-APK artifact.
To rename the visible app name again: edit APP_NAME in Theme.kt and android:label in AndroidManifest.xml.
License server (optional): see server/README.md. Add the LICENSE_URL secret in GitHub to turn licensing on; without it the app works exactly as before.
