@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val EnterEase = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)
private val Indigo = Color(0xFF5B3FE4)

/** Staggered fade-and-rise entrance (the `enter` keyframe: 450 ms, 12 dp). */
@Composable
private fun Enter(index: Int, content: @Composable () -> Unit) {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(60L * index); go = true }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(450, easing = EnterEase), label = "enter")
    Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 12.dp.toPx() }) { content() }
}

/** The `live-dot` keyframe: scales to 1.5x and fades while pulsing. */
@Composable
private fun LiveDot(color: Color, size: Dp = 8.dp) {
    val t = rememberInfiniteTransition(label = "liveDot")
    val k by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "k")
    Box(
        Modifier.size(size).graphicsLayer { val s = 1f + 0.5f * k; scaleX = s; scaleY = s; alpha = 1f - 0.55f * k }
            .clip(CircleShape).background(color)
    )
}

/** Squircle avatar: `breathe` (scale + glow) and the expanding `ripple` ring while a call is live. */
@Composable
private fun CallAvatar(initials: String?, size: Dp, live: Boolean) {
    val t = rememberInfiniteTransition(label = "avatar")
    val breathe by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "breathe")
    val ripple by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "ripple")
    val shape = RoundedCornerShape(22.dp)
    Box(Modifier.size(size + 18.dp), Alignment.Center) {
        if (live) {
            val a = when {
                ripple < 0.2f -> 0.65f * ripple / 0.2f
                ripple < 0.8f -> 0.65f * (1f - (ripple - 0.2f) / 0.6f)
                else -> 0f
            }
            Box(
                Modifier.size(size).graphicsLayer { val sc = 0.84f + 0.62f * ripple; scaleX = sc; scaleY = sc; alpha = a }
                    .border(2.dp, Indigo, shape)
            )
        }
        val sc = if (live) 1f + 0.035f * breathe else 1f
        Box(
            Modifier.size(size).graphicsLayer { scaleX = sc; scaleY = sc }
                .shadow(if (live) (8 + 10 * breathe).dp else 4.dp, shape, ambientColor = HeroBg, spotColor = HeroBg)
                .clip(shape).background(Brush.linearGradient(listOf(Indigo, HeroBg))),
            Alignment.Center
        ) {
            if (initials != null) Text(initials, color = Color.White, style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp))
            else Icon(Icons.Rounded.Call, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun EqualizerBars(color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    val h1 by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520), RepeatMode.Reverse), label = "h1")
    val h2 by t.animateFloat(1f, 0.35f, infiniteRepeatable(tween(680), RepeatMode.Reverse), label = "h2")
    val h3 by t.animateFloat(0.5f, 1f, infiniteRepeatable(tween(440), RepeatMode.Reverse), label = "h3")
    Row(Modifier.height(28.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        listOf(h1, h2, h3).forEach { h -> Box(Modifier.width(5.dp).fillMaxHeight(h).clip(CircleShape).background(color)) }
    }
}

/** Right-hand slot of the identity row: rolling countdown digits, or live bars while a call is in progress. */
@Composable
private fun CountdownBlock(secs: Long, caption: String, calling: Boolean, compact: Boolean) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.End) {
        if (secs > 0) {
            AnimatedContent(
                targetState = secs,
                transitionSpec = { (fadeIn(tween(250)) + slideInVertically(tween(250)) { -it / 3 }) togetherWith fadeOut(tween(120)) },
                label = "digits"
            ) { s ->
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$s", color = HeroBg, style = MaterialTheme.typography.displaySmall.copy(fontSize = if (compact) 32.sp else 40.sp))
                    Text("s", color = cs.onSurfaceVariant, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 6.dp))
                }
            }
            if (caption.isNotEmpty()) Text(caption, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                textAlign = TextAlign.End, maxLines = 2)
        } else if (calling) {
            EqualizerBars(Sem.success)
            Text(T("On call", "في مكالمة"), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun CurrentCallCard(c: CampState, list: CallList, p: Prog, now: Long, compact: Boolean) {
    val cs = MaterialTheme.colorScheme
    val finished = c.status == CS.FINISHED
    val calling = c.status == CS.RUNNING && c.currentNumber.isNotEmpty()
    val secs = if (c.nextAt > now) (c.nextAt - now + 999) / 1000 else 0L
    val label = when {
        finished -> if (c.error) T("Stopped", "توقفت") else T("Finished", "انتهت")
        c.status == CS.PAUSED -> T("Paused", "متوقفة مؤقتًا")
        c.status == CS.WAITING -> T("Waiting", "في الانتظار")
        calling -> T("Calling now", "جارٍ الاتصال")
        c.awaitingStage -> T("Your input", "دورك")
        else -> T("Next call", "المكالمة التالية")
    }
    // Who the card is about: the contact being called, or the next one in line.
    val next = list.entries.firstOrNull { it.status == St.PENDING }
    val who: Pair<String, String>? = when {
        calling -> c.currentName to c.currentNumber
        !finished && next != null -> next.name to next.number
        else -> null
    }
    val caption = when {
        c.awaitingStage -> T("Continuing in", "المتابعة بعد")
        else -> c.message
    }
    val note = when {
        finished -> T("${p.answered} answered \u00b7 ${p.noAnswer} no answer \u00b7 ${p.failed} failed",
            "${p.answered} ردّوا \u00b7 ${p.noAnswer} لم يردّوا \u00b7 ${p.failed} فشل")
        c.status == CS.PAUSED -> T("Tap Resume to continue", "اضغط استئناف للمتابعة")
        c.status == CS.WAITING -> c.message
        c.awaitingStage && secs == 0L -> c.message
        else -> ""
    }
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (finished) Icon(Icons.Rounded.CheckCircle, null, tint = if (c.error) Sem.danger else Sem.success, modifier = Modifier.size(14.dp))
                else LiveDot(if (calling) Sem.success else HeroBg)
                Spacer(Modifier.width(8.dp))
                Text(label, style = MaterialTheme.typography.labelLarge, color = if (calling) readable(Sem.success) else cs.onSurface)
                Spacer(Modifier.weight(1f))
                Text(c.listName, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                CallAvatar(
                    initials = who?.first?.takeIf { it.isNotBlank() }?.let { initialsOf(it) },
                    size = if (compact) 54.dp else 62.dp, live = calling
                )
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (who != null) {
                        Text(who.first.ifBlank { who.second }, style = MaterialTheme.typography.headlineSmall.copy(fontSize = if (compact) 18.sp else 20.sp),
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (who.first.isNotBlank()) NumText(who.second, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    } else {
                        Text(c.message.ifBlank { label }, style = MaterialTheme.typography.headlineSmall.copy(fontSize = 18.sp), maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.width(8.dp))
                CountdownBlock(secs, caption, calling, compact)
            }
            if (note.isNotEmpty()) Text(note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

/** Progress bar with a smooth fill and the slow `shimmer` sweep. */
@Composable
private fun ShimmerBar(fraction: Float) {
    val cs = MaterialTheme.colorScheme
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(500), label = "bar")
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-0.4f, 1.4f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "x")
    Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(cs.surfaceVariant)) {
        Box(
            Modifier.fillMaxWidth(f).fillMaxHeight().clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(Indigo, HeroBg)))
                .drawWithContent {
                    drawContent()
                    val w = size.width
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                            startX = x * w, endX = x * w + w * 0.4f
                        )
                    )
                }
        )
    }
}

/** Result counter; the number pops (the `counter-pop` keyframe) whenever it changes. */
@Composable
private fun CounterCell(label: String, value: Int, color: Color, icon: ImageVector, modifier: Modifier) {
    val fg = readable(color)
    val pop = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(value) {
        if (first) first = false
        else {
            pop.animateTo(1.12f, tween(110))
            pop.animateTo(1f, spring(dampingRatio = 0.5f))
        }
    }
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(color.copy(alpha = 0.10f)).padding(horizontal = Sp.m, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("$value", style = MaterialTheme.typography.titleLarge, color = fg,
                modifier = Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value })
        }
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp), color = fg, maxLines = 1)
    }
}

@Composable
private fun ProgressCard(c: CampState, p: Prog) {
    val cs = MaterialTheme.colorScheme
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Text(T("${p.called} of ${p.total} called", "${p.called} من ${p.total} تم الاتصال"), style = MaterialTheme.typography.titleSmall)
                Text("${p.pct}%", style = MaterialTheme.typography.headlineSmall, color = HeroBg)
            }
            ShimmerBar(p.pct / 100f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(T("${p.remaining} left", "${p.remaining} متبقي"), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                if (c.loops > 1) Text(T("Round ${c.loop} of ${c.loops}", "الجولة ${c.loop} من ${c.loops}"),
                    style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(Sp.xs))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                CounterCell(T("Answered", "ردّوا"), p.answered, Sem.success, Icons.Rounded.Check, Modifier.weight(1f))
                CounterCell(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, Icons.Rounded.PhoneMissed, Modifier.weight(1f))
                CounterCell(T("Failed", "فشل"), p.failed, Sem.danger, Icons.Rounded.ErrorOutline, Modifier.weight(1f))
            }
        }
    }
}

/** Pause/Resume, End call (hangs up the current call only) and Stop (ends the campaign). */
@Composable
private fun CallControls(paused: Boolean, compact: Boolean) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        BButton(
            if (paused) T("Resume", "استئناف") else T("Pause", "إيقاف مؤقت"),
            { DialerService.send(ctx, if (paused) DialerService.ACT_RESUME else DialerService.ACT_PAUSE) },
            Modifier.weight(1.4f), icon = if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, compact = true
        )
        BButton(T("End call", "إنهاء"), { DialerService.send(ctx, DialerService.ACT_SKIP) }, Modifier.weight(1f),
            kind = BtnKind.Outline, icon = Icons.Rounded.CallEnd, compact = true, iconOnly = compact)
        BButton(T("Stop", "إيقاف"), { DialerService.send(ctx, DialerService.ACT_STOP) }, Modifier.weight(1f),
            kind = BtnKind.Danger, icon = Icons.Rounded.Stop, compact = true, iconOnly = compact)
    }
}

@Composable
private fun FactButton(icon: ImageVector, value: String, caption: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.m)
    Row(
        modifier.heightIn(min = 52.dp).clip(shape).background(cs.surface).border(1.dp, cs.outline, shape)
            .clickable(role = Role.Button) { Store.openSettings() }.padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, null, tint = HeroBg, modifier = Modifier.size(18.dp))
        Column {
            Text(value, style = MaterialTheme.typography.titleSmall, maxLines = 1)
            Text(caption, style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp), color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Three tappable run-setup facts; each opens Settings. */
@Composable
private fun RunSetupStrip() {
    val s = Store.cfg
    val gap = if (s.randomDelay) "${s.delaySec}\u2013${s.delayMaxSec}s" else "${s.delaySec}s"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        FactButton(Icons.Rounded.Timer, gap, T("between calls", "بين المكالمات"), Modifier.weight(1f))
        FactButton(
            Icons.Rounded.Replay, "${s.retries}",
            if (s.retries == 0) T("no retries", "بدون إعادة") else T("retries", "إعادة محاولة"), Modifier.weight(1f)
        )
        FactButton(
            if (s.autoSpeaker) Icons.Rounded.MicOff else Icons.Rounded.Mic,
            if (s.autoSpeaker) T("On", "مفعّل") else T("Off", "مغلق"),
            if (s.autoSpeaker) T("mic muted", "المايك مكتوم") else T("mic live", "المايك يعمل"), Modifier.weight(1f)
        )
    }
}

@Composable
private fun LiveHeader(subtitle: String) {
    Column(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = Sp.xl, end = Sp.xl, top = Sp.l, bottom = Sp.s)
    ) {
        Text(T("Live dialer", "التشغيل المباشر"), style = MaterialTheme.typography.headlineLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LiveScreen(act: MainActivity) {
    val c = Store.camp
    val active = Store.campActive()
    val compact = isCompact()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }
    val heroList = Store.lists.find { it.id == c.listId }
    val showHero = (active || c.status == CS.FINISHED) && heroList != null

    val subtitle = when {
        c.status == CS.PAUSED -> T("Campaign paused", "الحملة متوقفة مؤقتًا")
        active -> T("Campaign in progress", "الحملة قيد التشغيل")
        c.status == CS.FINISHED && heroList != null -> T("Campaign finished", "انتهت الحملة")
        else -> T("Choose a campaign to start", "اختر حملة للبدء")
    }

    Scaffold(
        topBar = { LiveHeader(subtitle) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.xl, vertical = Sp.s),
            verticalArrangement = Arrangement.spacedBy(Sp.m)
        ) {
            LicenseBanner()
            PermissionBanner(act)
            if (showHero && heroList != null) {
                val p = Store.prog(heroList)
                Enter(0) { CurrentCallCard(c, heroList, p, now, compact) }
                if (c.status == CS.FINISHED) Enter(1) { Banner(if (c.error) Tk.ERROR else Tk.SUCCESS, c.message) }
                Enter(1) { ProgressCard(c, p) }
                if (active) Enter(2) { CallControls(c.status == CS.PAUSED, compact) }
                if (active) Enter(3) { RunSetupStrip() }
                if (active && !Store.cfg.shuffle) Enter(4) { UpNext(heroList, p.remaining) }
            }
            if (!active) {
                if (c.status == CS.FINISHED && heroList != null && !c.error) {
                    BButton(T("View campaign results", "عرض نتائج الحملة"),
                        { Store.resultsListId = c.listId; Store.tab = 2 }, Modifier.fillMaxWidth(),
                        kind = BtnKind.Tonal, icon = Icons.Rounded.BarChart)
                }
                Launcher(act)
            }
            Spacer(Modifier.height(Sp.l))
        }
    }
}

private fun initialsOf(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return parts.take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "#" }
}

@Composable
private fun UpNext(list: CallList, remaining: Int) {
    val next = list.entries.filter { it.status == St.PENDING }.take(3)
    if (next.isNotEmpty()) {
        val cs = MaterialTheme.colorScheme
        Panel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(start = Sp.l, end = Sp.l, top = Sp.l)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            T("UP NEXT", "التالي"),
                            style = MaterialTheme.typography.labelMedium.copy(letterSpacing = if (Store.cfg.lang == 0) 1.5.sp else 0.sp),
                            color = cs.onSurfaceVariant
                        )
                        Spacer(Modifier.height(Sp.xs))
                        Text(T("Coming up in the queue", "الدور القادم في الطابور"), style = MaterialTheme.typography.titleLarge)
                    }
                    Pill(T("$remaining left", "$remaining متبقي"), cs.primary)
                }
                Spacer(Modifier.height(Sp.m))
                next.forEachIndexed { i, e ->
                    Box(Modifier.fillMaxWidth().height(1.dp).background(cs.outline))
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant), Alignment.Center) {
                            Text("${i + 1}", style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(Modifier.width(Sp.m))
                        Column(Modifier.weight(1f)) {
                            Text(e.name.ifBlank { e.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            if (e.name.isNotBlank()) NumText(e.number, style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant)
                        }
                        // X: remove this number from the campaign so it is never called.
                        // Small soft circle; the clickable area stays 48 dp so it is easy to hit.
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button) {
                                Store.deleteEntry(list.id, e.id)
                                Store.notify(Tk.INFO, T("Removed from the queue", "تم الحذف من القائمة"))
                            },
                            Alignment.Center
                        ) {
                            Box(Modifier.size(26.dp).clip(CircleShape).background(cs.surfaceVariant), Alignment.Center) {
                                Icon(Icons.Rounded.Close, T("Remove from the queue", "حذف من القائمة"),
                                    tint = cs.onSurfaceVariant, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Launcher(act: MainActivity) {
    val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
    val selList = Store.lists.find { it.id == sel }
    val p = selList?.let { Store.prog(it) }

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            SectionLabel(T("Choose a campaign", "اختر الحملة"))
            if (Store.lists.isEmpty()) {
                Text(T("Create a campaign first.", "أنشئ حملة أولاً."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                BButton(T("Go to campaigns", "الذهاب إلى الحملات"), { Store.tab = 0 }, kind = BtnKind.Tonal, compact = true)
            }
            Store.lists.forEach { l ->
                val lp = Store.prog(l)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).clickable { Store.runListId = l.id }
                        .background(if (l.id == sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                        .heightIn(min = 56.dp).padding(horizontal = Sp.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = l.id == sel, onClick = { Store.runListId = l.id })
                    Column(Modifier.weight(1f)) {
                        Text(l.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(T("${lp.total} contacts · ${lp.remaining} left", "${lp.total} جهة · ${lp.remaining} متبقي"),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (sel != null && p != null && p.total > 0) {
        val resumable = p.called > 0 && p.remaining > 0
        BButton(
            when {
                resumable -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                p.called > 0 -> T("Restart campaign", "إعادة تشغيل الحملة")
                else -> T("Start campaign", "ابدأ الحملة")
            },
            { act.startCampaign(sel, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
        )
        if (resumable) {
            BButton(T("Restart from the beginning", "ابدأ من الأول"), { act.startCampaign(sel, true) },
                Modifier.fillMaxWidth(), kind = BtnKind.Outline, icon = Icons.Rounded.Refresh)
        }
    }

    RunSetupStrip()
}
