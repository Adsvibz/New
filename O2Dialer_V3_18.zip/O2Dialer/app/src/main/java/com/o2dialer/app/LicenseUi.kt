package com.o2dialer.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/** Asks for the admin-issued activation code. Shown when a campaign is started on a device that is not activated. */
@Composable
fun ActivationDialog(act: MainActivity) {
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    BDialog(
        title = T("Activate this device", "تفعيل هذا الجهاز"),
        onDismiss = {
            if (!License.checking) {
                License.showActivation = false
                License.pendingStart = null
            }
        },
        confirmText = if (License.checking) T("Checking\u2026", "جارٍ التحقق\u2026") else T("Activate", "تفعيل"),
        confirmEnabled = code.trim().length >= 6 && !License.checking,
        onConfirm = {
            error = ""
            License.activate(code) { ok, msg ->
                if (ok) {
                    License.showActivation = false
                    Store.notify(Tk.SUCCESS, msg)
                    val pending = License.pendingStart
                    License.pendingStart = null
                    if (pending != null) act.startCampaign(pending.first, pending.second)
                } else {
                    error = msg
                }
            }
        }
    ) {
        Text(
            T("Enter the activation code you received from your administrator.", "أدخل كود التفعيل الذي استلمته من المسؤول."),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        BTextField(code, { code = it.uppercase() }, label = T("Activation code", "كود التفعيل"), placeholder = "O2D-XXXX-XXXX-XXXX")
        if (error.isNotEmpty()) Text(error, style = MaterialTheme.typography.bodySmall, color = readable(Sem.danger))
        Text(
            T("Device ID: ", "رقم الجهاز: ") + License.shortId(),
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Warning shown on the Live and campaign screens when licensing blocks campaigns. */
@Composable
fun LicenseBanner() {
    if (!License.enabled) return
    if (!License.activated) {
        Banner(
            Tk.WARN, T("This device is not activated", "هذا الجهاز غير مفعّل"),
            T("Enter your activation code to start campaigns.", "أدخل كود التفعيل لبدء الحملات."),
            actionText = T("Activate", "تفعيل")
        ) { License.showActivation = true }
    } else if (License.status == "suspended") {
        Banner(
            Tk.ERROR, T("This device has been deactivated", "هذا الجهاز موقوف"),
            T("New campaigns are blocked. Contact your administrator.", "الحملات الجديدة ممنوعة. تواصل مع المسؤول."),
            actionText = T("Check", "تحقق")
        ) { License.check { ok, msg -> Store.notify(if (ok) Tk.SUCCESS else Tk.ERROR, msg) } }
    }
}

/** Settings section: license state, permissions granted by the administrator, manual check. */
@Composable
fun LicenseSettingsSection() {
    if (!License.enabled) return
    val p = License.policy
    SettingsSection(Icons.Rounded.VerifiedUser, T("Device & license", "الجهاز والترخيص")) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(T("Status", "الحالة"), style = MaterialTheme.typography.bodyLarge)
            when {
                !License.activated -> Pill(T("Not activated", "غير مفعّل"), Sem.warning, Icons.Rounded.Warning)
                License.status == "suspended" -> Pill(T("Deactivated", "موقوف"), Sem.danger, Icons.Rounded.Error)
                else -> Pill(T("Active", "مفعّل"), Sem.success, Icons.Rounded.CheckCircle)
            }
        }
        val muted = MaterialTheme.colorScheme.onSurfaceVariant
        Text(T("Device ID: ", "رقم الجهاز: ") + License.shortId(), style = MaterialTheme.typography.bodyMedium, color = muted)
        Text(T("Server: ", "السيرفر: ") + License.serverHost(), style = MaterialTheme.typography.bodyMedium, color = muted)
        if (License.activated) {
            Text(
                T("Last verified: ", "آخر تحقق: ") + (if (License.lastOkAt > 0) fmtTime(License.lastOkAt) else T("never", "لم يتم")),
                style = MaterialTheme.typography.bodyMedium, color = muted
            )
            val offline = when {
                p.offlineHours <= 0 -> T("Internet required before every campaign", "الإنترنت مطلوب قبل كل حملة")
                p.offlineHours >= 9999 -> T("Offline use: unlimited", "العمل أوفلاين: بدون حد")
                else -> T("Offline use: up to ${p.offlineHours} h after the last check", "العمل أوفلاين: حتى ${p.offlineHours} ساعة بعد آخر تحقق")
            }
            Text(offline, style = MaterialTheme.typography.bodyMedium, color = muted)
            Text(
                T("Campaigns: ${if (p.canStart) "allowed" else "blocked"} \u00b7 Import: ${if (p.canImport) "allowed" else "blocked"} \u00b7 Share: ${if (p.canExport) "allowed" else "blocked"}",
                    "الحملات: ${if (p.canStart) "مسموح" else "ممنوع"} \u00b7 الاستيراد: ${if (p.canImport) "مسموح" else "ممنوع"} \u00b7 المشاركة: ${if (p.canExport) "مسموح" else "ممنوع"}"),
                style = MaterialTheme.typography.bodyMedium, color = muted
            )
        }
        if (License.activated) {
            BButton(
                if (License.checking) T("Checking\u2026", "جارٍ التحقق\u2026") else T("Check now", "تحقق الآن"),
                { License.check { ok, msg -> Store.notify(if (ok) Tk.SUCCESS else Tk.ERROR, msg) } },
                Modifier.fillMaxWidth(), kind = BtnKind.Outline, compact = true, enabled = !License.checking
            )
        } else {
            BButton(T("Enter activation code", "إدخال كود التفعيل"), { License.showActivation = true },
                Modifier.fillMaxWidth(), compact = true)
        }
    }
}
