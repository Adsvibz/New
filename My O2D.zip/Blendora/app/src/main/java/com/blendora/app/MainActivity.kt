@file:OptIn(ExperimentalMaterial3Api::class)

package com.blendora.app

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            Store.permTick = Store.permTick + 1
            if (has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
            else Store.notify(Tk.ERROR, T("Calling and phone-state permissions are required", "صلاحيات الاتصال وحالة الهاتف مطلوبة"))
            afterPerms = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) afterContacts?.invoke()
            else Store.notify(Tk.ERROR, T("Contacts permission was denied", "تم رفض صلاحية جهات الاتصال"))
            afterContacts = null
        }

    fun ensureContacts(after: () -> Unit) {
        if (has(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    /** Asks for everything a campaign needs, then runs [after] once calling is allowed. */
    fun requestCallPermissions(after: (() -> Unit)? = null) {
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !has(it) }
        if (missing.isEmpty()) { after?.invoke(); return }
        afterPerms = after
        permLauncher.launch(missing.toTypedArray())
    }

    /** restart = false -> continue from the first number not called yet. */
    fun startCampaign(listId: String, restart: Boolean = false) {
        if (Store.campActive()) {
            Store.notify(Tk.INFO, T("A campaign is already running", "توجد حملة جارية بالفعل"))
            Store.tab = 1
            return
        }
        requestCallPermissions {
            Store.runListId = listId
            Store.tab = 1
            DialerService.send(this, DialerService.ACT_START, listId, restart)
        }
    }

    override fun onResume() {
        super.onResume()
        Store.permTick = Store.permTick + 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val dir = if (Store.cfg.lang == 1) LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                AppTheme { Root(this@MainActivity) }
            }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tint = if (selected) cs.onSurface else cs.onSurfaceVariant
    Column(
        modifier.clip(RoundedCornerShape(Rd.l)).clickable(role = Role.Tab, onClick = onClick).heightIn(min = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal))
    }
}

/** The raised centre button: the live dialer. Turns green and pulses while a campaign is running. */
@Composable
private fun CenterDial(selected: Boolean, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (active) Sem.success else cs.primary
    val fg = if (active) Color.White else cs.onPrimary
    val label = T("Live dialer", "التشغيل المباشر")
    val sc by animateFloatAsState(if (selected) 1f else 0.92f, tween(160), label = "dial")
    Box(
        modifier.size(64.dp).graphicsLayer { scaleX = sc; scaleY = sc }
            .shadow(14.dp, CircleShape, ambientColor = bg, spotColor = bg)
            .clip(CircleShape).background(bg)
            .clickable(role = Role.Tab, onClick = onClick)
            .semantics { contentDescription = label },
        Alignment.Center
    ) {
        Icon(Icons.Rounded.Call, null, tint = fg, modifier = Modifier.size(28.dp))
        if (active) Box(Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp)) { PulseDot(Color.White, 8.dp) }
    }
}

/** Floating pill bar: Campaigns, Results | Live (raised) | Log, Settings. */
@Composable
private fun AppNavBar() {
    val cs = MaterialTheme.colorScheme
    val pill = RoundedCornerShape(50)
    Box(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.l).padding(bottom = Sp.s),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(Modifier.widthIn(max = 520.dp).fillMaxWidth().height(84.dp)) {
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(68.dp)
                    .shadow(10.dp, pill).clip(pill).background(cs.surface).padding(horizontal = Sp.s),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavItem(T("Campaigns", "الحملات"), Icons.Rounded.Campaign, Store.tab == 0, Modifier.weight(1f)) {
                    Store.selectedListId = null; Store.tab = 0
                }
                NavItem(T("Results", "النتائج"), Icons.Rounded.BarChart, Store.tab == 2, Modifier.weight(1f)) { Store.tab = 2 }
                Spacer(Modifier.weight(1f))
                NavItem(T("Log", "السجل"), Icons.Rounded.History, Store.tab == 3, Modifier.weight(1f)) { Store.tab = 3 }
                NavItem(T("Settings", "الإعدادات"), Icons.Rounded.Settings, Store.tab == 4, Modifier.weight(1f)) { Store.openSettings() }
            }
            CenterDial(Store.tab == 1, Store.campActive(), Modifier.align(Alignment.TopCenter)) { Store.tab = 1 }
        }
    }
}

@Composable
fun Root(act: MainActivity) {
    val activity = LocalContext.current as Activity

    val keep = Store.cfg.keepScreenOn && (Store.camp.status == CS.RUNNING || Store.camp.status == CS.WAITING)
    LaunchedEffect(keep) {
        if (keep) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    // When a campaign completes, jump to its results.
    LaunchedEffect(Store.pendingResultsNav) {
        if (Store.pendingResultsNav) { Store.tab = 2; Store.pendingResultsNav = false }
    }

    BackHandler(enabled = Store.tab != 0 || Store.selectedListId != null) {
        when {
            Store.tab == 4 -> Store.tab = Store.prevTab
            Store.tab == 0 && Store.selectedListId != null -> Store.selectedListId = null
            else -> Store.tab = 0
        }
    }

    val screenKey = if (Store.tab == 0 && Store.selectedListId != null) 10 else Store.tab
    // The floating bar belongs to the five main destinations; the campaign detail page is full-screen.
    val showNav = screenKey in 0..4

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = { if (showNav) AppNavBar() }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
            Responsive {
                AnimatedContent(
                    targetState = screenKey,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                    label = "screen"
                ) { k ->
                    when (k) {
                        0 -> ListsScreen()
                        10 -> Store.selectedListId?.let { ListDetail(it, act) }
                        1 -> LiveScreen(act)
                        2 -> ResultsScreen()
                        3 -> LogScreen()
                        else -> SettingsScreen()
                    }
                }
            }
            ToastHost(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp, start = Sp.l, end = Sp.l)
            )
            Store.stageTarget?.let { (lid, eid) -> StageSheet(lid, eid) }
        }
    }
}
