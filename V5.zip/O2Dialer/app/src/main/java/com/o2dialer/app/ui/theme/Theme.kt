package com.o2dialer.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.o2dialer.app.R
import com.o2dialer.app.domain.model.AppSettings
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Stage

// =========================================================================================
// O2Dialer design system — derived from the "Augen Pro" reference:
// clinical off-white canvas, whisper-weight type, hairline borders, zero shadows,
// pill / soft-enclosure shapes, one electric blue used ONLY for links and outlines.
// =========================================================================================

/** Spacing scale (reference scale, adapted to a phone). */
object Sp {
    val xs = 4.dp
    val s = 6.dp
    val m = 10.dp
    val l = 14.dp
    val xl = 22.dp      // screen padding / card padding
    val xxl = 30.dp
    val xxxl = 50.dp    // section gap
}

/** Corner radii. Buttons & inputs are pills, cards are soft enclosures. */
object Rd {
    val s = 10.dp       // small rows, nav-style containers
    val m = 26.dp       // buttons, inputs, nav pill
    val l = 36.dp       // cards
    val xl = 44.dp      // hero, dialogs, sheets
}

/** The reference palette. */
object Ink {
    val offBlack = Color(0xFF0F1012)      // primary text, dark surfaces
    val pureBlack = Color(0xFF020201)     // emphasis
    val offWhite = Color(0xFFF2F2F4)      // page canvas
    val pureWhite = Color(0xFFFDFDFD)     // elevated surfaces
    val steel = Color(0xFF5E5E5E)         // muted text
    val ash = Color(0xFF8F8F8F)           // tertiary / disabled
    val signalBlue = Color(0xFF0071E3)    // links + outlines only. Never a fill.
    val signalBlueDark = Color(0xFF2997FF) // same role on dark surfaces (contrast)
    val darkRaised = Color(0xFF1C1D21)    // dark-theme equivalent of the hero surface
}

/**
 * Functional state colours. The brand is monochrome + blue, so these are rationed:
 * they only ever appear as tiny dots / glyphs, never as fills or large text.
 */
object Sem {
    val success = Color(0xFF2E9E62)
    val warning = Color(0xFFC98A2B)
    val danger = Color(0xFFC8453B)
    val info = Ink.signalBlue
}

@Composable
fun isDarkSurface(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

/** Link / interactive-outline colour. */
@Composable
fun linkBlue(): Color = if (isDarkSurface()) Ink.signalBlueDark else Ink.signalBlue

/** Hero / footer "dark surface" that stays dark in both themes. */
@Composable
fun heroSurface(): Color = if (isDarkSurface()) Ink.darkRaised else Ink.offBlack

/** Stronger hairline for inputs / outline buttons (card hairlines use colorScheme.outline). */
val ColorScheme.line: Color get() = outlineVariant

private val InstrumentSans = FontFamily(Font(R.font.instrument_sans, FontWeight.Normal))

private val LightC = lightColorScheme(
    primary = Ink.offBlack, onPrimary = Ink.pureWhite,
    primaryContainer = Color(0xFFE9E9EC), onPrimaryContainer = Ink.offBlack,
    secondary = Ink.steel, onSecondary = Ink.pureWhite,
    secondaryContainer = Color(0xFFE9E9EC), onSecondaryContainer = Ink.offBlack,
    tertiary = Ink.signalBlue,
    background = Ink.offWhite, onBackground = Ink.offBlack,
    surface = Ink.pureWhite, onSurface = Ink.offBlack,
    surfaceVariant = Color(0xFFE9E9EC), onSurfaceVariant = Ink.steel,
    surfaceTint = Color.Transparent,
    outline = Color(0x0F000000), outlineVariant = Color(0x1F000000),
    inverseSurface = Ink.offBlack, inverseOnSurface = Ink.pureWhite,
    error = Sem.danger
)

private val DarkC = darkColorScheme(
    primary = Ink.offWhite, onPrimary = Ink.offBlack,
    primaryContainer = Color(0xFF2A2B30), onPrimaryContainer = Ink.offWhite,
    secondary = Color(0xFFA0A0A8), onSecondary = Ink.offBlack,
    secondaryContainer = Color(0xFF2A2B30), onSecondaryContainer = Ink.offWhite,
    tertiary = Ink.signalBlueDark,
    background = Ink.offBlack, onBackground = Ink.offWhite,
    surface = Color(0xFF17181B), onSurface = Ink.offWhite,
    surfaceVariant = Color(0xFF26272C), onSurfaceVariant = Color(0xFFA0A0A8),
    surfaceTint = Color.Transparent,
    outline = Color(0x14FFFFFF), outlineVariant = Color(0x29FFFFFF),
    inverseSurface = Ink.offWhite, inverseOnSurface = Ink.offBlack,
    error = Color(0xFFE0675D)
)

fun statusColor(s: CallStatus): Color = when (s) {
    CallStatus.ANSWERED -> Sem.success
    CallStatus.NO_ANSWER -> Sem.warning
    CallStatus.FAILED -> Sem.danger
    CallStatus.CALLING -> Sem.info
    CallStatus.COMPLETED -> Color(0xFF3D8F8A)
    CallStatus.PENDING -> Ink.ash
}

fun Stage.color(): Color = when (this) {
    Stage.POTENTIAL -> Color(0xFF3B82F6)
    Stage.NOT_INTERESTED -> Color(0xFFC8453B)
    Stage.CALL_BACK -> Color(0xFFC98A2B)
    Stage.WHATSAPP -> Color(0xFF2E9E62)
    Stage.VOICEMAIL -> Color(0xFF7C6BC9)
    Stage.NONE -> Ink.ash
}

/**
 * One typeface, one weight (350 whisper-weight: the single regular face is used, never bold),
 * tight -0.02em tracking in Latin scripts. Arabic keeps neutral tracking so letters still join.
 * Sizes follow the reference scale: 10 / 12 / 14 / 16 / 18 / 27.
 */
private fun typography(ff: FontFamily, tracking: TextUnit): Typography {
    fun st(size: Int) = TextStyle(
        fontFamily = ff, fontWeight = FontWeight(350), fontSize = size.sp,
        lineHeight = (size * 1.2f).sp, letterSpacing = tracking
    )
    return Typography(
        displayLarge = st(27), displayMedium = st(27), displaySmall = st(27),
        headlineLarge = st(27), headlineMedium = st(27), headlineSmall = st(27),
        titleLarge = st(18), titleMedium = st(16), titleSmall = st(14),
        bodyLarge = st(16), bodyMedium = st(14), bodySmall = st(12),
        labelLarge = st(14), labelMedium = st(12), labelSmall = st(10)
    )
}

@Composable
fun AppTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkC else LightC
    val ty = remember(settings.lang) {
        if (settings.lang == 1) typography(FontFamily.Default, 0.em) else typography(InstrumentSans, (-0.02).em)
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val ic = WindowCompat.getInsetsController(w, view)
                ic.isAppearanceLightStatusBars = !dark
                ic.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = scheme, typography = ty,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(18.dp), small = RoundedCornerShape(Rd.s), medium = RoundedCornerShape(Rd.m),
            large = RoundedCornerShape(Rd.l), extraLarge = RoundedCornerShape(Rd.xl)
        )
    ) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
