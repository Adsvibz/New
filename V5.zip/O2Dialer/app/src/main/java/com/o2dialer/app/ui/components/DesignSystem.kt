@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.o2dialer.app.core.T
import com.o2dialer.app.core.Tk
import com.o2dialer.app.core.UiToast
import com.o2dialer.app.core.label
import com.o2dialer.app.domain.model.CallStatus
import com.o2dialer.app.domain.model.Stage
import com.o2dialer.app.ui.LocalAppActions
import com.o2dialer.app.ui.LocalLiveBadge
import com.o2dialer.app.ui.Tab
import com.o2dialer.app.ui.theme.Rd
import com.o2dialer.app.ui.theme.Sem
import com.o2dialer.app.ui.theme.Sp
import com.o2dialer.app.ui.theme.color
import com.o2dialer.app.ui.theme.line
import com.o2dialer.app.ui.theme.linkBlue
import com.o2dialer.app.ui.theme.statusColor
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

// ====================================================================== layout helpers
/** Caps the content width so tablets / landscape keep the reference's centred measure. */
@Composable
fun Responsive(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
        Box(Modifier.widthIn(max = 640.dp).fillMaxSize()) { content() }
    }
}

@Composable
fun isCompact(): Boolean = LocalConfiguration.current.screenWidthDp < 360

// ====================================================================== motion
@Composable
fun Modifier.pressScale(src: MutableInteractionSource): Modifier {
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.98f else 1f, tween(110), label = "press")
    return this.graphicsLayer { scaleX = s; scaleY = s }
}

@Composable
fun PulseDot(color: Color, size: Dp = 8.dp) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(1f, 0.3f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Box(Modifier.size(size).clip(CircleShape).background(color.copy(alpha = a)))
}

/** Loading placeholder. */
@Composable
fun Skeleton(modifier: Modifier = Modifier, radius: Dp = Rd.s) {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(0.04f, 0.10f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Box(modifier.clip(RoundedCornerShape(radius)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = a)))
}

@Composable
fun Dot(color: Color, size: Dp = 6.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color))
}

// ====================================================================== progress (monochrome hairlines)
@Composable
fun BProgress(
    progress: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface,
    track: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), height: Dp = 4.dp
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "bar")
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
        Box(Modifier.fillMaxWidth(p).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable
fun ProgressRing(
    progress: Float, size: Dp, stroke: Dp, color: Color, track: Color, content: @Composable () -> Unit
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(600), label = "ring")
    Box(Modifier.size(size), Alignment.Center) {
        CircularProgressIndicator(progress = { p }, modifier = Modifier.fillMaxSize(), color = color,
            trackColor = track, strokeWidth = stroke, strokeCap = StrokeCap.Round)
        content()
    }
}

// ====================================================================== buttons
/**
 * Primary   = off-black pill (the one action that matters on a screen)
 * Tonal     = "floating CTA pill": 5% charcoal wash, black text, blue glyph
 * Outline   = hairline pill
 * Ghost     = blue text link
 * Danger    = hairline pill in the danger colour
 * Blue is never a fill.
 */
enum class BtnKind { Primary, Tonal, Outline, Ghost, Danger }

@Composable
fun BButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary,
    icon: ImageVector? = null, enabled: Boolean = true, compact: Boolean = false, iconOnly: Boolean = false
) {
    val src = remember { MutableInteractionSource() }
    val m = modifier.pressScale(src).heightIn(min = if (compact) 44.dp else 52.dp)
    val shape = RoundedCornerShape(Rd.m)
    val pad = PaddingValues(horizontal = if (iconOnly) 12.dp else 22.dp)
    val cs = MaterialTheme.colorScheme
    val link = linkBlue()
    val flat = ButtonDefaults.buttonElevation(0.dp, 0.dp, 0.dp, 0.dp, 0.dp)
    val body: @Composable RowScope.() -> Unit = {
        if (icon != null) Icon(icon, null, Modifier.size(18.dp), tint = if (kind == BtnKind.Tonal) link else LocalContentColor.current)
        if (icon != null && !iconOnly) Spacer(Modifier.width(8.dp))
        if (!iconOnly) Text(text, style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    when (kind) {
        BtnKind.Primary -> Button(onClick, m, enabled, shape, elevation = flat, contentPadding = pad,
            interactionSource = src, content = body)
        BtnKind.Tonal -> Button(onClick, m, enabled, shape,
            colors = ButtonDefaults.buttonColors(containerColor = cs.onSurface.copy(alpha = 0.05f), contentColor = cs.onSurface),
            elevation = flat, contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Danger -> OutlinedButton(onClick, m, enabled, shape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Sem.danger),
            border = BorderStroke(0.5.dp, Sem.danger), contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Outline -> OutlinedButton(onClick, m, enabled, shape,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.onSurface),
            border = BorderStroke(0.5.dp, cs.line), contentPadding = pad, interactionSource = src, content = body)
        BtnKind.Ghost -> TextButton(onClick, m, enabled, shape,
            colors = ButtonDefaults.textButtonColors(contentColor = link),
            contentPadding = pad, interactionSource = src, content = body)
    }
}

// ====================================================================== inputs
/** Hairline pill input on a pure-white surface; the focus ring is a 1dp blue outline (never a fill). */
@Composable
fun BTextField(
    value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, label: String? = null,
    placeholder: String? = null, supporting: String? = null, keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true, minLines: Int = 1, leading: ImageVector? = null, isError: Boolean = false
) {
    val cs = MaterialTheme.colorScheme
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(Rd.m)
    val numeric = keyboardType == KeyboardType.Phone || keyboardType == KeyboardType.Number
    val borderColor = when { isError -> Sem.danger; focused -> linkBlue(); else -> cs.line }
    val textStyle = MaterialTheme.typography.bodyLarge.copy(
        color = cs.onSurface, textDirection = if (numeric) TextDirection.Ltr else TextDirection.Content
    )
    Column(modifier.fillMaxWidth()) {
        if (label != null) Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
            modifier = Modifier.padding(start = Sp.l, bottom = Sp.xs))
        Row(
            Modifier.fillMaxWidth().clip(shape).background(cs.surface)
                .border(if (focused || isError) 1.dp else 0.5.dp, borderColor, shape)
                .padding(horizontal = Sp.xl, vertical = Sp.l),
            verticalAlignment = if (singleLine) Alignment.CenterVertically else Alignment.Top
        ) {
            if (leading != null) {
                Icon(leading, null, tint = com.o2dialer.app.ui.theme.Ink.ash, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(Sp.m))
            }
            Box(Modifier.weight(1f)) {
                if (value.isEmpty() && placeholder != null) {
                    Text(placeholder, style = textStyle.copy(color = com.o2dialer.app.ui.theme.Ink.ash))
                }
                BasicTextField(
                    value = value, onValueChange = onChange, singleLine = singleLine,
                    minLines = minLines, maxLines = if (singleLine) 1 else 6, textStyle = textStyle,
                    cursorBrush = SolidColor(linkBlue()), keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
                )
            }
        }
        if (supporting != null) Text(supporting, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
            modifier = Modifier.padding(start = Sp.l, top = Sp.xs))
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.m)
    Row(Modifier.fillMaxWidth().clip(shape).background(cs.surface).border(0.5.dp, cs.line, shape).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            val bg by animateColorAsState(if (on) cs.onSurface.copy(alpha = 0.06f) else Color.Transparent, tween(180), label = "seg")
            Box(Modifier.weight(1f).clip(RoundedCornerShape(Rd.m)).background(bg).clickable { onSelect(i) }
                .padding(vertical = 11.dp), Alignment.Center) {
                Text(o, maxLines = 1, color = if (on) cs.onSurface else cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/** Selectable pill used for filters. */
@Composable
fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (selected) cs.onSurface.copy(alpha = 0.06f) else cs.surface)
            .border(0.5.dp, if (selected) cs.onSurface.copy(alpha = 0.35f) else cs.line, shape)
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(label, maxLines = 1, style = MaterialTheme.typography.labelLarge,
            color = if (selected) cs.onSurface else cs.onSurfaceVariant)
    }
}

// ====================================================================== surfaces
/** Soft-enclosure card: pure-white surface on the off-white canvas, 0.5dp hairline, no shadow. */
@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val shape = RoundedCornerShape(Rd.l)
    val border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
    val flat = CardDefaults.cardElevation(defaultElevation = 0.dp)
    if (onClick != null) Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, elevation = flat,
        border = border, content = content)
    else Card(modifier = modifier, shape = shape, colors = colors, elevation = flat, border = border, content = content)
}

/** Quiet 12sp preamble. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Reference "section label pair": small muted label above a 27sp title. Hierarchy by size alone. */
@Composable
fun ScreenHeader(label: String, title: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(top = Sp.l, bottom = Sp.xs), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = com.o2dialer.app.ui.theme.Ink.ash)
        Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Hairline circle holding a thin outlined glyph. */
@Composable
fun IconTile(icon: ImageVector, color: Color = Color.Unspecified, size: Dp = 44.dp) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size).clip(CircleShape).background(cs.surface).border(0.5.dp, cs.line, CircleShape), Alignment.Center) {
        Icon(icon, null, tint = if (color == Color.Unspecified) cs.onSurface else color, modifier = Modifier.size(size * 0.46f))
    }
}

// ====================================================================== feedback: banner + toast + empty
private fun kindColor(kind: Int): Color = when (kind) {
    Tk.SUCCESS -> Sem.success; Tk.ERROR -> Sem.danger; Tk.WARN -> Sem.warning; else -> Sem.info
}

@Composable
fun Banner(
    kind: Int, title: String, message: String? = null, modifier: Modifier = Modifier,
    actionText: String? = null, onAction: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.m)
    Row(
        modifier.fillMaxWidth().clip(shape).background(cs.surface).border(0.5.dp, cs.line, shape).padding(Sp.l),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Dot(kindColor(kind), 8.dp)
        Spacer(Modifier.width(Sp.l))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (message != null) Text(message, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (actionText != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionText, color = linkBlue(), style = MaterialTheme.typography.labelLarge) }
        }
    }
}

@Composable
fun ToastHost(toast: UiToast?, onDismiss: (Long) -> Unit, modifier: Modifier = Modifier) {
    var last by remember { mutableStateOf<UiToast?>(null) }
    LaunchedEffect(toast?.id) {
        if (toast != null) {
            last = toast
            delay(2600)
            onDismiss(toast.id)
        }
    }
    AnimatedVisibility(
        visible = toast != null, modifier = modifier,
        enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()
    ) {
        val shown = toast ?: last
        if (shown != null) {
            Surface(shape = RoundedCornerShape(Rd.m), color = MaterialTheme.colorScheme.inverseSurface) {
                Row(Modifier.padding(horizontal = Sp.xl, vertical = Sp.l), verticalAlignment = Alignment.CenterVertically) {
                    Dot(kindColor(shown.kind), 8.dp)
                    Spacer(Modifier.width(Sp.m))
                    Text(shown.msg, color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector, title: String, sub: String, modifier: Modifier = Modifier,
    actionText: String? = null, onAction: (() -> Unit)? = null
) {
    Column(modifier.fillMaxSize().padding(Sp.xxl), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        IconTile(icon, size = 84.dp)
        Spacer(Modifier.height(Sp.xl))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Sp.s))
        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(Sp.xl))
            BButton(actionText, onAction, kind = BtnKind.Tonal, compact = true)
        }
    }
}

// ====================================================================== small atoms
@Composable
fun NumText(
    n: String, modifier: Modifier = Modifier, style: TextStyle = MaterialTheme.typography.bodyMedium,
    color: Color = Color.Unspecified
) {
    Text(n, modifier = modifier, style = style.copy(textDirection = TextDirection.Ltr), color = color)
}

@Composable
fun Avatar(text: String, color: Color = Color.Unspecified, size: Dp = 44.dp) {
    val cs = MaterialTheme.colorScheme
    val ch = text.trim().firstOrNull { it.isLetter() }?.uppercase() ?: "#"
    val ring = color != Color.Unspecified
    Box(
        Modifier.size(size).clip(CircleShape).background(cs.surface)
            .border(if (ring) 1.dp else 0.5.dp, if (ring) color else cs.line, CircleShape),
        Alignment.Center
    ) { Text(ch, style = MaterialTheme.typography.titleSmall, color = cs.onSurface) }
}

/** Neutral hairline tag. With [onClick] it becomes a blue-outline link tag (the reference "pill tag chip"). */
@Composable
fun Pill(text: String, tint: Color, icon: ImageVector? = null, onClick: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    val link = linkBlue()
    val interactive = onClick != null
    val shape = RoundedCornerShape(50)
    var m = Modifier.clip(shape)
    if (onClick != null) m = m.clickable { onClick() }
    Row(
        m.border(0.5.dp, if (interactive) link else cs.line, shape).padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = if (interactive) link else tint, modifier = Modifier.size(12.dp))
            Spacer(Modifier.width(5.dp))
        }
        Text(text, style = MaterialTheme.typography.labelMedium, color = if (interactive) link else cs.onSurfaceVariant)
    }
}

/** Hairline tag with a small state dot. */
@Composable
fun DotTag(text: String, dot: Color, onClick: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    val link = linkBlue()
    val shape = RoundedCornerShape(50)
    var m = Modifier.clip(shape)
    if (onClick != null) m = m.clickable { onClick() }
    Row(
        m.border(0.5.dp, if (onClick != null) link else cs.line, shape).padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Dot(dot, 6.dp)
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = if (onClick != null) link else cs.onSurfaceVariant)
    }
}

fun stageIcon(s: Stage): ImageVector = when (s) {
    Stage.POTENTIAL -> Icons.Outlined.Star
    Stage.NOT_INTERESTED -> Icons.Outlined.ThumbDown
    Stage.CALL_BACK -> Icons.Outlined.Replay
    Stage.WHATSAPP -> Icons.Outlined.Chat
    Stage.VOICEMAIL -> Icons.Outlined.Voicemail
    Stage.NONE -> Icons.Outlined.Label
}

@Composable
fun StatusPill(s: CallStatus) = DotTag(s.label(), statusColor(s))

@Composable
fun StagePill(s: Stage, onClick: (() -> Unit)? = null) = DotTag(s.label(), s.color(), onClick)

/** "Inline icon link": hairline pill, blue glyph, ink label. */
@Composable
fun ActionChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).background(cs.surface).border(0.5.dp, cs.line, shape)
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = linkBlue(), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun WhatsAppButton(number: String, size: Dp = 34.dp) {
    val app = LocalAppActions.current
    val link = linkBlue()
    Box(Modifier.size(size).clip(CircleShape).border(0.5.dp, link, CircleShape).clickable { app.openWhatsApp(number) },
        Alignment.Center) {
        Icon(Icons.Outlined.Chat, contentDescription = "WhatsApp", tint = link, modifier = Modifier.size(size * 0.5f))
    }
}

/** The brand glyph: an 8-pointed compass star. */
@Composable
fun LogoMark(dp: Dp, color: Color = MaterialTheme.colorScheme.onSurface) {
    Canvas(Modifier.size(dp)) {
        val c = center
        val outer = this.size.minDimension / 2f
        val path = Path()
        for (k in 0 until 16) {
            val ang = Math.toRadians(-90.0 + k * 22.5)
            val r = when {
                k % 4 == 0 -> outer
                k % 4 == 2 -> outer * 0.6f
                else -> outer * 0.2f
            }
            val x = c.x + (r * cos(ang)).toFloat()
            val y = c.y + (r * sin(ang)).toFloat()
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color)
    }
}

// ====================================================================== top bar: floating pill navigation
@Composable
private fun LivePill(pct: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.padding(end = Sp.xs).clip(shape).border(0.5.dp, cs.line, shape)
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PulseDot(Sem.success, 6.dp)
        Spacer(Modifier.width(6.dp))
        Text("${T("Live", "مباشر")} $pct%", style = MaterialTheme.typography.labelMedium)
    }
}

/** A floating pure-white pill (never a full-width bar): menu/back · star + wordmark · live · settings. */
@Composable
fun AppBar(
    onMenu: (() -> Unit)?, onBack: (() -> Unit)? = null, showSettings: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val app = LocalAppActions.current
    val badge = LocalLiveBadge.current
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.m)
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m)) {
        Row(
            Modifier.fillMaxWidth().clip(shape).background(cs.surface).border(0.5.dp, cs.outline, shape).padding(Sp.xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(20.dp))
            } else if (onMenu != null) IconButton(onClick = onMenu, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Outlined.Menu, null, Modifier.size(20.dp))
            } else Spacer(Modifier.width(40.dp))
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                LogoMark(16.dp)
                Spacer(Modifier.width(Sp.s))
                Text("O2Dialer", style = MaterialTheme.typography.titleSmall)
            }
            if (badge != null) LivePill(badge.pct) { app.navigate(Tab.LIVE) }
            actions()
            if (showSettings) IconButton(onClick = { app.openSettings() }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Outlined.Settings, null, Modifier.size(20.dp))
            } else Spacer(Modifier.width(40.dp))
        }
    }
}

// ====================================================================== dialog
@Composable
fun BDialog(
    title: String?, onDismiss: () -> Unit, confirmText: String? = null, onConfirm: (() -> Unit)? = null,
    dismissText: String = T("Cancel", "إلغاء"), destructive: Boolean = false, confirmEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss, shape = RoundedCornerShape(Rd.xl), containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        title = if (title != null) { { Text(title, style = MaterialTheme.typography.titleLarge) } } else null,
        text = { Column(verticalArrangement = Arrangement.spacedBy(Sp.l), content = content) },
        confirmButton = {
            if (confirmText != null && onConfirm != null)
                BButton(confirmText, onConfirm, kind = if (destructive) BtnKind.Danger else BtnKind.Primary,
                    compact = true, enabled = confirmEnabled)
        },
        dismissButton = { BButton(dismissText, onDismiss, kind = BtnKind.Ghost, compact = true) }
    )
}
