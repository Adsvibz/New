# O2Dialer — Design System (v4.1, based on the "Augen Pro" reference)

Clinical off-white canvas · whisper-weight type · hairline borders · zero shadows ·
pill / soft-enclosure shapes · one electric blue used **only** for links and outlines.

## Tokens (`ui/theme/Theme.kt`)
| Reference | Token | Value |
|---|---|---|
| Page canvas | `Ink.offWhite` / `colorScheme.background` | `#F2F2F4` |
| Elevated surface | `Ink.pureWhite` / `colorScheme.surface` | `#FDFDFD` |
| Primary text | `Ink.offBlack` | `#0F1012` |
| Emphasis | `Ink.pureBlack` | `#020201` |
| Muted / tertiary | `Ink.steel` / `Ink.ash` | `#5E5E5E` / `#8F8F8F` |
| Signal blue (text + outline only) | `Ink.signalBlue` → `linkBlue()` | `#0071E3` (dark: `#2997FF`) |
| Card hairline | `colorScheme.outline` | `rgba(0,0,0,.06)` 0.5dp |
| Input / outline-button line | `colorScheme.line` | `rgba(0,0,0,.12)` 0.5dp |
| Dark surface (hero, footer, drawer header) | `heroSurface()` | `#0F1012` |

**Type:** one family, one weight (never bold). Sizes 10 / 12 / 14 / 16 / 18 / 27, line-height 1.2, tracking −0.02em (Latin only; Arabic keeps neutral tracking so letters join). Hierarchy comes from size alone.

**Spacing (`Sp`)** 4 · 6 · 10 · 14 · 22 · 30 · 50 (card padding 22, screen padding 22, section gap 50).
**Radii (`Rd`)** 10 (rows) · 26 (buttons, inputs, nav pill) · 36 (cards) · 44 (hero, dialogs, sheets) · full (tags).

## Components (`ui/components/DesignSystem.kt`)
* **AppBar** — floating pure-white pill: menu/back · star + wordmark · live indicator · settings.
* **ScreenHeader** — "section label pair": 12sp muted label over a 27sp title.
* **Panel** — pure-white card on the canvas, 0.5dp hairline, no shadow.
* **BButton** — Primary (off-black pill, one per screen) · Tonal (5% charcoal wash, blue glyph = the reference's floating CTA) · Outline (hairline) · Ghost (blue text) · Danger (hairline in danger colour). Blue is never a fill.
* **BTextField** — hairline pill on white; focus = 1dp blue outline.
* **Segmented / ChoiceChip / ActionChip** — hairline pills; selection = 5% wash.
* **Pill / DotTag** — hairline tags; interactive tags get the blue outline + blue text.
* **Banner / ToastHost** — hairline card / off-black pill with a state dot.
* **BProgress / ProgressRing** — thin monochrome strokes.
* **LogoMark** — 8-pointed compass star (also the launcher + notification icon).

## Deliberate adaptations (and why)
1. **Typeface:** PP Neue Montreal isn't available offline → **Instrument Sans Regular** (closest clean neo-grotesque available). It has no lighter cut, so text is regular weight rather than a true 350. Swap `res/font/instrument_sans.ttf` for Inter Light/Regular if you want it lighter.
2. **Primary action:** the reference has no CTA colour; the single main action per screen is an off-black pill, secondary actions use the 5% wash. Blue stays text/outline only.
3. **State colours:** the reference is monochrome + blue, but a dialer must show answered / no answer / failed / stage. They are kept as **6–8dp dots and tiny glyphs only**, never fills or large text.
4. **Desktop → phone scale:** 54px card radius and 69px padding become 36dp / 22dp; 94px section gaps become 50dp.
5. **Hero imagery:** no 3D render; the Live screen uses the dark surface card as the single high-contrast moment. No gradients anywhere.
6. **Shadows:** none, except the system popup menu (Material 3 draws its own).
7. **Dark theme:** the reference is light-only. Light is the default; dark is an optional inversion.
