@file:OptIn(ExperimentalMaterial3Api::class)

package com.o2dialer.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
private fun StatCard(label: String, value: Int, color: Color, icon: ImageVector, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val fg = readable(color)
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(color.copy(alpha = 0.13f)).padding(Sp.l),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Box(
            Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.surface.copy(alpha = 0.7f)),
            Alignment.Center
        ) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(Sp.m))
        Text("$value", style = MaterialTheme.typography.headlineLarge.copy(fontSize = 32.sp), color = fg)
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp), color = fg, maxLines = 1)
    }
}

@Composable
private fun LiveHeader(subtitle: String) {
    Column(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = Sp.xl, end = Sp.xl, top = Sp.l, bottom = Sp.s)
    ) {
        Text(T("Live dialer", "التشغيل المباشر"), style = MaterialTheme.typography.headlineLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SetupCell(value: String, caption: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(Rd.m)
    Column(
        modifier.clip(shape).background(cs.surface).border(1.dp, cs.outline, shape)
            .clickable { Store.openSettings() }.padding(Sp.m),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        Text(caption, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
    }
}

/** Three small cells summarising the run settings; tapping any of them opens Settings. */
@Composable
private fun RunSetupStrip() {
    val s = Store.cfg
    val gap = if (s.randomDelay) "${s.delaySec}\u2013${s.delayMaxSec}s" else "${s.delaySec}s"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
        SetupCell(gap, T("between calls", "بين المكالمات"), Modifier.weight(1f))
        SetupCell(
            "${s.retries}",
            if (s.retries == 0) T("no retries", "بدون إعادة") else T("retries", "إعادة محاولة"),
            Modifier.weight(1f)
        )
        SetupCell(
            if (s.autoSpeaker) T("On", "مفعّل") else T("Off", "مغلق"),
            if (s.autoSpeaker) T("mic muted", "المايك مكتوم") else T("mic live", "المايك يعمل"),
            Modifier.weight(1f)
        )
    }
}

@Composable
fun LiveScreen(act: MainActivity) {
    val c = Store.camp
    val active = Store.campActive()
    val compact = isCompact()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }
    val heroList = Store.lists.find { it.id == c.listId }
    val showHero = (active || c.status == CS.FINISHED) && heroList != null

    val subtitle = when {
        c.status == CS.PAUSED -> T("Campaign paused", "الحملة متوقفة مؤقتًا")
        active -> T("Campaign in progress", "الحملة قيد التشغيل")
        c.status == CS.FINISHED && heroList != null -> T("Campaign finished", "انتهت الحملة")
        else -> T("Choose a campaign to start", "اختر حملة للبدء")
    }

    Scaffold(
        topBar = { LiveHeader(subtitle) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.xl, vertical = Sp.s),
            verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            PermissionBanner(act)
            if (showHero && heroList != null) {
                val p = Store.prog(heroList)
                Hero(c, p, now, compact, active)
                if (c.status == CS.FINISHED) Banner(if (c.error) Tk.ERROR else Tk.SUCCESS, c.message)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m), modifier = Modifier.fillMaxWidth()) {
                    StatCard(T("Answered", "ردّوا"), p.answered, Sem.success, Icons.Rounded.Check, Modifier.weight(1f))
                    StatCard(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, Icons.Rounded.PhoneMissed, Modifier.weight(1f))
                    StatCard(T("Failed", "فشل"), p.failed, Sem.danger, Icons.Rounded.ErrorOutline, Modifier.weight(1f))
                }
                if (active && !Store.cfg.shuffle) UpNext(heroList, p.remaining)
                if (active) RunSetupStrip()
            }
            if (!active) {
                if (c.status == CS.FINISHED && heroList != null && !c.error) {
                    BButton(T("View campaign results", "عرض نتائج الحملة"),
                        { Store.resultsListId = c.listId; Store.tab = 2 }, Modifier.fillMaxWidth(),
                        kind = BtnKind.Tonal, icon = Icons.Rounded.BarChart)
                }
                Launcher(act)
            }
            Spacer(Modifier.height(Sp.l))
        }
    }
}

@Composable
private fun Hero(c: CampState, p: Prog, now: Long, compact: Boolean, showControls: Boolean) {
    val finished = c.status == CS.FINISHED
    val calling = c.status == CS.RUNNING && c.currentNumber.isNotEmpty()
    val secs = if (c.nextAt > now) ((c.nextAt - now + 999) / 1000).toInt() else 0

    val label = when {
        finished -> if (c.error) T("Stopped", "توقفت") else T("Finished", "انتهت")
        c.status == CS.PAUSED -> T("Paused", "متوقفة")
        c.status == CS.WAITING -> T("Waiting", "في الانتظار")
        calling -> T("Calling now", "جارٍ الاتصال")
        c.awaitingStage -> T("Your input", "بانتظارك")
        else -> T("Next call", "الاتصال التالي")
    }
    val big = when {
        calling -> c.currentName.ifBlank { c.currentNumber }
        finished -> c.message
        c.status == CS.PAUSED -> T("Paused", "متوقفة مؤقتًا")
        c.awaitingStage -> T("Choose the call result", "اختر نتيجة المكالمة")
        c.status == CS.WAITING -> T("Waiting", "في الانتظار")
        secs > 0 -> "${secs}s"
        else -> c.message.ifBlank { "…" }
    }
    val small = when {
        calling && c.currentName.isNotBlank() -> c.currentNumber
        finished -> T("${p.answered} answered · ${p.noAnswer} no answer · ${p.failed} failed",
            "${p.answered} ردّوا · ${p.noAnswer} لم يردّوا · ${p.failed} فشل")
        c.status == CS.PAUSED -> T("Tap Resume to continue", "اضغط استئناف للمتابعة")
        c.awaitingStage && secs > 0 -> T("Continuing in ${secs}s", "المتابعة بعد ${secs} ث")
        c.awaitingStage -> c.message
        c.status == CS.WAITING -> c.message
        secs > 0 -> c.message
        else -> ""
    }

    val hasName = c.currentName.isNotBlank()
    val bigSize = if (compact || (calling && !hasName)) 26.sp else 32.sp
    val glass = Color.White.copy(alpha = 0.12f)
    val glassLine = Color.White.copy(alpha = 0.18f)
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(HeroBg).padding(Sp.xxl)) {
        Column(verticalArrangement = Arrangement.spacedBy(Sp.xl), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(glass).border(1.dp, glassLine, RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (finished) Icon(Icons.Rounded.CheckCircle, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    else PulseDot(Color.White, 6.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(label, color = Color.White, style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                }
                Spacer(Modifier.weight(1f))
                Text(c.listName, color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.labelLarge,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
            }
            if (calling) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(glass)
                            .border(1.dp, glassLine, RoundedCornerShape(16.dp)),
                        Alignment.Center
                    ) {
                        if (hasName) Text(initialsOf(c.currentName), color = Color.White, style = MaterialTheme.typography.titleMedium)
                        else Icon(Icons.Rounded.Call, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(Sp.l))
                    HeroTexts(Modifier.weight(1f), big, small, calling && hasName, bigSize)
                }
            } else {
                HeroTexts(Modifier.fillMaxWidth(), big, small, false, bigSize)
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(glass)
                    .border(1.dp, glassLine, RoundedCornerShape(20.dp)).padding(Sp.l),
                verticalArrangement = Arrangement.spacedBy(Sp.m)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(T("Campaign progress", "تقدّم الحملة"), color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                    Text("${p.pct}%", color = Color.White, style = MaterialTheme.typography.titleSmall)
                }
                BProgress(p.pct / 100f, color = Color.White, track = Color.White.copy(alpha = 0.25f), height = 6.dp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(T("${p.called} of ${p.total} called", "${p.called} من ${p.total} تم الاتصال"),
                        color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                    Text(T("${p.remaining} left", "${p.remaining} متبقي"),
                        color = Color.White, style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                }
                if (c.loops > 1) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(glassLine))
                    Text(T("Round ${c.loop} of ${c.loops}", "الجولة ${c.loop} من ${c.loops}"),
                        color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                }
            }
            if (showControls) HeroControls(c.status == CS.PAUSED, compact)
        }
    }
}

private fun initialsOf(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return parts.take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "#" }
}

@Composable
private fun HeroTexts(modifier: Modifier, big: String, small: String, numberLine: Boolean, size: TextUnit) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
        Text(big, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.headlineLarge.copy(fontSize = size))
        if (small.isNotEmpty()) {
            if (numberLine) NumText(small, color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.titleMedium)
            else Text(small, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun UpNext(list: CallList, remaining: Int) {
    val next = list.entries.filter { it.status == St.PENDING }.take(3)
    if (next.isNotEmpty()) {
        val cs = MaterialTheme.colorScheme
        Panel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(start = Sp.l, end = Sp.l, top = Sp.l)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            T("UP NEXT", "التالي"),
                            style = MaterialTheme.typography.labelMedium.copy(letterSpacing = if (Store.cfg.lang == 0) 1.5.sp else 0.sp),
                            color = cs.onSurfaceVariant
                        )
                        Spacer(Modifier.height(Sp.xs))
                        Text(T("Coming up in the queue", "الدور القادم في الطابور"), style = MaterialTheme.typography.titleLarge)
                    }
                    Pill(T("$remaining left", "$remaining متبقي"), cs.primary)
                }
                Spacer(Modifier.height(Sp.m))
                next.forEachIndexed { i, e ->
                    Box(Modifier.fillMaxWidth().height(1.dp).background(cs.outline))
                    Row(Modifier.fillMaxWidth().padding(vertical = Sp.m), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant), Alignment.Center) {
                            Text("${i + 1}", style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(Modifier.width(Sp.m))
                        Column {
                            Text(e.name.ifBlank { e.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            if (e.name.isNotBlank()) NumText(e.number, style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/** Call controls that live inside the hero card: Pause/Resume (solid white), End call and Stop (glass). */
@Composable
private fun HeroControls(paused: Boolean, compact: Boolean) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        HeroButton(
            if (paused) T("Resume", "استئناف") else T("Pause", "إيقاف مؤقت"),
            if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
            Modifier.weight(1.4f), solid = true, iconOnly = false, tint = HeroBg
        ) { DialerService.send(ctx, if (paused) DialerService.ACT_RESUME else DialerService.ACT_PAUSE) }
        HeroButton(T("End call", "إنهاء"), Icons.Rounded.SkipNext, Modifier.weight(1f), solid = false,
            iconOnly = compact, tint = Color.White) { DialerService.send(ctx, DialerService.ACT_SKIP) }
        HeroButton(T("Stop", "إيقاف"), Icons.Rounded.Stop, Modifier.weight(1f), solid = false,
            iconOnly = compact, tint = Color(0xFFFFB4AB)) { DialerService.send(ctx, DialerService.ACT_STOP) }
    }
}

@Composable
private fun HeroButton(
    label: String, icon: ImageVector, modifier: Modifier, solid: Boolean, iconOnly: Boolean, tint: Color, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.heightIn(min = 48.dp).clip(shape)
            .background(if (solid) Color.White else Color.White.copy(alpha = 0.12f))
            .then(if (solid) Modifier else Modifier.border(1.dp, Color.White.copy(alpha = 0.18f), shape))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = if (iconOnly) 12.dp else 14.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, if (iconOnly) label else null, tint = tint, modifier = Modifier.size(20.dp))
        if (!iconOnly) {
            Spacer(Modifier.width(6.dp))
            Text(label, color = tint, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Launcher(act: MainActivity) {
    val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
    val selList = Store.lists.find { it.id == sel }
    val p = selList?.let { Store.prog(it) }

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            SectionLabel(T("Choose a campaign", "اختر الحملة"))
            if (Store.lists.isEmpty()) {
                Text(T("Create a campaign first.", "أنشئ حملة أولاً."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                BButton(T("Go to campaigns", "الذهاب إلى الحملات"), { Store.tab = 0 }, kind = BtnKind.Tonal, compact = true)
            }
            Store.lists.forEach { l ->
                val lp = Store.prog(l)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).clickable { Store.runListId = l.id }
                        .background(if (l.id == sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                        .heightIn(min = 56.dp).padding(horizontal = Sp.s),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = l.id == sel, onClick = { Store.runListId = l.id })
                    Column(Modifier.weight(1f)) {
                        Text(l.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(T("${lp.total} contacts · ${lp.remaining} left", "${lp.total} جهة · ${lp.remaining} متبقي"),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (sel != null && p != null && p.total > 0) {
        val resumable = p.called > 0 && p.remaining > 0
        BButton(
            when {
                resumable -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                p.called > 0 -> T("Restart campaign", "إعادة تشغيل الحملة")
                else -> T("Start campaign", "ابدأ الحملة")
            },
            { act.startCampaign(sel, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
        )
        if (resumable) {
            BButton(T("Restart from the beginning", "ابدأ من الأول"), { act.startCampaign(sel, true) },
                Modifier.fillMaxWidth(), kind = BtnKind.Outline, icon = Icons.Rounded.Refresh)
        }
    }

    RunSetupStrip()
}
